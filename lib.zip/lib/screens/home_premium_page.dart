import 'package:flutter/material.dart';

import '../core/theme/app_dimensions.dart';
import '../widgets/home_premium/dashboard.dart';
import '../widgets/home_premium/home_header.dart';
import '../widgets/home_premium/home_map.dart';

class HomePremiumPage extends StatelessWidget {
  const HomePremiumPage({super.key});

  @override
  Widget build(BuildContext context) {
    final bool tablet = AppDimensions.isTablet(context);

    return Scaffold(
      backgroundColor: const Color(0xFF0F1115),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: tablet ? 22 : 16),
            child: Column(
              children: [
                const SizedBox(height: 8),

                const HomePremiumHeader(),

                const SizedBox(height: 12),

                SizedBox(
                  height: tablet ? 430 : 370,
                  child: const HomePremiumMap(),
                ),

                const SizedBox(height: 18),

                const PremiumDashboard(),

                const SizedBox(height: 120),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
