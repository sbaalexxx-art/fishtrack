import 'dart:ui';

import 'package:flutter/material.dart';

import 'favorites_page.dart';
import 'home_premium_page.dart';
import 'map_page.dart';
import 'reports_page.dart';
import 'settings_page.dart';
import 'weather_page.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    HomePremiumPage(),
    MapPage(),
    WeatherPage(),
    ReportsPage(),
    FavoritesPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      backgroundColor: const Color(0xFF0F1115),
      body: _pages[_selectedIndex],

      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(34),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                height: 82,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.08),
                  borderRadius: BorderRadius.circular(34),
                  border: Border.all(color: Colors.white.withOpacity(.08)),
                ),
                child: Row(
                  children: [
                    Expanded(child: _item(Icons.home_rounded, 0)),

                    Expanded(child: _item(Icons.map_rounded, 1)),

                    Expanded(
                      child: Center(
                        child: GestureDetector(
                          onTap: () {},
                          child: Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              color: const Color(0xFF67D04B),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFF67D04B,
                                  ).withOpacity(.35),
                                  blurRadius: 24,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.add,
                              size: 38,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ),

                    Expanded(child: _item(Icons.campaign_rounded, 3)),

                    Expanded(child: _item(Icons.person_rounded, 5)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(IconData icon, int index) {
    final selected = _selectedIndex == index;

    return IconButton(
      onPressed: () {
        setState(() {
          _selectedIndex = index;
        });
      },
      icon: AnimatedScale(
        duration: const Duration(milliseconds: 180),
        scale: selected ? 1.15 : 1,
        child: Icon(
          icon,
          size: 29,
          color: selected ? const Color(0xFF67D04B) : Colors.white60,
        ),
      ),
    );
  }
}
