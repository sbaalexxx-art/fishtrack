import 'dart:async';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:latlong2/latlong.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart' as mapbox;

import '../core/context/current_location.dart';
import '../core/context/selected_context.dart';
import '../core/map/map_feature_registry.dart';
import '../core/map/map_runtime_provenance.dart';
import '../core/map/map_theme_style.dart';
import '../core/map/pending_map_camera.dart';
import '../core/navigation/app_destination.dart';
import '../core/navigation/app_navigator.dart';
import '../core/navigation/map_entry.dart';
import '../l10n/l10n.dart';
import '../models/station.dart';
import '../services/community_service.dart';
import '../services/favorite_stations_service.dart';
import '../services/location_service.dart';
import '../services/water_service.dart';
import '../widgets/fluviai/draggable_ask_fluvi.dart';

enum _FullMapStyle {
  satellite(Icons.satellite_alt_rounded),
  standard(Icons.map_rounded),
  outdoors(Icons.terrain_rounded),
  streets(Icons.route_rounded);

  const _FullMapStyle(this.icon);

  final IconData icon;

  String get uri => switch (this) {
    _FullMapStyle.satellite => MapThemeStyle.satellite,
    _FullMapStyle.standard => MapThemeStyle.standard,
    _FullMapStyle.outdoors => MapThemeStyle.outdoors,
    _FullMapStyle.streets => MapThemeStyle.streets,
  };
}

@immutable
class MapFocusRequest {
  const MapFocusRequest({required this.id, required this.target, this.station});

  final int id;
  final RuntimeMapCameraTarget target;
  final Station? station;
}

/// One-shot bridge between the existing tab router and the persistent Map.
///
/// A request remains pending until the Map consumes it. Reopening the same
/// station creates a new request id, while [takePending] can return each
/// request only once.
class MapFocusController extends ChangeNotifier {
  int _nextRequestId = 0;
  MapFocusRequest? _pending;

  MapFocusRequest? get pending => _pending;

  void requestStation(Station station) {
    _pending = MapFocusRequest(
      id: ++_nextRequestId,
      station: station,
      target: RuntimeMapCameraTarget(
        source: 'water-navigation',
        entityId: station.id,
        latitude: station.latitude,
        longitude: station.longitude,
        zoom: 13.5,
      ),
    );
    logMapRuntime(
      'focus-controller.request',
      station: station,
      fields: {'focusRequestId': _pending!.id},
    );
    notifyListeners();
  }

  void requestTarget(RuntimeMapCameraTarget target) {
    _pending = MapFocusRequest(id: ++_nextRequestId, target: target);
    logMapRuntime(
      'focus-controller.request-target',
      fields: {
        'focusRequestId': _pending!.id,
        'source': target.source,
        'entityId': target.entityId,
      },
    );
    notifyListeners();
  }

  MapFocusRequest? takePending() {
    final request = _pending;
    _pending = null;
    if (request != null) {
      logMapRuntime(
        'focus-controller.consume',
        station: request.station,
        fields: {'focusRequestId': request.id, 'source': request.target.source},
      );
    }
    return request;
  }
}

/// A pushed, source-preserving presentation of the one production [MapPage].
///
/// General browsing remains the bottom-nav Map tab. Explicit entity/place
/// intents push this wrapper so Back deterministically returns to the caller.
class ContextualMapPage extends ConsumerStatefulWidget {
  const ContextualMapPage({super.key, required this.entry});

  final ContextualMapEntry? entry;

  @override
  ConsumerState<ContextualMapPage> createState() => _ContextualMapPageState();
}

class _ContextualMapPageState extends ConsumerState<ContextualMapPage> {
  late final ValueNotifier<bool> _active;
  late final MapFocusController _focusController;

  @override
  void initState() {
    super.initState();
    _active = ValueNotifier<bool>(true);
    _focusController = MapFocusController();
    final entry = widget.entry;
    final station = entry?.station;
    final target = entry?.cameraTarget;
    if (station != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          ref.read(selectedContextProvider.notifier).selectStation(station);
        }
      });
      _focusController.requestStation(station);
    } else if (target != null) {
      _focusController.requestTarget(target);
    }
  }

  @override
  void dispose() {
    _active.dispose();
    _focusController.dispose();
    super.dispose();
  }

  Future<void> _openAddCatch() async {
    final added = await AppNavigator.open<bool>(
      context,
      AppDestination.addCatch,
    );
    if (mounted && added == true) {
      await AppNavigator.open<void>(context, AppDestination.myCatches);
    }
  }

  @override
  Widget build(BuildContext context) => MapPage(
    isActiveListenable: _active,
    focusController: _focusController,
    includeBottomSafeArea: true,
    onBack: () => Navigator.of(context).maybePop(),
    onAddCatch: _openAddCatch,
    onCreateReport: (category) => AppNavigator.open<void>(
      context,
      AppDestination.addReport,
      arguments: category,
    ),
  );
}

/// Returns dataset-wide station candidates for the Full Map annotation layer.
///
/// Monitoring-station coverage is independent from the device/local camera
/// radius. Local radius filtering belongs to contextual layers such as reports.
List<Station> filterFullMapStations({
  required Iterable<Station> stations,
  Set<String>? stationIds,
}) {
  final ids = stationIds;
  return stations
      .where((station) {
        if (ids != null && !ids.contains(station.id)) return false;
        if (!isValidRuntimeMapCoordinate(station.latitude, station.longitude)) {
          return false;
        }
        return true;
      })
      .toList(growable: false);
}

const Color fullMapTemporaryStationHighlightColor = Color(0xFFFFD166);

List<CommunityPost> filterFullMapReports({
  required Iterable<CommunityPost> reports,
  required LatLng? center,
  required double radiusKm,
  required Set<ReportCategory> categories,
}) => reports
    .where((report) {
      final latitude = report.latitude;
      final longitude = report.longitude;
      if (latitude == null || longitude == null) return false;
      if (!isValidRuntimeMapCoordinate(latitude, longitude)) return false;
      final category = report.reportCategory;
      if (categories.isNotEmpty &&
          (category == null || !categories.contains(category))) {
        return false;
      }
      return _fullMapPointWithinRadius(
        latitude: latitude,
        longitude: longitude,
        center: center,
        radiusKm: radiusKm,
      );
    })
    .toList(growable: false);

bool isValidRuntimeMapCoordinate(double latitude, double longitude) =>
    latitude.isFinite &&
    longitude.isFinite &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180 &&
    (latitude != 0 || longitude != 0);

bool _fullMapPointWithinRadius({
  required double latitude,
  required double longitude,
  required LatLng? center,
  required double radiusKm,
}) {
  if (center == null || radiusKm.isInfinite) return true;
  const distance = Distance();
  return distance.as(
        LengthUnit.Kilometer,
        center,
        LatLng(latitude, longitude),
      ) <=
      radiusKm;
}

class MapPage extends ConsumerStatefulWidget {
  const MapPage({
    super.key,
    required this.isActiveListenable,
    required this.focusController,
    required this.onAddCatch,
    required this.onCreateReport,
    this.favoriteStationsService = const FavoriteStationsService(),
    this.includeBottomSafeArea = true,
    this.onBack,
  });

  final ValueListenable<bool> isActiveListenable;
  final MapFocusController focusController;
  final VoidCallback onAddCatch;
  final ValueChanged<ReportCategory> onCreateReport;
  final FavoriteStationsService favoriteStationsService;
  final bool includeBottomSafeArea;
  final VoidCallback? onBack;

  @override
  ConsumerState<MapPage> createState() => _MapPageState();
}

class _MapPageState extends ConsumerState<MapPage> with WidgetsBindingObserver {
  final WaterService _waterService = WaterService();
  final CommunityService _communityService = const CommunityService();
  FavoriteStationsService get _favoriteStationsService =>
      widget.favoriteStationsService;
  final PendingMapCameraCoordinator _cameraCoordinator =
      PendingMapCameraCoordinator();

  mapbox.MapboxMap? _mapboxMap;
  mapbox.CircleAnnotationManager? _stationAnnotationManager;
  mapbox.CircleAnnotationManager? _stationHighlightAnnotationManager;
  mapbox.CircleAnnotationManager? _userAnnotationManager;
  mapbox.CircleAnnotationManager? _reportAnnotationManager;
  dynamic _stationTapEvents;
  dynamic _reportTapEvents;

  List<Station> _stations = const [];
  List<CommunityPost> _activeReports = const [];
  Set<String> _favoriteStationIds = const {};
  LatLng? _currentLocation;
  bool _isLocating = false;
  bool _isLoadingStations = false;
  bool _stationLayerVisible = true;
  bool _communityReportsVisible = true;
  bool _favoriteStationsVisible = false;
  double _localRadiusKm = 100;
  Set<ReportCategory> _reportCategories = const {};
  bool _hasLoadedInitialStyle = false;
  bool _isChangingMapStyle = false;
  bool _isCompletingStyleChange = false;
  _FullMapStyle _selectedMapStyle = _FullMapStyle.satellite;
  _FullMapStyle? _pendingMapStyle;
  mapbox.CameraState? _cameraBeforeStyleChange;
  Station? _temporarilyHighlightedStation;
  Station? _previewStation;
  String? _stationLoadError;
  String? _stationAnnotationFingerprint;
  Timer? _stationRefreshTimer;
  bool _isFullMapActive = false;
  bool _hasSelectedStationFocus = false;
  String? _locationUnavailableMessage;
  double? _gpsSpeedKmh;
  double? _gpsHeadingDegrees;
  Orientation? _orientation;
  Size? _mediaSize;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _isFullMapActive = widget.isActiveListenable.value;
    widget.isActiveListenable.addListener(_handleMapActiveChanged);
    widget.focusController.addListener(_consumePendingFocus);
    _consumePendingFocus();
    _loadStations();
    _loadApprovedMapLayers();
    _updateStationRefreshTimer();
    WidgetsBinding.instance.addPostFrameCallback((_) => _locateUser());
  }

  @override
  void didUpdateWidget(covariant MapPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (identical(oldWidget.isActiveListenable, widget.isActiveListenable)) {
      if (!identical(oldWidget.focusController, widget.focusController)) {
        oldWidget.focusController.removeListener(_consumePendingFocus);
        widget.focusController.addListener(_consumePendingFocus);
        _consumePendingFocus();
      }
      return;
    }

    oldWidget.isActiveListenable.removeListener(_handleMapActiveChanged);
    _isFullMapActive = widget.isActiveListenable.value;
    widget.isActiveListenable.addListener(_handleMapActiveChanged);
    if (!identical(oldWidget.focusController, widget.focusController)) {
      oldWidget.focusController.removeListener(_consumePendingFocus);
      widget.focusController.addListener(_consumePendingFocus);
      _consumePendingFocus();
    }
    _updateStationRefreshTimer();
    if (_isFullMapActive) {
      unawaited(_loadStations());
      unawaited(_loadApprovedMapLayers());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _isFullMapActive) {
      _cameraCoordinator.markReentered();
      unawaited(_applyPendingCameraIfReady());
      unawaited(_loadStations());
      unawaited(_loadApprovedMapLayers());
    }
  }

  void _handleMapActiveChanged() {
    final isActive = widget.isActiveListenable.value;
    if (_isFullMapActive == isActive) return;

    _isFullMapActive = isActive;
    _updateStationRefreshTimer();
    if (isActive) {
      _cameraCoordinator.markReentered();
      unawaited(_applyPendingCameraIfReady());
      unawaited(_loadStations());
      unawaited(_loadApprovedMapLayers());
    }
  }

  Future<void> _toggleFavorite(Station station) async {
    final shouldFavorite = !_favoriteStationIds.contains(station.id);
    try {
      await _favoriteStationsService.setFavorite(
        station.id,
        favorite: shouldFavorite,
      );
      if (!mounted) return;
      setState(() {
        final next = {..._favoriteStationIds};
        shouldFavorite ? next.add(station.id) : next.remove(station.id);
        _favoriteStationIds = next;
      });
      await _syncStationAnnotations();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            shouldFavorite
                ? 'Stația a fost adăugată la Favorite.'
                : 'Stația a fost eliminată din Favorite.',
          ),
        ),
      );
    } on FavoriteException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message)));
    }
  }

  void _updateStationRefreshTimer() {
    _stationRefreshTimer?.cancel();
    _stationRefreshTimer = null;
    if (!_isFullMapActive) return;

    _stationRefreshTimer = Timer.periodic(WaterService.cacheDuration, (_) {
      if (!mounted || !_isFullMapActive) return;
      unawaited(_loadStations());
      unawaited(_loadApprovedMapLayers());
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final orientation = MediaQuery.orientationOf(context);
    final mediaSize = MediaQuery.sizeOf(context);
    if (_orientation == orientation && _mediaSize == mediaSize) return;
    _orientation = orientation;
    _mediaSize = mediaSize;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mapboxMap = _mapboxMap;
      if (mounted && mapboxMap != null) {
        unawaited(_updateMapboxOrnaments(mapboxMap));
      }
    });
  }

  @override
  void dispose() {
    _stationRefreshTimer?.cancel();
    widget.isActiveListenable.removeListener(_handleMapActiveChanged);
    widget.focusController.removeListener(_consumePendingFocus);
    WidgetsBinding.instance.removeObserver(this);
    _stationTapEvents?.cancel();
    _reportTapEvents?.cancel();
    _stationAnnotationManager?.deleteAll();
    _stationHighlightAnnotationManager?.deleteAll();
    _userAnnotationManager?.deleteAll();
    _reportAnnotationManager?.deleteAll();
    _cameraCoordinator.markMapDetached();
    super.dispose();
  }

  Future<void> _onMapCreated(mapbox.MapboxMap mapboxMap) async {
    _mapboxMap = mapboxMap;
    _cameraCoordinator.markMapCreated();
    logMapRuntime('map.created-style-pending');

    await _updateMapboxOrnaments(mapboxMap);
    await _applyPendingCameraIfReady();
  }

  void _consumePendingFocus() {
    final request = widget.focusController.takePending();
    if (request == null) return;
    final station = request.station;
    _hasSelectedStationFocus = station != null;
    _locationUnavailableMessage = null;
    final cameraRequestId = _cameraCoordinator.request(request.target);
    logMapRuntime(
      'map.focus-consumed',
      station: station,
      fields: {
        'focusRequestId': request.id,
        'cameraRequestId': cameraRequestId,
      },
    );
    if (mounted && station != null) {
      setState(() {
        _stationLayerVisible = true;
        _temporarilyHighlightedStation = station;
        _previewStation = station;
      });
    } else if (station != null) {
      _stationLayerVisible = true;
      _temporarilyHighlightedStation = station;
      _previewStation = station;
    } else if (mounted) {
      setState(() {
        _temporarilyHighlightedStation = null;
        _previewStation = null;
      });
    }
    unawaited(_applyPendingCameraIfReady());
    unawaited(_syncStationAnnotations());
    unawaited(_syncReportAnnotations());
  }

  void _onStyleLoaded(mapbox.StyleLoadedEventData _) {
    _cameraCoordinator.markStyleLoaded();
    if (mounted) setState(() => _hasLoadedInitialStyle = true);
    _isCompletingStyleChange = true;
    logMapRuntime('map.style-loaded');
    unawaited(_restoreAfterStyleChange());
  }

  Future<void> _bindAnnotationManagers(
    mapbox.MapboxMap mapboxMap, {
    bool replaceExisting = false,
  }) async {
    if (!_cameraCoordinator.isReady) return;
    if (!replaceExisting &&
        _stationAnnotationManager != null &&
        _stationHighlightAnnotationManager != null &&
        _userAnnotationManager != null &&
        _reportAnnotationManager != null) {
      return;
    }

    if (replaceExisting) {
      await _releaseAnnotationManagers(mapboxMap);
    }

    _stationAnnotationManager = await mapboxMap.annotations
        .createCircleAnnotationManager();
    try {
      _stationTapEvents = _stationAnnotationManager?.tapEvents(
        onTap: _handleStationAnnotationTap,
      );
      _stationHighlightAnnotationManager = await mapboxMap.annotations
          .createCircleAnnotationManager();
      _userAnnotationManager = await mapboxMap.annotations
          .createCircleAnnotationManager();
      _reportAnnotationManager = await mapboxMap.annotations
          .createCircleAnnotationManager();
      _reportTapEvents = _reportAnnotationManager?.tapEvents(
        onTap: _handleReportAnnotationTap,
      );

      await _syncStationAnnotations();
      await _syncUserAnnotation();
      await _syncReportAnnotations();
    } catch (_) {
      await _releaseAnnotationManagers(mapboxMap);
      rethrow;
    }
  }

  Future<void> _releaseAnnotationManagers(mapbox.MapboxMap mapboxMap) async {
    final stationManager = _stationAnnotationManager;
    final highlightManager = _stationHighlightAnnotationManager;
    final userManager = _userAnnotationManager;
    final reportManager = _reportAnnotationManager;

    await _stationTapEvents?.cancel();
    await _reportTapEvents?.cancel();
    _stationTapEvents = null;
    _reportTapEvents = null;
    _stationAnnotationManager = null;
    _stationHighlightAnnotationManager = null;
    _userAnnotationManager = null;
    _reportAnnotationManager = null;
    _stationAnnotationFingerprint = null;

    for (final manager in [
      stationManager,
      highlightManager,
      userManager,
      reportManager,
    ]) {
      if (manager == null) continue;
      try {
        await mapboxMap.annotations.removeAnnotationManager(manager);
      } catch (_) {
        // A completed style load may already have released the native manager.
      }
    }
  }

  Future<void> _restoreAfterStyleChange() async {
    final mapboxMap = _mapboxMap;
    final pendingStyle = _pendingMapStyle;
    final camera = _cameraBeforeStyleChange;
    if (mapboxMap == null) {
      _finishStyleChange();
      return;
    }

    var restoreFailed = false;
    try {
      if (_cameraCoordinator.activeTarget == null && camera != null) {
        await mapboxMap.setCamera(
          mapbox.CameraOptions(
            center: camera.center,
            padding: camera.padding,
            zoom: camera.zoom,
            bearing: camera.bearing,
            pitch: camera.pitch,
          ),
        );
      }
    } catch (_) {
      restoreFailed = true;
    }
    try {
      await _updateMapboxOrnaments(mapboxMap);
    } catch (_) {
      restoreFailed = true;
    }
    try {
      await _bindAnnotationManagers(mapboxMap, replaceExisting: true);
    } catch (_) {
      restoreFailed = true;
    }
    try {
      await _applyPendingCameraIfReady();
    } catch (_) {
      restoreFailed = true;
    }

    if (restoreFailed && mounted) {
      _showStyleChangeError();
    }
    if (!mounted) {
      _finishStyleChange();
      return;
    }
    setState(() {
      if (pendingStyle != null) _selectedMapStyle = pendingStyle;
      _isChangingMapStyle = false;
      _isCompletingStyleChange = false;
      _pendingMapStyle = null;
      _cameraBeforeStyleChange = null;
    });
  }

  void _finishStyleChange() {
    _isChangingMapStyle = false;
    _isCompletingStyleChange = false;
    _pendingMapStyle = null;
    _cameraBeforeStyleChange = null;
  }

  Future<void> _updateMapboxOrnaments(mapbox.MapboxMap mapboxMap) async {
    if (!mounted) return;
    final size = MediaQuery.sizeOf(context);
    final isLandscape = size.width > size.height;

    await mapboxMap.scaleBar.updateSettings(
      mapbox.ScaleBarSettings(
        position: mapbox.OrnamentPosition.BOTTOM_RIGHT,
        marginRight: 12,
        marginBottom: 12,
        ratio: isLandscape ? .24 : .3,
      ),
    );
  }

  Future<void> _loadStations() async {
    if (_isLoadingStations) return;
    setState(() {
      _isLoadingStations = true;
      _stationLoadError = null;
    });

    try {
      final stations = await _waterService.getStations();
      if (!mounted) return;
      setState(() => _stations = stations);
      logMapRuntime(
        'layers.stations-fetched',
        fields: {'count': stations.length},
      );
      await _syncStationAnnotations();
    } on Exception {
      if (!mounted) return;
      setState(() => _stationLoadError = context.l10n.waterProviderUnavailable);
    } finally {
      if (mounted) setState(() => _isLoadingStations = false);
    }
  }

  Future<void> _loadApprovedMapLayers() async {
    List<CommunityPost> reports = _activeReports;
    Set<String> favorites = _favoriteStationIds;
    try {
      reports = await _communityService.getActiveReports();
    } on Exception {
      // Keep the last truthful report snapshot when the feed is unavailable.
    }
    if (_favoriteStationsService.isAuthenticated) {
      try {
        favorites = await _favoriteStationsService.getFavoriteIds();
      } on FavoriteException {
        // Other approved layers stay usable when favorites are unavailable.
      }
    } else {
      favorites = const {};
    }
    if (!mounted) return;
    setState(() {
      _activeReports = reports;
      _favoriteStationIds = favorites;
    });
    logMapRuntime(
      'layers.repositories-fetched',
      fields: {'reports': reports.length, 'favorites': favorites.length},
    );
    await _syncStationAnnotations();
    await _syncReportAnnotations();
  }

  LatLng? get _activeFilterCenter {
    final station = _previewStation ?? _temporarilyHighlightedStation;
    if (station != null) return LatLng(station.latitude, station.longitude);
    final target = _cameraCoordinator.activeTarget;
    if (target != null) return LatLng(target.latitude, target.longitude);
    return _currentLocation;
  }

  List<Station> get _visibleStations =>
      filterFullMapStations(stations: _stations);

  List<CommunityPost> get _visibleReports => filterFullMapReports(
    reports: _activeReports,
    center: _activeFilterCenter,
    radiusKm: _localRadiusKm,
    categories: _reportCategories,
  );

  Future<void> _locateUser({bool recenter = false}) async {
    if (_isLocating) return;

    setState(() => _isLocating = true);
    try {
      final languageCode = Localizations.localeOf(context).languageCode;
      final canonical = await ref
          .read(currentLocationProvider.notifier)
          .refresh(languageCode: languageCode, force: recenter);
      if (!mounted) return;
      final deviceLocation = canonical.location;
      if (!canonical.hasUsableLocation || deviceLocation == null) {
        throw LocationFailure(_failureReasonFor(canonical.status));
      }
      final location = LatLng(
        deviceLocation.latitude,
        deviceLocation.longitude,
      );
      setState(() {
        _currentLocation = location;
        _gpsSpeedKmh = deviceLocation.speedMetersPerSecond == null
            ? null
            : deviceLocation.speedMetersPerSecond! * 3.6;
        _gpsHeadingDegrees = deviceLocation.headingDegrees;
        _locationUnavailableMessage = null;
      });
      await _syncUserAnnotation();
      await _syncStationAnnotations();
      await _syncReportAnnotations();
      if (recenter) {
        _clearSelectedStationFocus();
        _queueDeviceLocationCamera(location, zoom: 13.5);
      } else if (!_hasSelectedStationFocus &&
          _cameraCoordinator.activeTarget == null) {
        _queueDeviceLocationCamera(location, zoom: 12.5);
      }
    } on LocationFailure catch (failure) {
      if (!mounted) return;
      final message = switch (failure.reason) {
        LocationFailureReason.serviceDisabled => context.l10n.locationRequired,
        LocationFailureReason.permissionDenied => context.l10n.locationRequired,
        LocationFailureReason.permissionDeniedForever =>
          context.l10n.locationRequired,
        LocationFailureReason.unavailable => context.l10n.notAvailable,
      };
      if (_cameraCoordinator.activeTarget == null) {
        setState(() => _locationUnavailableMessage = message);
      }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) setState(() => _isLocating = false);
    }
  }

  LocationFailureReason _failureReasonFor(CurrentLocationStatus status) =>
      switch (status) {
        CurrentLocationStatus.serviceDisabled =>
          LocationFailureReason.serviceDisabled,
        CurrentLocationStatus.permissionDenied =>
          LocationFailureReason.permissionDenied,
        CurrentLocationStatus.permissionDeniedForever =>
          LocationFailureReason.permissionDeniedForever,
        _ => LocationFailureReason.unavailable,
      };

  void _clearSelectedStationFocus() {
    _hasSelectedStationFocus = false;
    if (!mounted) return;
    setState(() {
      _previewStation = null;
      _temporarilyHighlightedStation = null;
    });
    unawaited(_syncStationAnnotations());
    unawaited(_syncReportAnnotations());
  }

  void _queueDeviceLocationCamera(LatLng target, {required double zoom}) {
    final requestId = _cameraCoordinator.request(
      deviceLocationCameraTarget(
        latitude: target.latitude,
        longitude: target.longitude,
        zoom: zoom,
      ),
    );
    logMapRuntime(
      'map.device-location-queued',
      fields: {
        'cameraRequestId': requestId,
        'latitude': target.latitude,
        'longitude': target.longitude,
      },
    );
    unawaited(_applyPendingCameraIfReady());
  }

  Future<void> _applyPendingCameraIfReady() async {
    final mapboxMap = _mapboxMap;
    final application = _cameraCoordinator.takeReadyApplication();
    if (mapboxMap == null || application == null) return;
    final target = application.target;
    await mapboxMap.setCamera(
      mapbox.CameraOptions(
        center: mapbox.Point(
          coordinates: mapbox.Position(target.longitude, target.latitude),
        ),
        zoom: target.zoom,
      ),
    );
    logMapRuntime(
      'map.camera-applied',
      fields: {
        'cameraRequestId': application.requestId,
        'source': target.source,
        'entityId': target.entityId,
        'latitude': target.latitude,
        'longitude': target.longitude,
        'replay': application.isReplay,
      },
    );
  }

  bool get _annotationSyncBlocked =>
      _isChangingMapStyle && !_isCompletingStyleChange;

  Future<void> _syncStationAnnotations() async {
    if (_annotationSyncBlocked) return;
    final manager = _stationAnnotationManager;
    final highlightManager = _stationHighlightAnnotationManager;
    if (!_cameraCoordinator.isReady ||
        manager == null ||
        highlightManager == null) {
      return;
    }

    final existingAnnotations = await manager.getAnnotations();
    final visibleStations = _visibleStations;
    if (!_stationLayerVisible) {
      if (existingAnnotations.isNotEmpty) {
        await manager.deleteAll();
      }
      _stationAnnotationFingerprint = null;
    } else {
      final fingerprint = _buildStationAnnotationFingerprint(visibleStations);
      final annotationsChanged =
          existingAnnotations.length != visibleStations.length ||
          _stationAnnotationFingerprint != fingerprint;
      if (annotationsChanged) {
        await manager.deleteAll();
        if (visibleStations.isNotEmpty) {
          final annotations = visibleStations
              .map(_stationAnnotationOptions)
              .toList(growable: false);
          await manager.createMulti(annotations);
        }
        _stationAnnotationFingerprint = fingerprint;
      }
    }

    await manager.setCircleOpacity(1);
    await manager.setCircleStrokeOpacity(1);

    await highlightManager.deleteAll();
    final highlightedStation = _temporarilyHighlightedStation;
    final highlightedById = <String, Station>{
      if (_favoriteStationsVisible)
        for (final station in visibleStations)
          if (_favoriteStationIds.contains(station.id)) station.id: station,
    };
    if (highlightedStation != null) {
      highlightedById[highlightedStation.id] = highlightedStation;
    }
    if (highlightedById.isNotEmpty) {
      await highlightManager.createMulti(
        highlightedById.values
            .map(
              (station) => _stationAnnotationOptions(
                station,
                highlighted: station.id == highlightedStation?.id,
                favorite: _favoriteStationIds.contains(station.id),
              ),
            )
            .toList(growable: false),
      );
    }
    logMapRuntime(
      'layers.station-annotations',
      fields: {
        'fetched': _stations.length,
        'visible': visibleStations.length,
        'created': _stationLayerVisible ? visibleStations.length : 0,
        'highlighted': highlightedById.length,
        'favoriteVisible': highlightedById.values
            .where((station) => _favoriteStationIds.contains(station.id))
            .length,
      },
    );
  }

  String _buildStationAnnotationFingerprint(Iterable<Station> source) {
    final stations = List<Station>.of(source)
      ..sort((left, right) => left.id.compareTo(right.id));

    return stations
        .map((station) {
          return '${station.id}|'
              '${station.latitude.toStringAsFixed(6)}|'
              '${station.longitude.toStringAsFixed(6)}|'
              '${station.hasKnownTrend ? 1 : 0}|'
              '${station.trend.name}';
        })
        .join(';');
  }

  mapbox.CircleAnnotationOptions _stationAnnotationOptions(
    Station station, {
    bool highlighted = false,
    bool favorite = false,
  }) {
    final stationColor = _stationTrendColor(station);
    final fillColor = highlighted
        ? fullMapTemporaryStationHighlightColor
        : favorite
        ? MapFeatureRegistry.favorite
        : station.hasKnownTrend
        ? stationColor
        : stationColor.withValues(alpha: .88);

    return mapbox.CircleAnnotationOptions(
      geometry: mapbox.Point(
        coordinates: mapbox.Position(station.longitude, station.latitude),
      ),
      circleRadius: highlighted
          ? 8.5
          : favorite
          ? 7.5
          : 6.5,
      circleColor: _mapboxColor(fillColor),
      circleOpacity: 1,
      circleStrokeColor: _mapboxColor(
        highlighted || favorite ? Colors.white : const Color(0xFF06141D),
      ),
      circleStrokeWidth: highlighted
          ? 3.2
          : favorite
          ? 2.8
          : 2.2,
      circleSortKey: highlighted
          ? 60
          : favorite
          ? 40
          : 20,
      customData: <String, Object>{
        'type': 'water_station',
        'stationId': station.id,
      },
    );
  }

  Color _stationTrendColor(Station station) {
    return MapFeatureRegistry.stationTrendColor(station);
  }

  Future<void> _syncUserAnnotation() async {
    if (_annotationSyncBlocked) return;
    final manager = _userAnnotationManager;
    final location = _currentLocation;
    if (!_cameraCoordinator.isReady || manager == null || location == null) {
      return;
    }

    await manager.deleteAll();
    await manager.create(
      mapbox.CircleAnnotationOptions(
        geometry: mapbox.Point(
          coordinates: mapbox.Position(location.longitude, location.latitude),
        ),
        circleRadius: 8,
        circleColor: _mapboxColor(MapFeatureRegistry.currentLocation),
        circleOpacity: .96,
        circleStrokeColor: _mapboxColor(Colors.white),
        circleStrokeWidth: 3,
        circleSortKey: 50,
        customData: const <String, Object>{'type': 'current_location'},
      ),
    );
  }

  void _handleStationAnnotationTap(mapbox.CircleAnnotation annotation) {
    final stationId = annotation.customData?['stationId']?.toString();
    if (stationId == null) return;

    Station? station;
    for (final item in _stations) {
      if (item.id == stationId) {
        station = item;
        break;
      }
    }
    if (station == null || !mounted) return;

    setState(() {
      _temporarilyHighlightedStation = station;
      _previewStation = station;
    });
    unawaited(_syncStationAnnotations());
  }

  Future<void> _syncReportAnnotations() async {
    if (_annotationSyncBlocked) return;
    final manager = _reportAnnotationManager;
    if (!_cameraCoordinator.isReady || manager == null) return;
    await manager.deleteAll();
    final reports = _communityReportsVisible
        ? _visibleReports
        : const <CommunityPost>[];
    if (reports.isNotEmpty) {
      await manager.createMulti(
        reports
            .map((report) {
              final category = report.reportCategory ?? ReportCategory.other;
              final presentation = MapFeatureRegistry.forReportCategory(
                category,
                context.l10n,
              );
              return mapbox.CircleAnnotationOptions(
                geometry: mapbox.Point(
                  coordinates: mapbox.Position(
                    report.longitude!,
                    report.latitude!,
                  ),
                ),
                circleRadius: 7,
                circleColor: _mapboxColor(presentation.color),
                circleOpacity: .96,
                circleStrokeColor: _mapboxColor(Colors.white),
                circleStrokeWidth: 2.4,
                circleSortKey: 30,
                customData: <String, Object>{
                  'type': 'community_report',
                  'reportId': report.id,
                },
              );
            })
            .toList(growable: false),
      );
    }
    logMapRuntime(
      'layers.report-annotations',
      fields: {
        'fetched': _activeReports.length,
        'visible': reports.length,
        'created': reports.length,
      },
    );
  }

  void _handleReportAnnotationTap(mapbox.CircleAnnotation annotation) {
    final reportId = annotation.customData?['reportId']?.toString();
    if (reportId == null) return;
    CommunityPost? report;
    for (final item in _activeReports) {
      if (item.id == reportId) {
        report = item;
        break;
      }
    }
    if (report == null || !mounted) return;
    AppNavigator.open<void>(
      context,
      AppDestination.reportDetail,
      arguments: report,
    );
  }

  Future<void> _showUnavailableMapLayer(String label) => showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(label),
      content: Text(
        Localizations.localeOf(context).languageCode.toLowerCase() == 'ro'
            ? 'Acest strat nu este conectat la o sursă de date de producție.'
            : 'This layer is not connected to a production data source.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('OK'),
        ),
      ],
    ),
  );

  Future<void> _openStation(Station station) async {
    ProviderScope.containerOf(
      context,
    ).read(selectedContextProvider.notifier).selectStation(station);
    await AppNavigator.open<void>(
      context,
      AppDestination.station,
      arguments: station,
    );
  }

  Future<void> _openSearch() =>
      AppNavigator.open<void>(context, AppDestination.search);

  bool get _canChangeMapStyle =>
      _cameraCoordinator.isReady &&
      _hasLoadedInitialStyle &&
      !_isChangingMapStyle &&
      _mapboxMap != null &&
      _stationAnnotationManager != null &&
      _stationHighlightAnnotationManager != null &&
      _userAnnotationManager != null &&
      _reportAnnotationManager != null;

  Future<void> _openMapStyleSelector() async {
    if (!_canChangeMapStyle) return;
    final languageCode = Localizations.localeOf(context).languageCode;
    final sheetWidth = MediaQuery.sizeOf(
      context,
    ).width.clamp(0.0, 440.0).toDouble();
    final selectedStyle = await showModalBottomSheet<_FullMapStyle>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: .58),
      constraints: BoxConstraints.tightFor(width: sheetWidth),
      builder: (context) => _MapStyleSelector(
        selectedStyle: _selectedMapStyle,
        languageCode: languageCode,
      ),
    );

    if (selectedStyle == null || !mounted) return;
    await _changeMapStyle(selectedStyle);
  }

  Future<void> _openFilters() async {
    final isRo = Localizations.localeOf(context).languageCode == 'ro';
    var draft = _FullMapFilterSelection(
      stationLayerVisible: _stationLayerVisible,
      communityReportsVisible: _communityReportsVisible,
      favoriteStationsVisible: _favoriteStationsVisible,
      radiusKm: _localRadiusKm,
      reportCategories: _reportCategories,
    );
    final result = await showModalBottomSheet<Object>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF101720),
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => FractionallySizedBox(
          heightFactor: .86,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
                child: Text(
                  isRo ? 'Filtre hartă' : 'Map filters',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  key: const ValueKey('full-map-approved-filters'),
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 88),
                  children: [
                    SwitchListTile.adaptive(
                      key: const ValueKey('full-map-filter-stations'),
                      secondary: const Icon(Icons.water_drop_rounded),
                      title: Text(
                        isRo ? 'Stații de monitorizare' : 'Monitoring stations',
                      ),
                      value: draft.stationLayerVisible,
                      onChanged: (value) => setSheetState(
                        () =>
                            draft = draft.copyWith(stationLayerVisible: value),
                      ),
                    ),
                    SwitchListTile.adaptive(
                      key: const ValueKey('full-map-filter-reports'),
                      secondary: const Icon(Icons.campaign_rounded),
                      title: Text(
                        isRo ? 'Rapoarte comunitare' : 'Community reports',
                      ),
                      value: draft.communityReportsVisible,
                      onChanged: (value) => setSheetState(
                        () => draft = draft.copyWith(
                          communityReportsVisible: value,
                        ),
                      ),
                    ),
                    SwitchListTile.adaptive(
                      key: const ValueKey('full-map-filter-favorites'),
                      secondary: const Icon(Icons.bookmark_rounded),
                      title: Text(
                        isRo ? 'Stații favorite' : 'Favorite stations',
                      ),
                      subtitle: !_favoriteStationsService.isAuthenticated
                          ? Text(
                              isRo
                                  ? 'Autentificarea este necesară.'
                                  : 'Sign-in is required.',
                            )
                          : null,
                      value: draft.favoriteStationsVisible,
                      onChanged: !_favoriteStationsService.isAuthenticated
                          ? null
                          : (value) => setSheetState(
                              () => draft = draft.copyWith(
                                favoriteStationsVisible: value,
                              ),
                            ),
                    ),
                    const Divider(height: 24),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: DropdownButtonFormField<double>(
                        key: const ValueKey('full-map-filter-radius'),
                        initialValue: draft.radiusKm,
                        dropdownColor: const Color(0xFF101720),
                        decoration: InputDecoration(
                          labelText: isRo ? 'Rază locală' : 'Local radius',
                        ),
                        items: [
                          for (final radius in const [10.0, 25.0, 50.0, 100.0])
                            DropdownMenuItem(
                              value: radius,
                              child: Text('${radius.toInt()} km'),
                            ),
                          DropdownMenuItem(
                            value: double.infinity,
                            child: Text(isRo ? 'Toată harta' : 'Entire map'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setSheetState(
                            () => draft = draft.copyWith(radiusKm: value),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 18),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        isRo
                            ? 'Categorii rapoarte comunitare'
                            : 'Community report categories',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          FilterChip(
                            key: const ValueKey('full-map-filter-all-reports'),
                            label: Text(isRo ? 'Toate' : 'All'),
                            selected: draft.reportCategories.isEmpty,
                            onSelected: (_) => setSheetState(
                              () => draft = draft.copyWith(
                                reportCategories: const {},
                              ),
                            ),
                          ),
                          for (final category in ReportCategory.values)
                            FilterChip(
                              key: ValueKey(
                                'full-map-filter-report-${category.name}',
                              ),
                              label: Text(
                                MapFeatureRegistry.forReportCategory(
                                  category,
                                  context.l10n,
                                ).label,
                              ),
                              selected: draft.reportCategories.contains(
                                category,
                              ),
                              onSelected: (selected) => setSheetState(() {
                                final categories = <ReportCategory>{
                                  ...draft.reportCategories,
                                };
                                if (selected) {
                                  categories.add(category);
                                } else {
                                  categories.remove(category);
                                }
                                draft = draft.copyWith(
                                  reportCategories: categories,
                                );
                              }),
                            ),
                        ],
                      ),
                    ),
                    const Divider(height: 28),
                    ListTile(
                      key: const ValueKey('full-map-filter-style'),
                      leading: const Icon(Icons.layers_rounded),
                      title: Text(
                        isRo ? 'Stil și strat de bază' : 'Style & base layer',
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => Navigator.of(
                        sheetContext,
                      ).pop(_MapFilterAction.style),
                    ),
                  ],
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                  child: Row(
                    children: [
                      TextButton(
                        key: const ValueKey('full-map-filter-reset'),
                        onPressed: () => setSheetState(
                          () => draft = const _FullMapFilterSelection(),
                        ),
                        child: Text(isRo ? 'Resetează' : 'Reset'),
                      ),
                      const Spacer(),
                      FilledButton(
                        key: const ValueKey('full-map-filter-apply'),
                        onPressed: () => Navigator.of(sheetContext).pop(draft),
                        child: Text(isRo ? 'Aplică' : 'Apply'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted || result == null) return;
    if (result == _MapFilterAction.style) {
      await _openMapStyleSelector();
      return;
    }
    if (result case final _FullMapFilterSelection selection) {
      setState(() {
        _stationLayerVisible = selection.stationLayerVisible;
        _communityReportsVisible = selection.communityReportsVisible;
        _favoriteStationsVisible = selection.favoriteStationsVisible;
        _localRadiusKm = selection.radiusKm;
        _reportCategories = selection.reportCategories;
      });
      await _syncStationAnnotations();
      await _syncReportAnnotations();
    }
  }

  Future<void> _changeMapStyle(
    _FullMapStyle style, {
    bool force = false,
  }) async {
    final mapboxMap = _mapboxMap;
    if (!_canChangeMapStyle || mapboxMap == null) return;
    if (!force && style == _selectedMapStyle) return;
    final styleUri = style.uri;

    setState(() {
      _isChangingMapStyle = true;
      _pendingMapStyle = style;
    });
    _cameraCoordinator.markStyleLoading();

    try {
      _cameraBeforeStyleChange = await mapboxMap.getCameraState();
      await mapboxMap.loadStyleURI(styleUri);
    } catch (_) {
      _cameraCoordinator.markStyleLoaded();
      unawaited(_applyPendingCameraIfReady());
      if (!mounted) {
        _finishStyleChange();
        return;
      }
      setState(_finishStyleChange);
      _showStyleChangeError();
    }
  }

  void _showStyleChangeError() {
    if (!mounted) return;
    final isRomanian = Localizations.localeOf(context).languageCode == 'ro';
    final message = isRomanian
        ? 'Stilul hărții nu a putut fi schimbat.'
        : 'The map style could not be changed.';
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final canonical = ref.watch(currentLocationProvider);
    final deviceLocation = canonical.location;
    if (canonical.hasUsableLocation && deviceLocation != null) {
      _currentLocation = LatLng(
        deviceLocation.latitude,
        deviceLocation.longitude,
      );
      _gpsSpeedKmh = deviceLocation.speedMetersPerSecond == null
          ? null
          : deviceLocation.speedMetersPerSecond! * 3.6;
      _gpsHeadingDegrees = deviceLocation.headingDegrees;
      _locationUnavailableMessage = null;
    }
    final activeTarget = _cameraCoordinator.activeTarget;
    final initialCenter = activeTarget == null
        ? _currentLocation
        : LatLng(activeTarget.latitude, activeTarget.longitude);
    final isRomanian = Localizations.localeOf(context).languageCode == 'ro';

    return Scaffold(
      backgroundColor: const Color(0xFF071217),
      body: SafeArea(
        bottom: widget.includeBottomSafeArea,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final horizontalInset = constraints.biggest.shortestSide >= 600
                ? 24.0
                : 16.0;
            return Stack(
              fit: StackFit.expand,
              children: [
                MapboxMapView(
                  key: const ValueKey('aifishmap-map-page-mapbox'),
                  styleUri: _selectedMapStyle.uri,
                  initialCenter: initialCenter,
                  onMapCreated: _onMapCreated,
                  onStyleLoaded: _onStyleLoaded,
                ),
                Positioned(
                  left: horizontalInset,
                  right: horizontalInset,
                  top: 10,
                  child: Row(
                    children: [
                      if (widget.onBack != null) ...[
                        _MapReviewSquareButton(
                          key: const ValueKey('contextual-map-back'),
                          width: 46,
                          icon: Icons.arrow_back_rounded,
                          tooltip: MaterialLocalizations.of(
                            context,
                          ).backButtonTooltip,
                          onTap: widget.onBack!,
                        ),
                        const SizedBox(width: 10),
                      ],
                      Expanded(
                        child: Material(
                          color: const Color(0xF0071015),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: const BorderSide(color: Color(0xFF253841)),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            key: const ValueKey('figma-full-map-search'),
                            onTap: _openSearch,
                            child: SizedBox(
                              height: 46,
                              child: Row(
                                children: [
                                  const SizedBox(width: 13),
                                  const Icon(
                                    Icons.search_rounded,
                                    color: Color(0xFFF6F9FB),
                                    size: 20,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      isRomanian
                                          ? 'Caută apă, stație, acces…'
                                          : 'Search water, station, access…',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Color(0xFF93A5AF),
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      _MapReviewSquareButton(
                        key: const ValueKey('figma-full-map-layers'),
                        width: 62,
                        icon: _selectedMapStyle.icon,
                        tooltip: isRomanian ? 'Stil hartă' : 'Map style',
                        onTap: _openFilters,
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: horizontalInset,
                  right: horizontalInset,
                  top: 66,
                  child: SizedBox(
                    height: 48,
                    child: Row(
                      children: [
                        _MapReviewFilterChip(
                          width: 64,
                          label: isRomanian ? 'APĂ' : 'WATER',
                          active: _stationLayerVisible,
                          onTap: () {
                            setState(
                              () =>
                                  _stationLayerVisible = !_stationLayerVisible,
                            );
                            unawaited(_syncStationAnnotations());
                          },
                        ),
                        const SizedBox(width: 6),
                        _MapReviewFilterChip(
                          width: 74,
                          label: isRomanian ? 'RAPOARTE' : 'REPORTS',
                          active: _communityReportsVisible,
                          onTap: () {
                            setState(
                              () => _communityReportsVisible =
                                  !_communityReportsVisible,
                            );
                            unawaited(_syncReportAnnotations());
                          },
                        ),
                        const SizedBox(width: 6),
                        _MapReviewFilterChip(
                          width: 74,
                          label: isRomanian ? 'CAPTURI' : 'CATCHES',
                          onTap: () => _showUnavailableMapLayer(
                            isRomanian ? 'Capturi' : 'Catches',
                          ),
                        ),
                        const SizedBox(width: 6),
                        _MapReviewFilterChip(
                          width: 66,
                          label: isRomanian ? 'ACCES' : 'ACCESS',
                          onTap: () => _showUnavailableMapLayer(
                            isRomanian ? 'Acces' : 'Access',
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _MapReviewFilterChip(
                            label: isRomanian ? 'FĂRĂ NET' : 'OFFLINE',
                            onTap: () => _showUnavailableMapLayer(
                              isRomanian ? 'Fără net' : 'Offline',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  right: horizontalInset,
                  top: 110,
                  child: _BoatNavigationHud(
                    speedKmh: _gpsSpeedKmh,
                    headingDegrees: _gpsHeadingDegrees,
                  ),
                ),
                if (_previewStation == null) ...[
                  Positioned(
                    right: horizontalInset,
                    bottom: 118,
                    child: Column(
                      children: [
                        _MapReviewSquareButton(
                          key: const ValueKey('figma-full-map-locate'),
                          icon: Icons.my_location_rounded,
                          tooltip: context.l10n.youAreHere,
                          isLoading: _isLocating,
                          onTap: () => _locateUser(recenter: true),
                        ),
                        const SizedBox(height: 8),
                        _MapReviewSquareButton(
                          key: const ValueKey('figma-full-map-quick-report'),
                          icon: Icons.add_rounded,
                          tooltip: isRomanian ? 'Raport rapid' : 'Quick report',
                          accent: const Color(0xFFF0BD55),
                          onTap: () => widget.onCreateReport(
                            ReportCategory.fishActivity,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned.fill(
                    child: DraggableAskFluviControl(
                      controlKey: const ValueKey('map-ask-fluvi'),
                      scope: AskFluviPlacementScope.fullMap,
                      controlSize: const Size(140, 48),
                      defaultNormalizedPosition: const Offset(0, .76),
                      workspaceBuilder: (size) => Rect.fromLTRB(
                        horizontalInset,
                        120,
                        size.width - horizontalInset,
                        size.height - 16,
                      ),
                      obstaclesBuilder: (size) => <Rect>[
                        Rect.fromLTWH(
                          size.width - horizontalInset - 118,
                          110,
                          118,
                          68,
                        ),
                        Rect.fromLTWH(horizontalInset, 120, 164, 48),
                        Rect.fromLTWH(
                          size.width - horizontalInset - 48,
                          size.height - 222,
                          48,
                          104,
                        ),
                        if (_stationLoadError != null)
                          Rect.fromLTWH(
                            horizontalInset,
                            size.height - 128,
                            size.width - horizontalInset * 2,
                            44,
                          ),
                        if (_locationUnavailableMessage != null)
                          Rect.fromLTWH(
                            horizontalInset,
                            size.height -
                                (_stationLoadError == null ? 128 : 174),
                            size.width - horizontalInset * 2,
                            44,
                          ),
                      ],
                      semanticLabel: isRomanian
                          ? 'Întreabă Fluvi'
                          : 'Ask Fluvi',
                      onTap: () => AppNavigator.open<void>(
                        context,
                        AppDestination.askFluvi,
                      ),
                      child: _MapAskFluviButton(
                        onTap: () => AppNavigator.open<void>(
                          context,
                          AppDestination.askFluvi,
                        ),
                      ),
                    ),
                  ),
                ],
                if (_stationLoadError != null)
                  Positioned(
                    left: horizontalInset,
                    right: horizontalInset,
                    bottom: 84,
                    child: _MapMessage(text: _stationLoadError!),
                  ),
                if (_locationUnavailableMessage != null)
                  Positioned(
                    left: horizontalInset,
                    right: horizontalInset,
                    bottom: _stationLoadError == null ? 84 : 130,
                    child: _MapMessage(text: _locationUnavailableMessage!),
                  ),
                if (_previewStation case final station?)
                  Positioned(
                    left: horizontalInset,
                    right: horizontalInset,
                    bottom: 82,
                    child: FullMapPinPreviewCard(
                      station: station,
                      isFavorite: _favoriteStationIds.contains(station.id),
                      onClose: () => setState(() {
                        _previewStation = null;
                        _temporarilyHighlightedStation = null;
                      }),
                      onDetails: () => _openStation(station),
                      onFavorite: () => _toggleFavorite(station),
                      onAlert: () => AppNavigator.open<void>(
                        context,
                        AppDestination.newAlert,
                        arguments: station,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  static int _mapboxColor(Color color) {
    return ((color.a * 255).round() << 24) |
        ((color.r * 255).round() << 16) |
        ((color.g * 255).round() << 8) |
        (color.b * 255).round();
  }
}

String _boatHeadingLabel(double? degrees) {
  if (degrees == null || !degrees.isFinite) return 'â€”';
  const labels = ['N', 'NE', 'E', 'SE', 'S', 'SV', 'V', 'NV'];
  final normalized = ((degrees % 360) + 360) % 360;
  return labels[((normalized + 22.5) ~/ 45) % labels.length];
}

class _BoatNavigationHud extends StatelessWidget {
  const _BoatNavigationHud({
    required this.speedKmh,
    required this.headingDegrees,
  });

  final double? speedKmh;
  final double? headingDegrees;

  @override
  Widget build(BuildContext context) {
    final speed = speedKmh == null || !speedKmh!.isFinite
        ? 'â€”'
        : speedKmh!.toStringAsFixed(1).replaceAll('.', ',');
    final heading = headingDegrees == null || !headingDegrees!.isFinite
        ? 'â€”'
        : '${headingDegrees!.round()}Â°';
    final live = speedKmh != null || headingDegrees != null;
    return Container(
      key: const ValueKey('figma-full-map-boat-hud'),
      width: 118,
      height: 68,
      padding: const EdgeInsets.fromLTRB(9, 7, 9, 7),
      decoration: BoxDecoration(
        color: const Color(0xEB071015),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xEB253841)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3D000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Transform.rotate(
                angle: .785398,
                child: const Icon(
                  Icons.navigation_rounded,
                  color: Color(0xFF43D9CC),
                  size: 18,
                ),
              ),
              const SizedBox(width: 5),
              Text(
                _boatHeadingLabel(headingDegrees),
                style: const TextStyle(
                  fontFamily: 'IBM Plex Mono',
                  color: Color(0xFF43D9CC),
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  heading,
                  maxLines: 1,
                  overflow: TextOverflow.fade,
                  style: const TextStyle(
                    fontFamily: 'IBM Plex Mono',
                    color: Color(0xFF93A5AF),
                    fontSize: 9,
                  ),
                ),
              ),
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  color: live
                      ? const Color(0xFF34D399)
                      : const Color(0xFF93A5AF),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const Spacer(),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                speed,
                style: const TextStyle(
                  color: Color(0xFFF6F9FB),
                  fontSize: 20,
                  height: 1,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 4),
              const Padding(
                padding: EdgeInsets.only(bottom: 1),
                child: Text(
                  'km/h',
                  style: TextStyle(color: Color(0xFF93A5AF), fontSize: 9.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MapReviewFilterChip extends StatelessWidget {
  const _MapReviewFilterChip({
    required this.label,
    this.width,
    this.active = false,
    this.onTap,
  });

  final String label;
  final double? width;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = active ? const Color(0xFF43D9CC) : const Color(0xFF93A5AF);
    final visual = Container(
      width: width,
      height: 28,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color(0xE60D2025),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color),
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.fade,
        style: TextStyle(
          fontFamily: 'IBM Plex Mono',
          color: color,
          fontSize: 8.5,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
    return Semantics(
      button: onTap != null,
      enabled: onTap != null,
      label: label,
      child: SizedBox(
        width: width,
        height: 48,
        child: Align(
          alignment: Alignment.center,
          child: onTap == null
              ? visual
              : InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: onTap,
                  child: visual,
                ),
        ),
      ),
    );
  }
}

class _MapReviewSquareButton extends StatelessWidget {
  const _MapReviewSquareButton({
    super.key,
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.width = 48,
    this.accent,
    this.isLoading = false,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final double width;
  final Color? accent;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    final color = accent ?? const Color(0xFFF6F9FB);
    return Tooltip(
      message: tooltip,
      child: Semantics(
        button: true,
        enabled: onTap != null,
        label: tooltip,
        child: Material(
          color: const Color(0xF0071015),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: accent ?? const Color(0xFF253841)),
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            child: SizedBox(
              width: width,
              height: 48,
              child: Center(
                child: isLoading
                    ? SizedBox.square(
                        dimension: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: color,
                        ),
                      )
                    : Icon(icon, color: color, size: 22),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MapAskFluviButton extends StatelessWidget {
  const _MapAskFluviButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Semantics(
    button: true,
    label: 'Întreabă Fluvi',
    child: Material(
      color: const Color(0xF0071015),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF43D9CC)),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: const SizedBox(
          width: 140,
          height: 48,
          child: Row(
            children: [
              SizedBox(width: 15),
              Icon(Icons.circle, size: 12, color: Color(0xFF43D9CC)),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Întreabă Fluvi',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Color(0xFFF6F9FB),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(width: 10),
            ],
          ),
        ),
      ),
    ),
  );
}

class FullMapPinPreviewCard extends StatelessWidget {
  const FullMapPinPreviewCard({
    super.key,
    required this.station,
    this.isFavorite = false,
    required this.onClose,
    required this.onDetails,
    required this.onFavorite,
    required this.onAlert,
  });

  final Station station;
  final bool isFavorite;
  final VoidCallback onClose;
  final VoidCallback onDetails;
  final VoidCallback onFavorite;
  final VoidCallback onAlert;

  @override
  Widget build(BuildContext context) {
    final river = station.river.trim();
    return Material(
      key: const ValueKey('full-map-pin-preview'),
      color: const Color(0xF20A1628),
      elevation: 12,
      shadowColor: Colors.black54,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 10, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              station.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),
                          const DecoratedBox(
                            decoration: BoxDecoration(
                              color: Color(0xFF00E676),
                              shape: BoxShape.circle,
                            ),
                            child: SizedBox.square(dimension: 6),
                          ),
                        ],
                      ),
                      if (river.isNotEmpty)
                        Text(
                          river,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFF8DA2B8),
                            fontSize: 11,
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: MaterialLocalizations.of(context).closeButtonTooltip,
                  onPressed: onClose,
                  color: const Color(0xFFF6F9FB),
                  icon: const Icon(Icons.close_rounded, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: Text(
                    station.hasWaterLevel
                        ? '${station.level.toStringAsFixed(0)} ${station.waterLevelUnit}'
                        : 'Nivel indisponibil',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: isFavorite
                      ? 'Elimină din favorite'
                      : 'Adaugă la favorite',
                  onPressed: onFavorite,
                  color: const Color(0xFF43D9CC),
                  icon: Icon(
                    isFavorite
                        ? Icons.favorite_rounded
                        : Icons.favorite_border_rounded,
                  ),
                ),
                IconButton(
                  tooltip: 'Alertă',
                  onPressed: onAlert,
                  color: const Color(0xFF43D9CC),
                  icon: const Icon(Icons.notifications_none_rounded),
                ),
              ],
            ),
            const SizedBox(height: 6),
            OutlinedButton(
              onPressed: onDetails,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFF6F9FB),
                side: const BorderSide(color: Color(0xFF43D9CC)),
              ),
              child: const Text('Vezi detalii'),
            ),
          ],
        ),
      ),
    );
  }
}

enum _MapFilterAction { style }

@immutable
class _FullMapFilterSelection {
  const _FullMapFilterSelection({
    this.stationLayerVisible = true,
    this.communityReportsVisible = true,
    this.favoriteStationsVisible = false,
    this.radiusKm = 100,
    this.reportCategories = const {},
  });

  final bool stationLayerVisible;
  final bool communityReportsVisible;
  final bool favoriteStationsVisible;
  final double radiusKm;
  final Set<ReportCategory> reportCategories;

  _FullMapFilterSelection copyWith({
    bool? stationLayerVisible,
    bool? communityReportsVisible,
    bool? favoriteStationsVisible,
    double? radiusKm,
    Set<ReportCategory>? reportCategories,
  }) => _FullMapFilterSelection(
    stationLayerVisible: stationLayerVisible ?? this.stationLayerVisible,
    communityReportsVisible:
        communityReportsVisible ?? this.communityReportsVisible,
    favoriteStationsVisible:
        favoriteStationsVisible ?? this.favoriteStationsVisible,
    radiusKm: radiusKm ?? this.radiusKm,
    reportCategories: Set.unmodifiable(
      reportCategories ?? this.reportCategories,
    ),
  );
}

class _MapStyleSelector extends StatelessWidget {
  const _MapStyleSelector({
    required this.selectedStyle,
    required this.languageCode,
  });

  final _FullMapStyle selectedStyle;
  final String languageCode;

  @override
  Widget build(BuildContext context) {
    final isRomanian = languageCode == 'ro';
    final title = isRomanian ? 'Stil hartă' : 'Map style';

    return SafeArea(
      top: false,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFF0B141D).withValues(alpha: .98),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: Colors.white.withValues(alpha: .11)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .42),
              blurRadius: 28,
              offset: const Offset(0, -8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .22),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              for (final style in _FullMapStyle.values) ...[
                _MapStyleOption(
                  style: style,
                  label: _styleLabel(style, isRomanian: isRomanian),
                  selected: style == selectedStyle,
                ),
                if (style != _FullMapStyle.values.last)
                  const SizedBox(height: 8),
              ],
            ],
          ),
        ),
      ),
    );
  }

  static String _styleLabel(_FullMapStyle style, {required bool isRomanian}) =>
      switch (style) {
        _FullMapStyle.satellite => isRomanian ? 'Satelit' : 'Satellite',
        _FullMapStyle.standard => 'Standard',
        _FullMapStyle.outdoors => isRomanian ? 'Teren' : 'Outdoors',
        _FullMapStyle.streets => isRomanian ? 'Străzi' : 'Streets',
      };
}

class _MapStyleOption extends StatelessWidget {
  const _MapStyleOption({
    required this.style,
    required this.label,
    required this.selected,
  });

  final _FullMapStyle style;
  final String label;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    const accentColor = Color(0xFF12D8D6);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => Navigator.of(context).pop(style),
        borderRadius: BorderRadius.circular(15),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected
                ? accentColor.withValues(alpha: .11)
                : Colors.white.withValues(alpha: .035),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: selected
                  ? accentColor.withValues(alpha: .42)
                  : Colors.white.withValues(alpha: .09),
            ),
          ),
          child: Row(
            children: [
              Icon(
                style.icon,
                size: 21,
                color: selected ? accentColor : Colors.white70,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: selected ? Colors.white : Colors.white70,
                    fontSize: 14,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Icon(
                selected ? Icons.check_circle_rounded : Icons.circle_outlined,
                size: 20,
                color: selected
                    ? accentColor
                    : Colors.white.withValues(alpha: .28),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MapboxMapView extends StatelessWidget {
  const MapboxMapView({
    super.key,
    required this.styleUri,
    required this.initialCenter,
    required this.onMapCreated,
    required this.onStyleLoaded,
  });

  final String styleUri;
  final LatLng? initialCenter;
  final ValueChanged<mapbox.MapboxMap> onMapCreated;
  final ValueChanged<mapbox.StyleLoadedEventData> onStyleLoaded;

  @override
  Widget build(BuildContext context) {
    return mapbox.MapWidget(
      key: key,
      textureView: true,
      styleUri: styleUri,
      viewport: initialCenter == null
          ? null
          : mapbox.CameraViewportState(
              center: mapbox.Point(
                coordinates: mapbox.Position(
                  initialCenter!.longitude,
                  initialCenter!.latitude,
                ),
              ),
              zoom: 12.5,
            ),
      onMapCreated: onMapCreated,
      onStyleLoadedListener: onStyleLoaded,
    );
  }
}

class _MapMessage extends StatelessWidget {
  const _MapMessage({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFF101720).withValues(alpha: .78),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: .12)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        child: Text(
          text,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white, fontSize: 12),
        ),
      ),
    );
  }
}
