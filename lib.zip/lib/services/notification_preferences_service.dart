import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

enum NotificationCategory {
  waterAlerts('Water Alerts'),
  favoriteStations('Favourite Stations'),
  communityReports('Community Reports'),
  dangerousReports('Dangerous Reports'),
  aiFishingInsights('FluviAI Radar'),
  reputationTrust('Reputation & Trust'),
  achievements('Achievements'),
  catchActivity('Catch Activity');

  const NotificationCategory(this.label);
  final String label;
}

class NotificationPreferences {
  const NotificationPreferences({
    this.enabledCategories = const {
      NotificationCategory.waterAlerts,
      NotificationCategory.favoriteStations,
      NotificationCategory.communityReports,
      NotificationCategory.dangerousReports,
      NotificationCategory.aiFishingInsights,
      NotificationCategory.reputationTrust,
      NotificationCategory.achievements,
      NotificationCategory.catchActivity,
    },
    this.quietHoursEnabled = false,
    this.quietStartMinutes = 22 * 60,
    this.quietEndMinutes = 7 * 60,
    this.groupingEnabled = true,
    this.cooldown = const Duration(hours: 1),
  });

  final Set<NotificationCategory> enabledCategories;
  final bool quietHoursEnabled;
  final int quietStartMinutes;
  final int quietEndMinutes;
  final bool groupingEnabled;
  final Duration cooldown;

  bool isCategoryEnabled(NotificationCategory category) =>
      enabledCategories.contains(category);

  bool isQuietAt(DateTime time) {
    if (!quietHoursEnabled) return false;
    final minute = time.toLocal().hour * 60 + time.toLocal().minute;
    if (quietStartMinutes == quietEndMinutes) return true;
    if (quietStartMinutes < quietEndMinutes) {
      return minute >= quietStartMinutes && minute < quietEndMinutes;
    }
    return minute >= quietStartMinutes || minute < quietEndMinutes;
  }

  DateTime nextQuietEnd(DateTime time) {
    final local = time.toLocal();
    var end = DateTime(
      local.year,
      local.month,
      local.day,
      quietEndMinutes ~/ 60,
      quietEndMinutes % 60,
    );
    if (!end.isAfter(local)) end = end.add(const Duration(days: 1));
    return end;
  }

  NotificationPreferences copyWith({
    Set<NotificationCategory>? enabledCategories,
    bool? quietHoursEnabled,
    int? quietStartMinutes,
    int? quietEndMinutes,
    bool? groupingEnabled,
    Duration? cooldown,
  }) => NotificationPreferences(
    enabledCategories: enabledCategories ?? this.enabledCategories,
    quietHoursEnabled: quietHoursEnabled ?? this.quietHoursEnabled,
    quietStartMinutes: quietStartMinutes ?? this.quietStartMinutes,
    quietEndMinutes: quietEndMinutes ?? this.quietEndMinutes,
    groupingEnabled: groupingEnabled ?? this.groupingEnabled,
    cooldown: cooldown ?? this.cooldown,
  );

  Map<String, dynamic> toJson() => {
    'enabled_categories': enabledCategories
        .map((category) => category.name)
        .toList(),
    'quiet_hours_enabled': quietHoursEnabled,
    'quiet_start_minutes': quietStartMinutes,
    'quiet_end_minutes': quietEndMinutes,
    'grouping_enabled': groupingEnabled,
    'cooldown_minutes': cooldown.inMinutes,
  };

  factory NotificationPreferences.fromJson(Map<String, dynamic> json) {
    final enabledNames =
        (json['enabled_categories'] as List<dynamic>? ?? const [])
            .whereType<String>()
            .toSet();
    final enabled = NotificationCategory.values
        .where((category) => enabledNames.contains(category.name))
        .toSet();
    return NotificationPreferences(
      enabledCategories: enabled,
      quietHoursEnabled: json['quiet_hours_enabled'] == true,
      quietStartMinutes: (json['quiet_start_minutes'] as num?)?.toInt() ?? 1320,
      quietEndMinutes: (json['quiet_end_minutes'] as num?)?.toInt() ?? 420,
      groupingEnabled: json['grouping_enabled'] != false,
      cooldown: Duration(
        minutes: (json['cooldown_minutes'] as num?)?.toInt() ?? 60,
      ),
    );
  }
}

class NotificationPreferencesService {
  static final Map<String, NotificationPreferences> _preferences = {};

  static String _storageKey(String userId) =>
      'notification_preferences.${base64Url.encode(utf8.encode(userId))}';

  static void clearMemoryForTesting() => _preferences.clear();

  NotificationPreferences getForUser(String userId) =>
      _preferences[userId] ?? const NotificationPreferences();

  Future<NotificationPreferences> loadForUser(String userId) async {
    final cached = _preferences[userId];
    if (cached != null) return cached;
    final raw = (await SharedPreferences.getInstance()).getString(
      _storageKey(userId),
    );
    if (raw == null) return const NotificationPreferences();
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) {
        return const NotificationPreferences();
      }
      final preferences = NotificationPreferences.fromJson(decoded);
      _preferences[userId] = preferences;
      return preferences;
    } on FormatException {
      return const NotificationPreferences();
    }
  }

  Future<void> saveForUser(
    String userId,
    NotificationPreferences preferences,
  ) async {
    _preferences[userId] = preferences;
    final storage = await SharedPreferences.getInstance();
    await storage.setString(
      _storageKey(userId),
      jsonEncode(preferences.toJson()),
    );
  }
}
