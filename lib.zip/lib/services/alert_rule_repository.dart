import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

enum AlertRuleKind { levelAbove, levelBelow, rapidChange, communityReport }

class AlertRule {
  const AlertRule({
    required this.id,
    required this.entityId,
    required this.entityLabel,
    required this.kind,
    required this.createdAt,
    this.threshold,
    this.enabled = true,
  });

  final String id;
  final String entityId;
  final String entityLabel;
  final AlertRuleKind kind;
  final DateTime createdAt;
  final double? threshold;
  final bool enabled;

  AlertRule copyWith({
    String? entityLabel,
    AlertRuleKind? kind,
    double? threshold,
    bool? enabled,
  }) => AlertRule(
    id: id,
    entityId: entityId,
    entityLabel: entityLabel ?? this.entityLabel,
    kind: kind ?? this.kind,
    createdAt: createdAt,
    threshold: threshold ?? this.threshold,
    enabled: enabled ?? this.enabled,
  );

  Map<String, Object?> toJson() => {
    'id': id,
    'entityId': entityId,
    'entityLabel': entityLabel,
    'kind': kind.name,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'threshold': threshold,
    'enabled': enabled,
  };

  static AlertRule? fromJson(Object? value) {
    if (value is! Map<String, dynamic>) return null;
    final id = value['id']?.toString();
    final entityId = value['entityId']?.toString();
    final entityLabel = value['entityLabel']?.toString();
    final kindName = value['kind']?.toString();
    final createdAt = DateTime.tryParse(value['createdAt']?.toString() ?? '');
    final kind = AlertRuleKind.values
        .where((candidate) => candidate.name == kindName)
        .firstOrNull;
    if (id == null ||
        entityId == null ||
        entityLabel == null ||
        kind == null ||
        createdAt == null) {
      return null;
    }
    final thresholdValue = value['threshold'];
    return AlertRule(
      id: id,
      entityId: entityId,
      entityLabel: entityLabel,
      kind: kind,
      createdAt: createdAt,
      threshold: thresholdValue is num
          ? thresholdValue.toDouble()
          : double.tryParse(thresholdValue?.toString() ?? ''),
      enabled: value['enabled'] != false,
    );
  }
}

class AlertRuleRepository {
  const AlertRuleRepository();

  static const _storageKey = 'fluviai.alert_rules.v1';

  Future<List<AlertRule>> load() async {
    final preferences = await SharedPreferences.getInstance();
    final encoded = preferences.getString(_storageKey);
    if (encoded == null || encoded.isEmpty) return const [];
    try {
      final decoded = jsonDecode(encoded);
      if (decoded is! List<Object?>) return const [];
      return decoded
          .map(AlertRule.fromJson)
          .whereType<AlertRule>()
          .toList(growable: false);
    } on FormatException {
      return const [];
    }
  }

  Future<void> save(AlertRule rule) async {
    final rules = [...await load()];
    final index = rules.indexWhere((candidate) => candidate.id == rule.id);
    if (index >= 0) {
      rules[index] = rule;
    } else {
      rules.insert(0, rule);
    }
    await _write(rules);
  }

  Future<void> remove(String id) async {
    final rules = [...await load()]..removeWhere((rule) => rule.id == id);
    await _write(rules);
  }

  Future<void> _write(List<AlertRule> rules) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      _storageKey,
      jsonEncode(rules.map((rule) => rule.toJson()).toList()),
    );
  }
}
