import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/context/selected_context.dart';
import '../../../core/navigation/app_destination.dart';
import '../../../core/navigation/app_navigator.dart';
import '../../../core/theme/fluviai_commercial_tokens.dart';
import '../../../core/utility/fluviai_utility_registry.dart';
import '../../../features/commercial_home/data/commercial_home_data_source.dart';
import '../../../models/station.dart';
import '../../../services/water_service.dart';

class FluviAIUtilitiesHubPage extends ConsumerStatefulWidget {
  const FluviAIUtilitiesHubPage({
    super.key,
    required this.onSelectMainTab,
    this.dataSource,
  });

  final ValueChanged<int> onSelectMainTab;
  final CommercialHomeDataSource? dataSource;

  @override
  ConsumerState<FluviAIUtilitiesHubPage> createState() =>
      _FluviAIUtilitiesHubPageState();
}

class _FluviAIUtilitiesHubPageState
    extends ConsumerState<FluviAIUtilitiesHubPage> {
  final TextEditingController _searchController = TextEditingController();
  final WaterService _waterService = WaterService();
  String _query = '';
  bool _showAll = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Station? _stationArgument(SelectedContext? selected) {
    final stationId = selected?.stationId;
    final latitude = selected?.latitude;
    final longitude = selected?.longitude;
    if (stationId == null || latitude == null || longitude == null) {
      return null;
    }

    final selectedStation = _waterService.selectedStation;
    if (selectedStation?.id == stationId) return selectedStation;
    final automaticStation = _waterService.lastAutomaticStation;
    if (automaticStation?.id == stationId) return automaticStation;

    return Station(
      id: stationId,
      name: selected?.stationName ?? selected?.primaryLabel ?? stationId,
      river: selected?.riverName ?? selected?.waterName ?? '',
      level: double.nan,
      trend: WaterTrend.stable,
      latitude: latitude,
      longitude: longitude,
      lastUpdate: DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
      hasWaterLevel: false,
      hasKnownTrend: false,
      waterLevelSource: selected?.source ?? 'Selected context',
    );
  }

  FluviUtilityDefinition? _utility(String id) {
    for (final utility in FluviUtilityRegistry.definitions) {
      if (utility.id == id) return utility;
    }
    return null;
  }

  void _open(FluviUtilityDefinition utility) {
    if (const <String>{
      'map.access',
      'journal.bite-effort',
      'safety.ready-to-fish',
      'safety.check-in',
      'fluvi.vision',
    }.contains(utility.id)) {
      unawaited(_showUnavailable(utility.title(false)));
      return;
    }
    if (utility.id == 'catches.add') {
      unawaited(_openCatchUtility());
      return;
    }
    if (utility.destination == AppDestination.home) {
      widget.onSelectMainTab(0);
      return;
    }

    final station = _stationArgument(ref.read(selectedContextProvider));
    if (utility.destination == AppDestination.map && station == null) {
      widget.onSelectMainTab(1);
      return;
    }

    final carriesStation =
        utility.destination == AppDestination.map ||
        utility.destination == AppDestination.water ||
        utility.destination == AppDestination.weather ||
        utility.destination == AppDestination.fluvi;
    unawaited(
      AppNavigator.open<void>(
        context,
        utility.destination,
        arguments: carriesStation ? station : null,
        dataSource: widget.dataSource,
      ),
    );
  }

  Future<void> _showUnavailable(String title) => showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(title),
      content: const Text(
        'This utility is not connected to a production data source yet.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('Close'),
        ),
      ],
    ),
  );

  void _openUtilityId(String id) {
    final utility = _utility(id);
    if (utility != null) _open(utility);
  }

  Future<void> _openCatchUtility() async {
    await AppNavigator.open<bool>(context, AppDestination.addCatch);
  }

  @override
  Widget build(BuildContext context) {
    final isRomanian =
        Localizations.localeOf(context).languageCode.toLowerCase() == 'ro';
    String copy(String ro, String en) => isRomanian ? ro : en;
    final accessTier = ref.watch(fluviAccessTierProvider);
    final results = FluviUtilityRegistry.search(_query, isRomanian: isRomanian);
    final showRegistry = _showAll || _query.trim().isNotEmpty;
    final largeText = MediaQuery.textScalerOf(context).scale(1) >= 1.5;

    return Material(
      key: const ValueKey('utilities-hub-page'),
      color: FluviAICommercialTokens.background,
      child: SafeArea(
        bottom: false,
        child: CustomScrollView(
          key: const PageStorageKey<String>('utilities-hub-scroll'),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
              sliver: SliverToBoxAdapter(
                child: _UtilitiesHeader(
                  title: copy('Utilități', 'Utilities'),
                  subtitle: copy(
                    'Apele tale, jurnal, hărți și setări',
                    'Your waters, journal, maps and settings',
                  ),
                  onNotifications: () => AppNavigator.open<void>(
                    context,
                    AppDestination.notificationPreferences,
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              sliver: SliverToBoxAdapter(
                child: _UtilitySearchBar(
                  controller: _searchController,
                  hint: copy(
                    'Caută utilități și setări',
                    'Search utilities and settings',
                  ),
                  query: _query,
                  onChanged: (value) => setState(() => _query = value),
                  onClear: () {
                    _searchController.clear();
                    setState(() => _query = '');
                  },
                  onAll: () => setState(() => _showAll = !_showAll),
                  allActive: _showAll,
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
              sliver: SliverToBoxAdapter(
                child: _UtilitiesSectionLabel(copy('UTILITĂȚI', 'UTILITIES')),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  mainAxisExtent: largeText ? 132 : 92,
                ),
                delegate: SliverChildListDelegate.fixed([
                  _ApprovedUtilityCard(
                    keyName: 'utility-account.profile',
                    icon: Icons.person_outline_rounded,
                    iconColor: FluviAICommercialTokens.brandFocus,
                    title: copy('Profil', 'Profile'),
                    subtitle: copy(
                      'Cont, confidențialitate și abonament',
                      'Account, privacy and subscription',
                    ),
                    onTap: () => _openUtilityId('account.profile'),
                  ),
                  _ApprovedUtilityCard(
                    keyName: 'utility-favorites.my-waters',
                    icon: Icons.favorite_border_rounded,
                    iconColor: FluviAICommercialTokens.brandFocus,
                    title: copy('Apele mele', 'My waters'),
                    subtitle: copy(
                      'Favorite și monitorizare',
                      'Favorites and monitoring',
                    ),
                    onTap: () => _openUtilityId('favorites.my-waters'),
                  ),
                  _ApprovedUtilityCard(
                    keyName: 'utility-journal.sessions',
                    icon: Icons.set_meal_outlined,
                    iconColor: FluviAICommercialTokens.waterStable,
                    title: copy('Capturi & jurnal', 'Catches & journal'),
                    subtitle: copy(
                      'Capturi și rapoarte personale',
                      'Personal catches and reports',
                    ),
                    onTap: () => _openUtilityId('journal.sessions'),
                  ),
                  _ApprovedUtilityCard(
                    keyName: 'utility-offline-maps',
                    icon: Icons.map_outlined,
                    iconColor: FluviAICommercialTokens.textSecondary,
                    title: copy('Hărți fără conexiune', 'Offline maps'),
                    subtitle: copy(
                      'Indisponibil în această versiune',
                      'Unavailable in this version',
                    ),
                    badge: accessTier == FluviAccessTier.premium ? null : 'PRO',
                    onTap: () => _showUnavailable(
                      copy('Hărți fără conexiune', 'Offline maps'),
                    ),
                  ),
                  _ApprovedUtilityCard(
                    keyName: 'utility-rules.permits',
                    icon: Icons.shield_outlined,
                    iconColor: FluviAICommercialTokens.textSecondary,
                    title: copy('Reguli & permise', 'Rules & permits'),
                    subtitle: copy(
                      'Siguranță și documente',
                      'Safety and documents',
                    ),
                    onTap: () => _openUtilityId('rules.permits'),
                  ),
                  _ApprovedUtilityCard(
                    keyName: 'utility-notification-settings',
                    icon: Icons.notifications_none_rounded,
                    iconColor: FluviAICommercialTokens.textPrimary,
                    title: copy('Setări notificări', 'Notification settings'),
                    subtitle: copy(
                      'Alerte, rază și Nu deranja',
                      'Alerts, radius and Do Not Disturb',
                    ),
                    onTap: () => AppNavigator.open<void>(
                      context,
                      AppDestination.notificationPreferences,
                    ),
                  ),
                ]),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              sliver: SliverToBoxAdapter(
                child: _SettingsAndHelpCard(
                  title: copy(
                    'Setări aplicație & ajutor',
                    'App settings & help',
                  ),
                  subtitle: copy(
                    'Limbă, aspect, ajutor, legal și despre',
                    'Language, appearance, help, legal and about',
                  ),
                  onTap: () =>
                      AppNavigator.open<void>(context, AppDestination.settings),
                ),
              ),
            ),
            if (showRegistry) ...[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
                sliver: SliverToBoxAdapter(
                  child: _UtilitiesSectionLabel(
                    copy('REGISTRU COMPLET', 'ALL TOOLS'),
                  ),
                ),
              ),
              if (results.isEmpty)
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(
                    child: _UtilitiesEmpty(
                      title: copy('Nicio utilitate găsită', 'No utility found'),
                      subtitle: copy(
                        'Încearcă alt termen sau șterge filtrul.',
                        'Try another term or clear the filter.',
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate((context, childIndex) {
                      if (childIndex.isOdd) {
                        return const SizedBox(height: 8);
                      }
                      final utility = results[childIndex ~/ 2];
                      return _RegistryUtilityTile(
                        utility: utility,
                        isRomanian: isRomanian,
                        onTap: () => _open(utility),
                      );
                    }, childCount: results.length * 2 - 1),
                  ),
                ),
            ],
            const SliverToBoxAdapter(child: SizedBox(height: 96)),
          ],
        ),
      ),
    );
  }
}

class _UtilitiesHeader extends StatelessWidget {
  const _UtilitiesHeader({
    required this.title,
    required this.subtitle,
    required this.onNotifications,
  });

  final String title;
  final String subtitle;
  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: FluviAICommercialTokens.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: const TextStyle(
                color: FluviAICommercialTokens.textSecondary,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
      const SizedBox(width: 12),
      SizedBox.square(
        dimension: 44,
        child: Material(
          color: const Color(0xFF101C22),
          borderRadius: BorderRadius.circular(14),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onNotifications,
            child: const Icon(
              Icons.notifications_none_rounded,
              color: FluviAICommercialTokens.textPrimary,
              size: 20,
            ),
          ),
        ),
      ),
    ],
  );
}

class _UtilitySearchBar extends StatelessWidget {
  const _UtilitySearchBar({
    required this.controller,
    required this.hint,
    required this.query,
    required this.onChanged,
    required this.onClear,
    required this.onAll,
    required this.allActive,
  });

  final TextEditingController controller;
  final String hint;
  final String query;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;
  final VoidCallback onAll;
  final bool allActive;

  @override
  Widget build(BuildContext context) => Container(
    height: 46,
    decoration: BoxDecoration(
      color: const Color(0xFF101C22),
      borderRadius: BorderRadius.circular(15),
      border: Border.all(color: FluviAICommercialTokens.border),
    ),
    child: Row(
      children: [
        const SizedBox(width: 12),
        const Icon(
          Icons.search_rounded,
          color: FluviAICommercialTokens.textPrimary,
          size: 21,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: TextField(
            key: const ValueKey('utilities-search-field'),
            controller: controller,
            onChanged: onChanged,
            style: const TextStyle(
              color: FluviAICommercialTokens.textPrimary,
              fontSize: 12,
            ),
            decoration: InputDecoration(
              isDense: true,
              hintText: hint,
              hintStyle: const TextStyle(
                color: FluviAICommercialTokens.textSecondary,
                fontSize: 12,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
              suffixIcon: query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: onClear,
                      icon: const Icon(Icons.close_rounded, size: 17),
                    ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        SizedBox(
          height: 46,
          width: 90,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              key: const ValueKey('utilities-all-tools'),
              onTap: onAll,
              borderRadius: BorderRadius.circular(12),
              child: Center(
                child: Container(
                  height: 30,
                  width: 68,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: allActive
                        ? FluviAICommercialTokens.brandFocus.withValues(
                            alpha: .22,
                          )
                        : const Color(0xFF123C3B),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: FluviAICommercialTokens.brandFocus.withValues(
                        alpha: .35,
                      ),
                    ),
                  ),
                  child: const Text(
                    'TOATE',
                    style: TextStyle(
                      color: FluviAICommercialTokens.brandFocus,
                      fontFamily: FluviAICommercialTokens.monoFontFamily,
                      fontSize: 9,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

class _UtilitiesSectionLabel extends StatelessWidget {
  const _UtilitiesSectionLabel(this.label);

  final String label;

  @override
  Widget build(BuildContext context) => Text(
    label,
    style: const TextStyle(
      color: FluviAICommercialTokens.textSecondary,
      fontFamily: FluviAICommercialTokens.monoFontFamily,
      fontSize: 9,
      fontWeight: FontWeight.w500,
    ),
  );
}

class _ApprovedUtilityCard extends StatelessWidget {
  const _ApprovedUtilityCard({
    required this.keyName,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badge,
  });

  final String keyName;
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) => Material(
    key: ValueKey(keyName),
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(17),
    clipBehavior: Clip.antiAlias,
    child: Ink(
      decoration: BoxDecoration(
        color: const Color(0xFF0D171C),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: FluviAICommercialTokens.border),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 11, 13, 9),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: iconColor, size: 21),
                  const Spacer(),
                  if (badge != null)
                    Container(
                      height: 22,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFF17140D),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: FluviAICommercialTokens.premium,
                        ),
                      ),
                      child: Text(
                        badge!,
                        style: const TextStyle(
                          color: FluviAICommercialTokens.premium,
                          fontFamily: FluviAICommercialTokens.monoFontFamily,
                          fontSize: 8.5,
                        ),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FluviAICommercialTokens.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FluviAICommercialTokens.textMuted,
                  fontSize: 9.5,
                  height: 1.1,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class _SettingsAndHelpCard extends StatelessWidget {
  const _SettingsAndHelpCard({
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(16),
    clipBehavior: Clip.antiAlias,
    child: Ink(
      decoration: BoxDecoration(
        color: const Color(0xFF101C22),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FluviAICommercialTokens.border),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: FluviAICommercialTokens.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: FluviAICommercialTokens.textMuted,
                        fontSize: 9.5,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: FluviAICommercialTokens.brandFocus,
                size: 18,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class _RegistryUtilityTile extends StatelessWidget {
  const _RegistryUtilityTile({
    required this.utility,
    required this.isRomanian,
    required this.onTap,
  });

  final FluviUtilityDefinition utility;
  final bool isRomanian;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(15),
    clipBehavior: Clip.antiAlias,
    child: Ink(
      decoration: BoxDecoration(
        color: const Color(0xFF0D171C),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: FluviAICommercialTokens.border),
      ),
      child: InkWell(
        key: ValueKey('utility-${utility.id}'),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
          child: Row(
            children: [
              Icon(
                utility.icon,
                color: FluviAICommercialTokens.brandFocus,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      utility.title(isRomanian),
                      style: const TextStyle(
                        color: FluviAICommercialTokens.textPrimary,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      utility.subtitle(isRomanian),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: FluviAICommercialTokens.textMuted,
                        fontSize: 9.5,
                        height: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: FluviAICommercialTokens.textMuted,
                size: 18,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class _UtilitiesEmpty extends StatelessWidget {
  const _UtilitiesEmpty({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFF0D171C),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: FluviAICommercialTokens.border),
    ),
    child: Column(
      children: [
        const Icon(
          Icons.search_off_rounded,
          color: FluviAICommercialTokens.textMuted,
          size: 30,
        ),
        const SizedBox(height: 10),
        Text(
          title,
          style: const TextStyle(
            color: FluviAICommercialTokens.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: FluviAICommercialTokens.textSecondary,
            fontSize: 10,
          ),
        ),
      ],
    ),
  );
}
