import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/context/current_location.dart';
import '../../../core/context/selected_context.dart';
import '../../../core/localization/locale_controller.dart';
import '../../../core/navigation/app_destination.dart';
import '../../../core/navigation/app_navigator.dart';
import '../../../core/navigation/map_entry.dart';
import '../../../core/theme/fluviai_commercial_tokens.dart';
import '../../../core/theme/theme_controller.dart';
import '../../../models/station.dart';
import '../../../services/alert_rule_repository.dart';
import '../../../services/auth_service.dart';
import '../../../services/billing_repository.dart';
import '../../../services/favorite_stations_service.dart';
import '../../../services/reputation_service.dart';
import '../../../services/water_service.dart';
import '../../../widgets/fluviai/draggable_ask_fluvi.dart';
import 'figma_foundation.dart';

String _countryLabel(String? countryCode) =>
    switch (countryCode?.toUpperCase()) {
      'RO' => 'România',
      'GB' || 'UK' => 'Regatul Unit',
      final code? when code.isNotEmpty => code,
      _ => 'Automat',
    };

String _countryFlag(String? countryCode) =>
    switch (countryCode?.toUpperCase()) {
      'RO' => '🇷🇴',
      'GB' || 'UK' => '🇬🇧',
      _ => '🌍',
    };

Future<void> _showFigmaInfo(
  BuildContext context, {
  required String title,
  required String message,
}) => showDialog<void>(
  context: context,
  builder: (dialogContext) => AlertDialog(
    backgroundColor: FigmaFluviTokens.surface,
    title: Text(title),
    content: Text(message),
    actions: [
      TextButton(
        onPressed: () => Navigator.of(dialogContext).pop(),
        child: const Text('Închide'),
      ),
    ],
  ),
);

class FigmaFavoritesPage extends StatefulWidget {
  const FigmaFavoritesPage({
    super.key,
    this.favoritesService = const FavoriteStationsService(),
    this.waterService,
  });

  final FavoriteStationsService favoritesService;
  final WaterService? waterService;

  @override
  State<FigmaFavoritesPage> createState() => _FigmaFavoritesPageState();
}

class _FigmaFavoritesPageState extends State<FigmaFavoritesPage> {
  late final WaterService _waterService;
  late Future<List<Station>> _future;
  int _tab = 2;

  @override
  void initState() {
    super.initState();
    _waterService = widget.waterService ?? WaterService();
    _future = _load();
  }

  Future<List<Station>> _load() async {
    if (!widget.favoritesService.isAuthenticated) return const [];
    final ids = await widget.favoritesService.getFavoriteIds();
    final stations = await _waterService.getStations();
    return stations
        .where((station) => ids.contains(station.id))
        .toList(growable: false);
  }

  Future<void> _refresh() async {
    final next = _load();
    if (!mounted) return;
    setState(() {
      _future = next;
    });
    try {
      await next;
    } on Exception {
      // FutureBuilder displays the real failure.
    }
  }

  Future<void> _remove(Station station) async {
    try {
      await widget.favoritesService.setFavorite(station.id, favorite: false);
      await _refresh();
    } on FavoriteException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-favorites-page'),
      title: 'Favorite',
      eyebrow: 'APELE ȘI LOCURILE TALE',
      showBack: true,
      action: FigmaRoundButton(
        icon: Icons.edit_outlined,
        tooltip: 'Editează',
        onPressed: () => _showFigmaInfo(
          context,
          title: 'Editează favoritele',
          message:
              'Folosește steaua fiecărei stații pentru a o elimina. Nicio modificare nu este aplicată fără acțiunea ta.',
        ),
      ),
      padding: EdgeInsets.zero,
      child: FutureBuilder<List<Station>>(
        future: _future,
        builder: (context, state) {
          final stations = state.data ?? const <Station>[];
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              children: [
                Row(
                  children: [
                    FigmaPill(
                      label: 'Ape',
                      active: _tab == 0,
                      onTap: () => setState(() => _tab = 0),
                    ),
                    const SizedBox(width: 8),
                    FigmaPill(
                      label: 'Locuri',
                      active: _tab == 1,
                      onTap: () => setState(() => _tab = 1),
                    ),
                    const SizedBox(width: 8),
                    FigmaPill(
                      label: 'Stații',
                      active: _tab == 2,
                      onTap: () => setState(() => _tab = 2),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (_tab != 2)
                  FigmaTruthfulEmpty(
                    key: const ValueKey('favorites-unsupported-collection'),
                    icon: Icons.bookmark_border_rounded,
                    title: _tab == 0
                        ? 'Favorite pentru ape indisponibile'
                        : 'Locuri salvate indisponibile',
                    message: _tab == 0
                        ? 'Sursa curentă salvează numai stații. Nu afișăm ape inventate.'
                        : 'Salvarea locurilor nu este conectată. Nu afișăm locuri inventate.',
                  )
                else if (state.connectionState == ConnectionState.waiting &&
                    !state.hasData)
                  const Center(child: CircularProgressIndicator(strokeWidth: 2))
                else if (state.hasError)
                  FigmaTruthfulEmpty(
                    icon: Icons.cloud_off_rounded,
                    title: 'Favorite indisponibile',
                    message: 'Verifică sesiunea și conexiunea.',
                    actionLabel: 'Reîncearcă',
                    onAction: _refresh,
                  )
                else if (stations.isEmpty)
                  FigmaTruthfulEmpty(
                    icon: Icons.star_border_rounded,
                    title: 'Nicio stație favorită',
                    message: widget.favoritesService.isAuthenticated
                        ? 'Salvează o stație reală din harta completă.'
                        : 'Autentificarea este necesară pentru favorite.',
                    actionLabel: 'Deschide harta',
                    onAction: () => AppNavigator.open(
                      context,
                      AppDestination.contextualMap,
                      arguments: ContextualMapEntry.browse(
                        source: 'favorites-empty',
                      ),
                    ),
                  )
                else
                  for (var index = 0; index < stations.length; index++) ...[
                    _FavoriteStationCard(
                      station: stations[index],
                      onRemove: () => _remove(stations[index]),
                    ),
                    if (index != stations.length - 1)
                      const SizedBox(height: 10),
                  ],
                const SizedBox(height: 14),
                Center(
                  child: TextButton.icon(
                    onPressed: _tab == 2
                        ? () => AppNavigator.open(
                            context,
                            AppDestination.contextualMap,
                            arguments: ContextualMapEntry.browse(
                              source: 'favorites-add-station',
                            ),
                          )
                        : () => _showFigmaInfo(
                            context,
                            title: _tab == 0
                                ? 'Favorite pentru ape'
                                : 'Locuri salvate',
                            message: _tab == 0
                                ? 'Sursa curentă poate salva numai stații din hartă.'
                                : 'Salvarea locurilor nu este conectată în această versiune.',
                          ),
                    icon: const Icon(Icons.add_rounded),
                    label: Text(
                      _tab == 2
                          ? 'Adaugă stație din hartă'
                          : _tab == 0
                          ? 'Favorite pentru ape'
                          : 'Locuri salvate',
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _FavoriteStationCard extends StatelessWidget {
  const _FavoriteStationCard({required this.station, required this.onRemove});

  final Station station;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final hasLevel = station.hasWaterLevel && station.level.isFinite;
    final trendColor = !station.hasKnownTrend
        ? FigmaFluviTokens.textMuted
        : switch (station.trend) {
            WaterTrend.rising => const Color(0xFF29B6F6),
            WaterTrend.falling => FigmaFluviTokens.red,
            WaterTrend.stable => FigmaFluviTokens.green,
          };
    return FigmaSurface(
      onTap: () =>
          AppNavigator.open(context, AppDestination.water, arguments: station),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  station.river.trim().isEmpty
                      ? station.name
                      : '${station.name} · ${station.river}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: FigmaFluviTokens.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Elimină din favorite',
                onPressed: onRemove,
                icon: const Icon(
                  Icons.star_rounded,
                  color: FigmaFluviTokens.cyan,
                  size: 20,
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                hasLevel
                    ? '${station.level.toStringAsFixed(0)} ${station.waterLevelUnit}'
                    : 'Date indisponibile',
                style: TextStyle(
                  color: hasLevel
                      ? FigmaFluviTokens.white
                      : FigmaFluviTokens.textMuted,
                  fontSize: hasLevel ? 24 : 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const Spacer(),
              FigmaStatusDot(
                label: station.hasKnownTrend
                    ? station.trendText
                    : 'TREND NECUNOSCUT',
                color: trendColor,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              TextButton.icon(
                onPressed: () => AppNavigator.open(
                  context,
                  AppDestination.contextualMap,
                  arguments: ContextualMapEntry.forStation(
                    source: 'favorite-station',
                    station: station,
                  ),
                ),
                icon: const Icon(Icons.location_on_outlined, size: 16),
                label: const Text('Vezi harta'),
              ),
              const Spacer(),
              Text(
                station.waterLevelSource,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: figmaBody(size: 9),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class FigmaAlertsPage extends StatefulWidget {
  const FigmaAlertsPage({
    super.key,
    this.repository = const AlertRuleRepository(),
  });

  final AlertRuleRepository repository;

  @override
  State<FigmaAlertsPage> createState() => _FigmaAlertsPageState();
}

class _FigmaAlertsPageState extends State<FigmaAlertsPage> {
  late Future<List<AlertRule>> _future;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _future = widget.repository.load();
  }

  Future<void> _reload() async {
    final next = widget.repository.load();
    if (!mounted) return;
    setState(() {
      _future = next;
    });
    try {
      await next;
    } on Exception {
      // FutureBuilder renders the repository failure.
    }
  }

  Future<void> _toggle(AlertRule rule, bool enabled) async {
    await widget.repository.save(rule.copyWith(enabled: enabled));
    if (!mounted) return;
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-alerts-page'),
      title: 'Alerte și notificări',
      eyebrow: 'MONITORIZARE',
      action: FigmaRoundButton(
        key: const ValueKey('alerts-open-settings'),
        icon: Icons.settings_outlined,
        tooltip: 'Setări notificări',
        onPressed: () =>
            AppNavigator.open(context, AppDestination.notificationPreferences),
      ),
      padding: EdgeInsets.zero,
      child: FutureBuilder<List<AlertRule>>(
        future: _future,
        builder: (context, state) {
          final rules = state.data ?? const <AlertRule>[];
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
            children: [
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  FigmaPill(
                    label: 'Active',
                    active: _tab == 0,
                    onTap: () => setState(() => _tab = 0),
                  ),
                  FigmaPill(
                    label: 'Regulile mele',
                    active: _tab == 1,
                    onTap: () => setState(() => _tab = 1),
                  ),
                  FigmaPill(
                    label: 'Istoric',
                    active: _tab == 2,
                    onTap: () => setState(() => _tab = 2),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              FigmaSectionLabel(_tab == 2 ? 'Istoric' : 'Reguli locale'),
              const SizedBox(height: 10),
              if (state.connectionState == ConnectionState.waiting &&
                  !state.hasData)
                const Center(child: CircularProgressIndicator(strokeWidth: 2))
              else if (_tab == 2)
                const FigmaTruthfulEmpty(
                  icon: Icons.history_rounded,
                  title: 'Istoric indisponibil',
                  message:
                      'Evenimentele de alertă vor apărea numai după conectarea serviciului de notificări.',
                )
              else if (rules.isEmpty)
                FigmaTruthfulEmpty(
                  icon: Icons.notifications_active_outlined,
                  title: 'Nicio regulă creată',
                  message: 'Creează o alertă pentru o apă sau stație reală.',
                  actionLabel: 'Adaugă alertă',
                  onAction: () =>
                      AppNavigator.open(context, AppDestination.newAlert),
                )
              else
                for (var index = 0; index < rules.length; index++) ...[
                  _AlertRuleCard(
                    rule: rules[index],
                    onChanged: (value) => _toggle(rules[index], value),
                  ),
                  if (index != rules.length - 1) const SizedBox(height: 10),
                ],
              const SizedBox(height: 18),
              FigmaPrimaryButton(
                label: 'Adaugă alertă',
                icon: Icons.add_alert_rounded,
                secondary: true,
                onPressed: () =>
                    AppNavigator.open(context, AppDestination.newAlert),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _AlertRuleCard extends StatelessWidget {
  const _AlertRuleCard({required this.rule, required this.onChanged});

  final AlertRule rule;
  final ValueChanged<bool> onChanged;

  String get _description => switch (rule.kind) {
    AlertRuleKind.levelAbove =>
      'Nivel peste ${rule.threshold?.toStringAsFixed(0) ?? '—'} cm',
    AlertRuleKind.levelBelow =>
      'Nivel sub ${rule.threshold?.toStringAsFixed(0) ?? '—'} cm',
    AlertRuleKind.rapidChange =>
      'Schimbare rapidă ${rule.threshold?.toStringAsFixed(0) ?? '—'} cm/24h',
    AlertRuleKind.communityReport => 'Raport comunitate în zonă',
  };

  @override
  Widget build(BuildContext context) {
    return FigmaSurface(
      accent: rule.enabled
          ? FigmaFluviTokens.amber
          : FigmaFluviTokens.textMuted,
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: FigmaFluviTokens.amber.withValues(alpha: .12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.notifications_active_outlined,
              color: FigmaFluviTokens.amber,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  rule.entityLabel,
                  style: const TextStyle(
                    color: FigmaFluviTokens.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(_description, style: figmaBody(size: 10)),
              ],
            ),
          ),
          Switch(value: rule.enabled, onChanged: onChanged),
        ],
      ),
    );
  }
}

class FigmaNotificationCenterPage extends StatelessWidget {
  const FigmaNotificationCenterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-notification-center'),
      title: 'Notificări',
      eyebrow: 'CENTRU',
      action: FigmaRoundButton(
        icon: Icons.tune_rounded,
        tooltip: 'Preferințe',
        onPressed: () =>
            AppNavigator.open(context, AppDestination.notificationPreferences),
      ),
      child: const FigmaTruthfulEmpty(
        icon: Icons.notifications_none_rounded,
        title: 'Nicio notificare disponibilă',
        message:
            'Centrul rămâne gol până când serviciul real livrează evenimente.',
      ),
    );
  }
}

class FigmaRegulationsPage extends StatefulWidget {
  const FigmaRegulationsPage({super.key, this.initialTab = 1});

  final int initialTab;

  @override
  State<FigmaRegulationsPage> createState() => _FigmaRegulationsPageState();
}

class _FigmaRegulationsPageState extends State<FigmaRegulationsPage> {
  late int _tab;

  @override
  void initState() {
    super.initState();
    _tab = widget.initialTab;
  }

  @override
  Widget build(BuildContext context) {
    final title = switch (_tab) {
      0 => 'Permis',
      1 => 'Reglementări',
      _ => 'Siguranță',
    };
    final selected = ProviderScope.containerOf(
      context,
    ).read(selectedContextProvider);
    final countryLabel = _countryLabel(selected?.countryCode);
    final countryFlag = _countryFlag(selected?.countryCode);
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-regulations-page'),
      title: 'Permis, reguli și siguranță',
      eyebrow: countryLabel.toUpperCase(),
      padding: EdgeInsets.zero,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        children: [
          FigmaSurface(
            onTap: () => _showFigmaInfo(
              context,
              title: 'Țara conținutului',
              message:
                  'Pachetul de conținut este selectat din contextul aplicației. Schimbarea țării se face din Setări.',
            ),
            child: Row(
              children: [
                Text(countryFlag, style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    countryLabel,
                    style: const TextStyle(
                      color: FigmaFluviTokens.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FigmaFluviTokens.textSecondary,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FigmaPill(
                  label: 'Permis',
                  active: _tab == 0,
                  onTap: () => setState(() => _tab = 0),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: FigmaPill(
                  label: 'Reglementări',
                  active: _tab == 1,
                  onTap: () => setState(() => _tab = 1),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: FigmaPill(
                  label: 'Siguranță',
                  active: _tab == 2,
                  onTap: () => setState(() => _tab = 2),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          FigmaSurface(
            accent: FigmaFluviTokens.amber,
            child: Text(
              'Verifică întotdeauna sursa oficială înainte de pescuit. FluviAI nu afișează date juridice neverificate.',
              style: figmaBody(
                color: FigmaFluviTokens.amber,
                size: 10,
                weight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 18),
          FigmaSectionLabel(title),
          const SizedBox(height: 10),
          if (_tab == 0)
            const _PermitContent()
          else if (_tab == 1)
            const _RegulationsContent()
          else
            const _SafetyContent(),
        ],
      ),
    );
  }
}

class _PermitContent extends StatelessWidget {
  const _PermitContent();

  @override
  Widget build(BuildContext context) => const FigmaTruthfulEmpty(
    icon: Icons.badge_outlined,
    title: 'Permisul nu este conectat',
    message:
        'Valabilitatea și emitentul vor fi afișate numai din sursa oficială.',
  );
}

class _RegulationsContent extends StatelessWidget {
  const _RegulationsContent();

  @override
  Widget build(BuildContext context) {
    const species = ['Știucă', 'Șalău', 'Crap', 'Somn', 'Clean'];
    return FigmaSurface(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline_rounded,
                  color: FigmaFluviTokens.amber,
                  size: 18,
                ),
                SizedBox(width: 9),
                Expanded(
                  child: Text(
                    'Datele oficiale de prohibiție și limite sunt indisponibile.',
                    style: TextStyle(
                      color: FigmaFluviTokens.textSecondary,
                      fontSize: 11,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const FigmaDivider(),
          for (final item in species) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      item,
                      style: const TextStyle(
                        color: FigmaFluviTokens.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const FigmaPill(label: 'LUNGIME —'),
                  const SizedBox(width: 6),
                  const FigmaPill(label: 'LIMITĂ —', active: true),
                ],
              ),
            ),
            if (item != species.last) const FigmaDivider(),
          ],
        ],
      ),
    );
  }
}

class _SafetyContent extends StatelessWidget {
  const _SafetyContent();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _SafetyRow(
          icon: Icons.phone_rounded,
          color: FigmaFluviTokens.red,
          title: '112 · Urgențe',
          subtitle: 'Număr național unic',
        ),
        const SizedBox(height: 10),
        const _SafetyRow(
          icon: Icons.support_agent_rounded,
          color: FigmaFluviTokens.textSecondary,
          title: 'Contact oficial în integrare',
          subtitle: 'Nu afișăm numere neverificate',
        ),
        const SizedBox(height: 10),
        _SafetyRow(
          icon: Icons.warning_amber_rounded,
          color: FigmaFluviTokens.cyan,
          title: 'Raportează braconaj',
          subtitle: 'Deschide fișa de sesizare rapidă',
          onTap: () => AppNavigator.open(context, AppDestination.addReport),
        ),
      ],
    );
  }
}

class _SafetyRow extends StatelessWidget {
  const _SafetyRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => FigmaSurface(
    accent: color,
    onTap: onTap,
    child: Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: color.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: color, size: 19),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: FigmaFluviTokens.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 3),
              Text(subtitle, style: figmaBody(size: 10)),
            ],
          ),
        ),
        const Icon(
          Icons.chevron_right_rounded,
          color: FigmaFluviTokens.textSecondary,
        ),
      ],
    ),
  );
}

class FigmaToolkitPage extends StatelessWidget {
  const FigmaToolkitPage({super.key});

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-toolkit-page'),
      title: 'Instrumente pescar',
      eyebrow: 'PREGĂTIRE',
      child: ListView(
        children: [
          _ToolkitTile(
            icon: Icons.badge_outlined,
            title: 'Permis de pescuit',
            subtitle: 'Stare și valabilitate din sursă oficială',
            destination: AppDestination.permit,
          ),
          const SizedBox(height: 10),
          _ToolkitTile(
            icon: Icons.rule_rounded,
            title: 'Reglementări',
            subtitle: 'Prohibiții, dimensiuni și limite verificate',
            destination: AppDestination.regulations,
          ),
          const SizedBox(height: 10),
          _ToolkitTile(
            icon: Icons.health_and_safety_outlined,
            title: 'Siguranță',
            subtitle: 'Contacte și acțiuni pentru situații de risc',
            destination: AppDestination.safety,
          ),
          const SizedBox(height: 10),
          _ToolkitTile(
            icon: Icons.notifications_active_outlined,
            title: 'Alerte',
            subtitle: 'Reguli pentru ape și stații reale',
            destination: AppDestination.alerts,
          ),
        ],
      ),
    );
  }
}

class _ToolkitTile extends StatelessWidget {
  const _ToolkitTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.destination,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final AppDestination destination;

  @override
  Widget build(BuildContext context) => FigmaSurface(
    onTap: () => AppNavigator.open(context, destination),
    child: Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: FigmaFluviTokens.cyan.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: FigmaFluviTokens.cyan, size: 21),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: FigmaFluviTokens.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(subtitle, style: figmaBody(size: 10)),
            ],
          ),
        ),
        const Icon(
          Icons.chevron_right_rounded,
          color: FigmaFluviTokens.textSecondary,
        ),
      ],
    ),
  );
}

class FigmaProfilePage extends ConsumerStatefulWidget {
  const FigmaProfilePage({super.key});

  @override
  ConsumerState<FigmaProfilePage> createState() => _FigmaProfilePageState();
}

class _FigmaProfilePageState extends ConsumerState<FigmaProfilePage> {
  final _auth = const AuthService();
  late final Future<ReputationMetrics> _reputation;

  @override
  void initState() {
    super.initState();
    _reputation = const ReputationService().getCurrentUserReputation();
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    final metadata = user?.userMetadata;
    final name = metadata?['full_name']?.toString().trim();
    final avatarUrl = metadata?['avatar_url']?.toString();
    final tier = ref.watch(fluviAccessTierProvider);
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-profile-page'),
      title: 'Profil',
      eyebrow: user == null ? 'NEAUTENTIFICAT' : 'CONT',
      action: FigmaRoundButton(
        icon: Icons.settings_outlined,
        tooltip: 'Setări',
        onPressed: () => AppNavigator.open(context, AppDestination.settings),
      ),
      child: user == null
          ? FigmaTruthfulEmpty(
              icon: Icons.person_outline_rounded,
              title: 'Autentificare necesară',
              message: 'Profilul personal apare după autentificare.',
              actionLabel: 'Deschide autentificarea',
              onAction: () =>
                  AppNavigator.open(context, AppDestination.accountSecurity),
            )
          : ListView(
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundColor: FigmaFluviTokens.surfaceRaised,
                      backgroundImage: avatarUrl == null || avatarUrl.isEmpty
                          ? null
                          : NetworkImage(avatarUrl),
                      child: avatarUrl == null || avatarUrl.isEmpty
                          ? const Icon(
                              Icons.person_rounded,
                              color: FigmaFluviTokens.cyan,
                              size: 34,
                            )
                          : null,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  name == null || name.isEmpty
                                      ? 'Pescar FluviAI'
                                      : name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: FigmaFluviTokens.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              FigmaPill(
                                label: tier == FluviAccessTier.premium
                                    ? 'PRO'
                                    : 'FREE',
                                color: tier == FluviAccessTier.premium
                                    ? FigmaFluviTokens.amber
                                    : FigmaFluviTokens.cyan,
                                active: true,
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.email ?? 'Email indisponibil',
                            style: figmaBody(size: 10),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                FutureBuilder<ReputationMetrics>(
                  future: _reputation,
                  builder: (context, state) {
                    final metrics = state.data;
                    return FigmaSurface(
                      child: Row(
                        children: [
                          Expanded(
                            child: FigmaMetric(
                              value: metrics?.reputationScore.toString() ?? '—',
                              label: 'reputație',
                            ),
                          ),
                          Expanded(
                            child: FigmaMetric(
                              value: metrics?.trustLevel.label ?? '—',
                              label: 'încredere',
                              alignment: CrossAxisAlignment.center,
                            ),
                          ),
                          Expanded(
                            child: FigmaMetric(
                              value: metrics?.catchesCount.toString() ?? '—',
                              label: 'capturi',
                              alignment: CrossAxisAlignment.end,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 16),
                FigmaSurface(
                  padding: EdgeInsets.zero,
                  child: Column(
                    children: [
                      _ProfileRow(
                        label: 'Capturile mele',
                        destination: AppDestination.myCatches,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Jurnalul meu',
                        destination: AppDestination.journal,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Rapoartele mele',
                        destination: AppDestination.myReports,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Permis de pescuit',
                        destination: AppDestination.permit,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Cont și securitate',
                        destination: AppDestination.accountSecurity,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Premium',
                        destination: AppDestination.premium,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Ajutor și feedback',
                        destination: AppDestination.support,
                      ),
                      const FigmaDivider(),
                      _ProfileRow(
                        label: 'Legal',
                        destination: AppDestination.legal,
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class _ProfileRow extends StatelessWidget {
  const _ProfileRow({required this.label, required this.destination});

  final String label;
  final AppDestination destination;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () => AppNavigator.open(context, destination),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: FigmaFluviTokens.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const Icon(
            Icons.chevron_right_rounded,
            color: FigmaFluviTokens.textSecondary,
            size: 18,
          ),
        ],
      ),
    ),
  );
}

class FigmaSettingsPage extends ConsumerStatefulWidget {
  const FigmaSettingsPage({super.key});

  @override
  ConsumerState<FigmaSettingsPage> createState() => _FigmaSettingsPageState();
}

class _FigmaSettingsPageState extends ConsumerState<FigmaSettingsPage> {
  @override
  Widget build(BuildContext context) {
    final localeScope = LocaleScope.of(context);
    final themeController = ThemeScope.of(context);
    final contentRegion = ref.watch(contentRegionProvider);
    final countryLabel = _countryLabel(contentRegion?.countryCode);
    final languageCode = localeScope.languageCode;

    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-settings-page'),
      title: 'Setări aplicație & ajutor',
      subtitle: 'Preferințe · date · legal · suport',
      padding: EdgeInsets.zero,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
        children: [
          const _SettingsReviewSectionLabel('PREFERINȚE'),
          const SizedBox(height: 8),
          _SettingsAppearanceCard(
            preference: themeController.preference,
            onChanged: (value) async {
              await themeController.setPreference(value);
              if (mounted) setState(() {});
            },
          ),
          const SizedBox(height: 10),
          _SettingsReviewRow(
            title: 'Limbă',
            subtitle: languageCode == 'ro'
                ? 'Română · English'
                : 'English · Română',
            onTap: () async {
              await localeScope.setLanguageCode(
                languageCode == 'ro' ? 'en' : 'ro',
              );
              if (mounted) setState(() {});
            },
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Regiune și unități',
            subtitle: '$countryLabel · unități după preferința aplicației',
            onTap: () => _showFigmaInfo(
              context,
              title: 'Regiune și unități',
              message:
                  'Regiunea de conținut este rezolvată separat de limba interfeței. Selectorul complet de unități se conectează la setarea persistentă existentă în etapa de utilități reale.',
            ),
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: languageCode == 'ro'
                ? 'Resetează poziția Întreabă Fluvi'
                : 'Reset Ask Fluvi position',
            subtitle: languageCode == 'ro'
                ? 'Restabilește pozițiile implicite pe Acasă și Hartă'
                : 'Restore the default Home and Map positions',
            onTap: () async {
              await AskFluviPlacementStore.resetAll();
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    languageCode == 'ro'
                        ? 'Poziția Întreabă Fluvi a fost resetată.'
                        : 'Ask Fluvi position was reset.',
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          const _SettingsReviewSectionLabel('CONFIDENȚIALITATE & DATE'),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Confidențialitate și date',
            subtitle: 'Privacy notice · export · ștergere cont',
            onTap: () =>
                AppNavigator.open<void>(context, AppDestination.privacy),
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Permisiuni și analytics',
            subtitle: 'Locație · cameră · notificări · opțiuni analytics',
            onTap: () => _showFigmaInfo(
              context,
              title: 'Permisiuni și analytics',
              message:
                  'Permisiunile sunt controlate de sistem și de fluxurile care le folosesc. Nu schimbăm permisiuni fără o acțiune explicită a utilizatorului.',
            ),
          ),
          const SizedBox(height: 18),
          const _SettingsReviewSectionLabel('LEGAL & SIGURANȚĂ'),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Termeni & condiții',
            subtitle: 'UE · România · UK',
            onTap: () => AppNavigator.open<void>(context, AppDestination.terms),
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Comunitate & moderare',
            subtitle: 'Raportare · moderare · conținut ilegal',
            onTap: () =>
                AppNavigator.open<void>(context, AppDestination.moderation),
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Fluvi & transparență AI',
            subtitle: 'Asistent AI · surse · limite · etichetare',
            badge: 'AI',
            onTap: () =>
                AppNavigator.open<void>(context, AppDestination.aiTransparency),
          ),
          const SizedBox(height: 8),
          _SettingsReviewRow(
            title: 'Abonament & facturare',
            subtitle: 'Trial · preț · reînnoire · anulare',
            badge: 'PRO',
            onTap: () =>
                AppNavigator.open<void>(context, AppDestination.premium),
          ),
          const SizedBox(height: 10),
          _SettingsReviewRow(
            title: 'Ajutor · contact · companie · licențe · versiune',
            compact: true,
            onTap: () =>
                AppNavigator.open<void>(context, AppDestination.support),
          ),
          const SizedBox(height: 86),
        ],
      ),
    );
  }
}

class _SettingsReviewSectionLabel extends StatelessWidget {
  const _SettingsReviewSectionLabel(this.label);

  final String label;

  @override
  Widget build(BuildContext context) => Text(
    label,
    style: const TextStyle(
      color: FigmaFluviTokens.textSecondary,
      fontFamily: FluviAICommercialTokens.monoFontFamily,
      fontSize: 9,
      fontWeight: FontWeight.w500,
    ),
  );
}

class _SettingsAppearanceCard extends StatelessWidget {
  const _SettingsAppearanceCard({
    required this.preference,
    required this.onChanged,
  });

  final AppThemePreference preference;
  final ValueChanged<AppThemePreference> onChanged;

  @override
  Widget build(BuildContext context) {
    final largeText = MediaQuery.textScalerOf(context).scale(1) >= 1.5;
    final selector = _ThemePreferenceSelector(
      preference: preference,
      onChanged: onChanged,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0D171C),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FigmaFluviTokens.border),
      ),
      child: largeText
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _AppearanceCopy(),
                const SizedBox(height: 10),
                selector,
              ],
            )
          : Row(
              children: [
                const Expanded(child: _AppearanceCopy()),
                const SizedBox(width: 12),
                selector,
              ],
            ),
    );
  }
}

class _AppearanceCopy extends StatelessWidget {
  const _AppearanceCopy();

  @override
  Widget build(BuildContext context) => const Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Aspect',
        style: TextStyle(
          color: FigmaFluviTokens.white,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      SizedBox(height: 5),
      Text(
        'Automat urmează sistemul',
        style: TextStyle(color: FigmaFluviTokens.textMuted, fontSize: 10),
      ),
    ],
  );
}

class _ThemePreferenceSelector extends StatelessWidget {
  const _ThemePreferenceSelector({
    required this.preference,
    required this.onChanged,
  });

  final AppThemePreference preference;
  final ValueChanged<AppThemePreference> onChanged;

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: const Color(0xFF071015),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: FigmaFluviTokens.border),
    ),
    child: SegmentedButton<AppThemePreference>(
      key: const ValueKey('settings-theme-selector'),
      showSelectedIcon: false,
      segments: const [
        ButtonSegment(value: AppThemePreference.automatic, label: Text('Auto')),
        ButtonSegment(value: AppThemePreference.light, label: Text('Zi')),
        ButtonSegment(value: AppThemePreference.dark, label: Text('Noapte')),
      ],
      selected: {preference},
      onSelectionChanged: (values) => onChanged(values.first),
    ),
  );
}

class _SettingsReviewRow extends StatelessWidget {
  const _SettingsReviewRow({
    required this.title,
    this.subtitle,
    this.badge,
    this.onTap,
    this.compact = false,
  });

  final String title;
  final String? subtitle;
  final String? badge;
  final VoidCallback? onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(compact ? 14 : 16),
    clipBehavior: Clip.antiAlias,
    child: Ink(
      decoration: BoxDecoration(
        color: compact ? const Color(0xFF101C22) : const Color(0xFF0D171C),
        borderRadius: BorderRadius.circular(compact ? 14 : 16),
        border: Border.all(color: FigmaFluviTokens.border),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 14,
            vertical: compact ? 12 : 10,
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: compact ? 2 : 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: FigmaFluviTokens.white,
                        fontSize: compact ? 10.5 : 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        subtitle!,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: FigmaFluviTokens.textMuted,
                          fontSize: 9.5,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (badge != null) ...[
                const SizedBox(width: 10),
                Text(
                  badge!,
                  style: const TextStyle(
                    color: FigmaFluviTokens.cyan,
                    fontFamily: FluviAICommercialTokens.monoFontFamily,
                    fontSize: 9,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ] else ...[
                const SizedBox(width: 10),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: FigmaFluviTokens.textSecondary,
                  size: 20,
                ),
              ],
            ],
          ),
        ),
      ),
    ),
  );
}

class FigmaPremiumPage extends ConsumerStatefulWidget {
  const FigmaPremiumPage({
    super.key,
    this.billingRepository = const UnavailableBillingRepository(),
  });

  final BillingRepository billingRepository;

  @override
  ConsumerState<FigmaPremiumPage> createState() => _FigmaPremiumPageState();
}

class _FigmaPremiumPageState extends ConsumerState<FigmaPremiumPage> {
  bool _restoring = false;
  String? _result;

  Future<void> _restore() async {
    setState(() {
      _restoring = true;
      _result = null;
    });
    BillingRestoreResult result;
    try {
      result = await widget.billingRepository.restorePurchases();
    } on Exception {
      result = BillingRestoreResult.error;
    }
    if (!mounted) return;
    if (result == BillingRestoreResult.restored) {
      ref
          .read(fluviAccessTierProvider.notifier)
          .setTier(FluviAccessTier.premium);
    }
    setState(() {
      _restoring = false;
      _result = switch (result) {
        BillingRestoreResult.restored => 'Premium a fost restaurat.',
        BillingRestoreResult.nothingToRestore =>
          'Nu a fost găsită o achiziție eligibilă.',
        BillingRestoreResult.unavailable =>
          'Magazinul nu este conectat în această versiune.',
        BillingRestoreResult.error =>
          'Restaurarea a eșuat. Planul nu a fost modificat.',
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    final isPremium =
        ref.watch(fluviAccessTierProvider) == FluviAccessTier.premium;
    const features = [
      'Râuri interioare, baraje și acumulări',
      'Istoric Water și grafice extinse',
      'Prognoze, alerte și planificare avansată',
      'FluviScore, Insight și Ask Fluvi avansate',
      'Hărți și date salvate pentru teren',
      'Statistici personale și jurnal extins',
      'Comparații între stații și ape',
      'Experiență fără reclame',
    ];
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-premium-page'),
      title: 'FluviAI Pro',
      eyebrow: isPremium ? 'PLAN ACTIV' : 'UPGRADE',
      background: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topCenter,
          radius: 1.2,
          colors: [
            Color(0xFF123D57),
            FigmaFluviTokens.background,
            Color(0xFF000000),
          ],
          stops: [0, .48, 1],
        ),
      ),
      child: ListView(
        children: [
          Center(
            child: Column(
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'FluviAI',
                      style: TextStyle(
                        color: FigmaFluviTokens.white,
                        fontSize: 31,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(width: 8),
                    FigmaPill(
                      label: 'PRO',
                      color: FigmaFluviTokens.amber,
                      active: true,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Descoperă mai mult din fiecare partidă',
                  style: figmaBody(size: 14),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          FigmaSurface(
            accent: FigmaFluviTokens.amber,
            child: Column(
              children: [
                for (final feature in features)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.check_rounded,
                          color: FigmaFluviTokens.cyanSoft,
                          size: 17,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            feature,
                            style: const TextStyle(
                              color: FigmaFluviTokens.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FigmaSurface(
            accent: FigmaFluviTokens.green,
            child: Text(
              'Funcțiile esențiale și alertele de siguranță rămân disponibile Free.',
              textAlign: TextAlign.center,
              style: figmaBody(
                color: FigmaFluviTokens.cyanSoft,
                size: 10,
                weight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: FigmaSurface(
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'LUNAR',
                        style: TextStyle(
                          color: FigmaFluviTokens.textMuted,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Preț în Store',
                        style: TextStyle(
                          color: FigmaFluviTokens.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'monedă locală / lună',
                        style: TextStyle(
                          color: FigmaFluviTokens.textMuted,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FigmaSurface(
                  accent: FigmaFluviTokens.cyan,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ANUAL · RECOMANDAT',
                        style: TextStyle(
                          color: FigmaFluviTokens.cyan,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Preț în Store',
                        style: TextStyle(
                          color: FigmaFluviTokens.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'monedă locală / an',
                        style: TextStyle(
                          color: FigmaFluviTokens.textMuted,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          FigmaPrimaryButton(
            label: isPremium ? 'Plan Pro activ' : 'Continuă cu FluviAI Pro',
            icon: Icons.workspace_premium_rounded,
            onPressed: isPremium
                ? null
                : () => setState(
                    () => _result =
                        'Magazinul nu este conectat. Nu s-a inițiat nicio plată.',
                  ),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: _restoring ? null : _restore,
            child: Text(_restoring ? 'Se verifică…' : 'Restaurează achiziția'),
          ),
          if (_result != null)
            Text(
              _result!,
              textAlign: TextAlign.center,
              style: figmaBody(size: 10),
            ),
          const SizedBox(height: 8),
          Text(
            'Prețul și perioada sunt afișate de App Store sau Google Play înainte de confirmare.',
            textAlign: TextAlign.center,
            style: figmaBody(size: 9),
          ),
        ],
      ),
    );
  }
}

class FigmaLegalSupportPage extends StatelessWidget {
  const FigmaLegalSupportPage({super.key, this.focus});

  final AppDestination? focus;

  @override
  Widget build(BuildContext context) {
    final pageTitle = switch (focus) {
      AppDestination.support => 'Ajutor și suport',
      AppDestination.privacy => 'Politica de confidențialitate',
      AppDestination.terms => 'Termeni și condiții',
      AppDestination.licences => 'Licențe open-source',
      AppDestination.about => 'Despre FluviAI',
      AppDestination.moderation => 'Comunitate și moderare',
      AppDestination.aiTransparency => 'Transparență AI',
      _ => 'Legal și suport',
    };
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-legal-support-page'),
      title: pageTitle,
      eyebrow: 'TRANSPARENȚĂ',
      child: ListView(
        children: [
          if (focus == AppDestination.moderation)
            const FigmaTruthfulEmpty(
              icon: Icons.policy_outlined,
              title: 'Conținut de moderare indisponibil',
              message:
                  'Politica de moderare nu este publicată în sursa curentă.',
            )
          else if (focus == AppDestination.aiTransparency)
            const FigmaTruthfulEmpty(
              icon: Icons.auto_awesome_outlined,
              title: 'Conținut de transparență AI indisponibil',
              message:
                  'Documentul de transparență AI nu este publicat în sursa curentă.',
            )
          else if (focus == AppDestination.about)
            const FigmaTruthfulEmpty(
              icon: Icons.info_outline_rounded,
              title: 'Conținut despre aplicație indisponibil',
              message:
                  'Pagina editorială Despre FluviAI nu este publicată în sursa curentă.',
            ),
          if (focus == null || focus == AppDestination.terms) ...[
            _LegalSection(
              title: 'Termeni și condiții',
              body: 'Conținut juridic în curs de revizuire',
              onTap: focus == AppDestination.terms
                  ? null
                  : () => AppNavigator.open(context, AppDestination.terms),
            ),
            const SizedBox(height: 12),
          ],
          if (focus == null || focus == AppDestination.privacy) ...[
            _LegalSection(
              title: 'Politica de confidențialitate',
              body: 'Conținut juridic în curs de revizuire',
              onTap: focus == AppDestination.privacy
                  ? null
                  : () => AppNavigator.open(context, AppDestination.privacy),
            ),
            const SizedBox(height: 12),
          ],
          if (focus == null || focus == AppDestination.licences) ...[
            const _LegalSection(
              title: 'Licențe open-source',
              body: 'Mapbox GL · fl_chart · Riverpod · Supabase',
            ),
            const SizedBox(height: 12),
          ],
          if (focus == null || focus == AppDestination.support) ...[
            FigmaSurface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const FigmaSectionLabel('Contact suport'),
                  const SizedBox(height: 12),
                  const Row(
                    children: [
                      Icon(
                        Icons.mail_outline_rounded,
                        color: FigmaFluviTokens.cyan,
                        size: 20,
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'contact@fluviai.com',
                          style: TextStyle(
                            color: FigmaFluviTokens.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        color: FigmaFluviTokens.textSecondary,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Programul de răspuns va fi publicat înainte de lansare.',
                          style: figmaBody(size: 10),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            FigmaSurface(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  _SupportRow(
                    label: 'Ajutor și FAQ',
                    onTap: () => _showFigmaInfo(
                      context,
                      title: 'Ajutor și FAQ',
                      message:
                          'Centrul FAQ este în curs de publicare. Pentru asistență folosește contact@fluviai.com.',
                    ),
                  ),
                  const FigmaDivider(),
                  _SupportRow(
                    label: 'Trimite feedback',
                    onTap: () => _showFigmaInfo(
                      context,
                      title: 'Trimite feedback',
                      message:
                          'Trimite feedback la contact@fluviai.com. Formularul intern va fi activat numai după conectarea serviciului real.',
                    ),
                  ),
                  if (focus == null) ...[
                    const FigmaDivider(),
                    _SupportRow(
                      label: 'Despre FluviAI',
                      onTap: () =>
                          AppNavigator.open(context, AppDestination.about),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _LegalSection extends StatelessWidget {
  const _LegalSection({required this.title, required this.body, this.onTap});

  final String title;
  final String body;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => FigmaSurface(
    onTap: onTap,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FigmaSectionLabel(title),
        const SizedBox(height: 10),
        Text(body, style: figmaBody(size: 12)),
        if (onTap != null) ...[
          const SizedBox(height: 8),
          const Text(
            'Stare document  ›',
            style: TextStyle(
              color: FigmaFluviTokens.cyan,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ],
    ),
  );
}

class _SupportRow extends StatelessWidget {
  const _SupportRow({required this.label, required this.onTap});

  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: FigmaFluviTokens.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          if (onTap != null)
            const Icon(
              Icons.chevron_right_rounded,
              color: FigmaFluviTokens.cyan,
              size: 18,
            ),
        ],
      ),
    ),
  );
}

class FigmaAccountSecurityPage extends StatefulWidget {
  const FigmaAccountSecurityPage({super.key});

  @override
  State<FigmaAccountSecurityPage> createState() =>
      _FigmaAccountSecurityPageState();
}

class _FigmaAccountSecurityPageState extends State<FigmaAccountSecurityPage> {
  final _auth = const AuthService();
  bool _loggingOut = false;
  String? _message;

  Future<void> _sendRecovery() async {
    final email = _auth.currentUser?.email;
    if (email == null || email.isEmpty) return;
    setState(() {
      _message = null;
    });
    try {
      await _auth.sendPasswordReset(email);
      if (mounted) {
        setState(
          () => _message =
              'Instrucțiunile de recuperare au fost trimise la emailul contului.',
        );
      }
    } on AuthException catch (error) {
      if (mounted) setState(() => _message = error.message);
    }
  }

  Future<void> _logout() async {
    setState(() {
      _loggingOut = true;
      _message = null;
    });
    try {
      await _auth.logout();
      if (mounted) Navigator.of(context).popUntil((route) => route.isFirst);
    } on AuthException catch (error) {
      if (mounted) setState(() => _message = error.message);
    } finally {
      if (mounted) setState(() => _loggingOut = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-account-security'),
      title: 'Cont și securitate',
      eyebrow: user == null ? 'NEAUTENTIFICAT' : 'AUTENTIFICAT',
      child: ListView(
        children: [
          const FigmaSectionLabel('Autentificare'),
          const SizedBox(height: 8),
          FigmaSurface(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                _AccountRow(
                  label: 'Email',
                  value: user?.email ?? 'Neautentificat',
                ),
                const FigmaDivider(),
                _AccountRow(
                  label: 'Parolă și recuperare',
                  value: 'Gestionează  ›',
                  onTap: user?.email == null ? null : _sendRecovery,
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const FigmaSectionLabel('Securitate'),
          const SizedBox(height: 8),
          FigmaSurface(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                _AccountRow(
                  label: 'Dispozitive conectate',
                  value: 'Vezi sesiunile  ›',
                  onTap: () => _showFigmaInfo(
                    context,
                    title: 'Dispozitive conectate',
                    message:
                        'Lista sesiunilor va apărea după conectarea endpointului securizat. Nu afișăm dispozitive inventate.',
                  ),
                ),
                const FigmaDivider(),
                _AccountRow(
                  label: 'Activitate recentă',
                  value: 'Verifică  ›',
                  onTap: () => _showFigmaInfo(
                    context,
                    title: 'Activitate recentă',
                    message:
                        'Istoricul de securitate nu este disponibil în sursa curentă.',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const FigmaSectionLabel('Date și cont'),
          const SizedBox(height: 8),
          FigmaSurface(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                _AccountRow(
                  label: 'Exportă datele mele',
                  value: 'Solicită  ›',
                  onTap: () => _showFigmaInfo(
                    context,
                    title: 'Export date',
                    message:
                        'Exportul va fi disponibil după conectarea fluxului GDPR. Nu s-a creat nicio cerere.',
                  ),
                ),
                const FigmaDivider(),
                _AccountRow(
                  label: 'Șterge contul',
                  value: 'Proces protejat  ›',
                  destructive: true,
                  onTap: () => _showFigmaInfo(
                    context,
                    title: 'Ștergerea contului',
                    message:
                        'Ștergerea definitivă nu este conectată în această versiune. Nu s-a șters nimic.',
                  ),
                ),
              ],
            ),
          ),
          if (_message != null) ...[
            const SizedBox(height: 12),
            Text(
              _message!,
              textAlign: TextAlign.center,
              style: figmaBody(color: FigmaFluviTokens.red, size: 11),
            ),
          ],
          const SizedBox(height: 18),
          FigmaPrimaryButton(
            label: _loggingOut ? 'Se deconectează…' : 'Deconectare',
            secondary: true,
            onPressed: user == null || _loggingOut ? null : _logout,
          ),
        ],
      ),
    );
  }
}

class _AccountRow extends StatelessWidget {
  const _AccountRow({
    required this.label,
    required this.value,
    this.destructive = false,
    this.onTap,
  });

  final String label;
  final String value;
  final bool destructive;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: destructive
                    ? FigmaFluviTokens.red
                    : FigmaFluviTokens.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Flexible(
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
              style: TextStyle(
                color: destructive
                    ? FigmaFluviTokens.red
                    : FigmaFluviTokens.textSecondary,
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
