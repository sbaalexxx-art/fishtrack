import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../../core/context/selected_context.dart';
import '../../../core/map/map_runtime_provenance.dart';
import '../../../core/navigation/app_destination.dart';
import '../../../core/navigation/app_navigator.dart';
import '../../../core/navigation/map_entry.dart';
import '../../../core/navigation/water_entry.dart';
import '../../../core/water/water_history_analysis.dart';
import '../../../models/station.dart';
import '../../../models/water_level.dart';
import '../../../models/weather.dart';
import '../../../services/water_service.dart';
import '../../commercial_home/data/commercial_home_data_source.dart';
import 'figma_foundation.dart';
import 'figma_runtime_data.dart';

String _number(double? value, {int decimals = 0}) =>
    value == null || !value.isFinite ? '—' : value.toStringAsFixed(decimals);

enum WaterFreshnessDisplayState { live, cache, stale, error, unavailable }

WaterFreshnessDisplayState resolveWaterFreshnessDisplayState(
  WaterUiResult? result,
) {
  if (result?.latestReading == null) {
    return result?.providerError == true ||
            result?.status == WaterUiStatus.providerError
        ? WaterFreshnessDisplayState.error
        : WaterFreshnessDisplayState.unavailable;
  }
  if (result!.isStale) return WaterFreshnessDisplayState.stale;
  if (result.providerError || result.status == WaterUiStatus.providerError) {
    return WaterFreshnessDisplayState.cache;
  }
  return WaterFreshnessDisplayState.live;
}

String waterFreshnessDisplayLabel(
  WaterFreshnessDisplayState state, {
  required bool isRomanian,
}) => switch (state) {
  WaterFreshnessDisplayState.live => isRomanian ? 'ACTUAL' : 'LIVE',
  WaterFreshnessDisplayState.cache => 'CACHE',
  WaterFreshnessDisplayState.stale => isRomanian ? 'VECHI' : 'STALE',
  WaterFreshnessDisplayState.error => isRomanian ? 'EROARE' : 'ERROR',
  WaterFreshnessDisplayState.unavailable =>
    isRomanian ? 'FĂRĂ DATE' : 'UNAVAILABLE',
};

Color _waterFreshnessDisplayColor(WaterFreshnessDisplayState state) =>
    switch (state) {
      WaterFreshnessDisplayState.live => const Color(0xFF38BDF8),
      WaterFreshnessDisplayState.cache => FigmaFluviTokens.amber,
      WaterFreshnessDisplayState.stale ||
      WaterFreshnessDisplayState.error => FigmaFluviTokens.red,
      WaterFreshnessDisplayState.unavailable => FigmaFluviTokens.textMuted,
    };

String _stationContext(CommercialHomeSnapshot? snapshot, Station? preferred) {
  final station = preferred ?? snapshot?.station;
  if (station == null) {
    return 'Locația ta';
  }
  final river = station.river.trim();
  return river.isEmpty ? station.name : '$river · ${station.name}';
}

String _officialContext(CommercialHomeSnapshot? snapshot, Station? preferred) {
  final station = preferred ?? snapshot?.station;
  final river = station?.river.trim();
  final label = river != null && river.isNotEmpty ? river : station?.name;
  return label == null || label.trim().isEmpty
      ? 'DATE OFICIALE'
      : 'DATE OFICIALE · ${label.toUpperCase()}';
}

@immutable
class WaterOfficialObservationState {
  const WaterOfficialObservationState({
    required this.currentReading,
    required this.deltaCm,
    required this.trend,
  });

  final WaterLevel? currentReading;
  final double? deltaCm;
  final WaterTrend? trend;
}

WaterOfficialObservationState resolveWaterOfficialObservationState(
  WaterUiResult? result,
) {
  final canonical = result?.effectiveCanonicalTrend;
  return WaterOfficialObservationState(
    currentReading: result?.latestReading,
    deltaCm: canonical?.delta?.value,
    trend: canonical?.trend.displayTrend,
  );
}

Color _trendColor(WaterTrend? trend) => switch (trend) {
  WaterTrend.rising => const Color(0xFF38BDF8),
  WaterTrend.falling => FigmaFluviTokens.red,
  WaterTrend.stable => FigmaFluviTokens.green,
  null => FigmaFluviTokens.textMuted,
};

String _trendLabel(WaterTrend? trend) => switch (trend) {
  WaterTrend.rising => 'Crește lent',
  WaterTrend.falling => 'Scade lent',
  WaterTrend.stable => 'Stabil',
  null => 'Trend indisponibil',
};

String _signedDelta(double value) {
  final rounded = value.round();
  final sign = rounded > 0
      ? '+'
      : rounded < 0
      ? '−'
      : '';
  return '$sign${rounded.abs()} cm / 24h';
}

String _relativeAge(Duration? age) {
  if (age == null) {
    return 'actualizare indisponibilă';
  }
  final safe = age.isNegative ? Duration.zero : age;
  if (safe.inDays > 0) {
    return 'acum ${safe.inDays} ${safe.inDays == 1 ? 'zi' : 'zile'}';
  }
  if (safe.inHours > 0) {
    return 'acum ${safe.inHours} h';
  }
  if (safe.inMinutes > 0) {
    return 'acum ${safe.inMinutes} min';
  }
  return 'acum';
}

String _sourceLabel(String? raw) {
  final value = raw?.trim() ?? '';
  if (value.isEmpty) {
    return 'Sursă indisponibilă';
  }
  return RegExp(r'^[A-Za-z0-9_-]{2,10}$').hasMatch(value)
      ? value.toUpperCase()
      : value;
}

String _windDirectionRo(String direction) => direction.replaceAll('W', 'V');

String _localizedWeatherCondition(BuildContext context, String? raw) {
  final value = raw?.trim() ?? '';
  if (value.isEmpty ||
      Localizations.localeOf(context).languageCode.toLowerCase() != 'ro') {
    return value;
  }
  return switch (value.toLowerCase()) {
    'clear sky' || 'clear' => 'Senin',
    'mainly clear' => 'Mai mult senin',
    'partly cloudy' => 'Parțial noros',
    'overcast' => 'Cer acoperit',
    'fog' || 'mist' => 'Ceață',
    'drizzle' => 'Burniță',
    'rain' || 'light rain' => 'Ploaie',
    'snow' || 'snowfall' => 'Ninsoare',
    'thunderstorm' => 'Furtună',
    _ => value,
  };
}

String _localizedScoreText(BuildContext context, String raw) {
  if (Localizations.localeOf(context).languageCode.toLowerCase() != 'ro') {
    return raw;
  }
  return switch (raw.trim().toLowerCase()) {
    'fair' => 'Moderat',
    'good' => 'Bun',
    'poor' => 'Slab',
    'stable water trend' => 'Tendință stabilă a apei',
    'water reading is outdated' => 'Citirea apei este veche',
    'unfavourable humidity' => 'Umiditate nefavorabilă',
    'very bright, clear conditions' => 'Lumină puternică și cer senin',
    'moderate sw wind' => 'Vânt moderat din SV',
    'moderate west wind' => 'Vânt moderat din vest',
    _ => raw,
  };
}

double _textScale(BuildContext context) =>
    MediaQuery.textScalerOf(context).scale(16) / 16;

double _responsivePanelHeight(
  BuildContext context,
  double normalHeight,
  double heightAt200Percent,
) {
  final scale = _textScale(context);
  if (scale <= 1) {
    return normalHeight;
  }

  final progress = (scale - 1).clamp(0.0, 1.0);
  final calibrated =
      normalHeight + (heightAt200Percent - normalHeight) * progress;

  // Large accessibility text does more than scale glyphs: it also creates
  // extra wrapped lines. Preserve the exact 1.0x Figma height, but grow card
  // capacity faster than glyph scale once accessibility scaling is active.
  final wrapCapacity = normalHeight * (1 + 2.0 * (scale - 1).clamp(0.0, 1.0));

  final bounded = calibrated > wrapCapacity ? calibrated : wrapCapacity;
  if (scale <= 2) {
    return bounded;
  }

  // Continue growing beyond 200% rather than freezing a fixed-height card.
  return bounded + normalHeight * (scale - 2);
}

IconData _conditionIcon(String? condition) {
  final value = condition?.toLowerCase() ?? '';
  if (value.contains('storm') ||
      value.contains('thunder') ||
      value.contains('furt')) {
    return Icons.thunderstorm_rounded;
  }
  if (value.contains('rain') ||
      value.contains('drizzle') ||
      value.contains('ploa')) {
    return Icons.water_drop_rounded;
  }
  if (value.contains('snow') || value.contains('ninso')) {
    return Icons.ac_unit_rounded;
  }
  if (value.contains('fog') ||
      value.contains('mist') ||
      value.contains('cea')) {
    return Icons.cloud_queue_rounded;
  }
  if (value.contains('cloud') ||
      value.contains('overcast') ||
      value.contains('nor')) {
    return Icons.cloud_rounded;
  }
  return Icons.wb_sunny_rounded;
}

class _ContextHubAction {
  const _ContextHubAction({
    required this.keyName,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.secondary = true,
  });

  final String keyName;
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final bool secondary;
}

class _ContextHubActionGrid extends StatelessWidget {
  const _ContextHubActionGrid({required this.actions});

  final List<_ContextHubAction> actions;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final textScale = _textScale(context);
        final columns = textScale >= 1.5 || constraints.maxWidth < 520
            ? 1
            : actions.length > 3
            ? 3
            : actions.length;
        final gap = 10.0;
        final itemWidth =
            (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final action in actions)
              SizedBox(
                width: itemWidth,
                child: FigmaPrimaryButton(
                  key: ValueKey<String>(action.keyName),
                  label: action.label,
                  icon: action.icon,
                  secondary: action.secondary,
                  onPressed: action.onPressed,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _ReviewPanel extends StatelessWidget {
  const _ReviewPanel({
    required this.child,
    this.height,
    this.padding = const EdgeInsets.all(14),
    this.accent,
    this.background = const Color(0xFF0C151A),
    this.radius = 18,
  });

  final Widget child;
  final double? height;
  final EdgeInsetsGeometry padding;
  final Color? accent;
  final Color background;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: padding,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: accent ?? const Color(0xFF253841)),
      ),
      child: child,
    );
  }
}

class _MonoLabel extends StatelessWidget {
  const _MonoLabel(this.text, {this.color = FigmaFluviTokens.textSecondary});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Text(
    text.toUpperCase(),
    maxLines: 1,
    overflow: TextOverflow.ellipsis,
    style: TextStyle(
      fontFamily: 'IBM Plex Mono',
      color: color,
      fontSize: 9,
      height: 1.2,
      fontWeight: FontWeight.w500,
      letterSpacing: .25,
    ),
  );
}

class _TinyStatusPill extends StatelessWidget {
  const _TinyStatusPill({required this.label, required this.color, this.width});

  final String label;
  final Color color;
  final double? width;

  @override
  Widget build(BuildContext context) => Container(
    width: width,
    constraints: const BoxConstraints(minHeight: 28),
    padding: const EdgeInsets.symmetric(horizontal: 12),
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: color.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(999),
      border: Border.all(color: color),
    ),
    child: Text(
      label,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontFamily: 'IBM Plex Mono',
        color: color,
        fontSize: 9,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}

class _WaterSegmentBar extends StatelessWidget {
  const _WaterSegmentBar({required this.onStations, required this.onAlerts});

  final VoidCallback onStations;
  final VoidCallback onAlerts;

  @override
  Widget build(BuildContext context) {
    final largeText = MediaQuery.textScalerOf(context).scale(1) >= 1.5;

    Widget segment(String label, {bool selected = false, VoidCallback? onTap}) {
      return _SegmentLabel(
        label,
        selected: selected,
        onTap: onTap,
        semanticLabel: onTap == null ? null : 'Deschide $label',
      );
    }

    final children = <Widget>[
      segment('Rezumat'),
      segment('Tendință', selected: true),
      segment('Stații', onTap: onStations),
      segment('Alerte', onTap: onAlerts),
    ];

    return _ReviewPanel(
      height: largeText ? 50 : 42,
      padding: const EdgeInsets.all(4),
      radius: 14,
      background: const Color(0xFF091318),
      child: largeText
          ? SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: const ClampingScrollPhysics(),
              child: Row(
                children: [
                  for (final child in children)
                    SizedBox(width: 112, child: child),
                ],
              ),
            )
          : Row(
              children: [for (final child in children) Expanded(child: child)],
            ),
    );
  }
}

class _SegmentLabel extends StatelessWidget {
  const _SegmentLabel(
    this.label, {
    this.selected = false,
    this.onTap,
    this.semanticLabel,
  });

  final String label;
  final bool selected;
  final VoidCallback? onTap;
  final String? semanticLabel;

  @override
  Widget build(BuildContext context) {
    final child = Container(
      height: 34,
      alignment: Alignment.center,
      decoration: selected
          ? BoxDecoration(
              color: const Color(0xFF113B3A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: FigmaFluviTokens.cyan),
            )
          : null,
      child: Text(
        label,
        style: TextStyle(
          color: selected
              ? FigmaFluviTokens.cyan
              : FigmaFluviTokens.textSecondary,
          fontSize: 11,
          fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
        ),
      ),
    );
    if (onTap == null) {
      return child;
    }
    return Semantics(
      button: true,
      label: semanticLabel ?? label,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: child,
      ),
    );
  }
}

List<List<WaterLevel>> officialWaterChartSegments(List<WaterLevel> history) {
  final points = history.where((item) => item.value.isFinite).toList()
    ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
  if (points.isEmpty) return const <List<WaterLevel>>[];

  var typicalGap = const Duration(hours: 24);
  if (points.length >= 3) {
    final gaps = <Duration>[];
    for (var index = 1; index < points.length; index++) {
      gaps.add(
        points[index].timestamp.difference(points[index - 1].timestamp).abs(),
      );
    }
    gaps.sort((a, b) => a.compareTo(b));
    typicalGap = gaps[gaps.length ~/ 2];
    if (typicalGap < const Duration(minutes: 30)) {
      typicalGap = const Duration(minutes: 30);
    }
  }
  final breakAfter = Duration(
    milliseconds: (typicalGap.inMilliseconds * 2.5).round(),
  );
  final segments = <List<WaterLevel>>[
    <WaterLevel>[points.first],
  ];
  for (var index = 1; index < points.length; index++) {
    final gap = points[index].timestamp
        .difference(points[index - 1].timestamp)
        .abs();
    if (gap > breakAfter) segments.add(<WaterLevel>[]);
    segments.last.add(points[index]);
  }
  return segments;
}

class _OfficialWaterChart extends StatelessWidget {
  const _OfficialWaterChart({required this.history});

  final List<WaterLevel> history;

  @override
  Widget build(BuildContext context) {
    final segments = officialWaterChartSegments(history);
    final points = segments
        .expand((segment) => segment)
        .toList(growable: false);
    if (points.length < 2) return const SizedBox.shrink();

    var minimum = points.first.value;
    var maximum = points.first.value;
    for (final point in points.skip(1)) {
      if (point.value < minimum) minimum = point.value;
      if (point.value > maximum) maximum = point.value;
    }
    final range = maximum - minimum;
    final padding = range.abs() < .01 ? 1.0 : range * .18;
    final firstTime = points.first.timestamp.millisecondsSinceEpoch.toDouble();
    final lastTime = points.last.timestamp.millisecondsSinceEpoch.toDouble();
    const color = Color(0xFF38BDF8);

    WaterLevel readingForX(double x) => points.reduce((nearest, candidate) {
      final nearestDistance = (nearest.timestamp.millisecondsSinceEpoch - x)
          .abs();
      final candidateDistance = (candidate.timestamp.millisecondsSinceEpoch - x)
          .abs();
      return candidateDistance < nearestDistance ? candidate : nearest;
    });

    return Padding(
      key: const ValueKey('batch-b-water-official-chart'),
      padding: const EdgeInsets.fromLTRB(2, 6, 6, 4),
      child: LineChart(
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        LineChartData(
          minX: firstTime,
          maxX: firstTime == lastTime ? lastTime + 1 : lastTime,
          minY: minimum - padding,
          maxY: maximum + padding,
          clipData: const FlClipData.all(),
          borderData: FlBorderData(show: false),
          titlesData: const FlTitlesData(show: false),
          gridData: const FlGridData(show: false),
          lineTouchData: LineTouchData(
            enabled: true,
            touchSpotThreshold: 22,
            touchTooltipData: LineTouchTooltipData(
              fitInsideHorizontally: true,
              fitInsideVertically: true,
              tooltipPadding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 8,
              ),
              tooltipBorderRadius: BorderRadius.circular(11),
              tooltipBorder: BorderSide(color: color.withValues(alpha: .38)),
              getTooltipColor: (_) => const Color(0xF507131C),
              getTooltipItems: (spots) => spots
                  .map((spot) {
                    final reading = readingForX(spot.x);
                    final value = reading.value == reading.value.roundToDouble()
                        ? reading.value.toStringAsFixed(0)
                        : reading.value.toStringAsFixed(1);
                    final local = reading.timestamp.toLocal();
                    final stamp =
                        '${local.day.toString().padLeft(2, '0')}.${local.month.toString().padLeft(2, '0')} · ${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
                    return LineTooltipItem(
                      '$value ${reading.unit}\n$stamp',
                      const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    );
                  })
                  .toList(growable: false),
            ),
          ),
          lineBarsData: [
            for (final segment in segments)
              LineChartBarData(
                spots: segment
                    .map(
                      (point) => FlSpot(
                        point.timestamp.millisecondsSinceEpoch.toDouble(),
                        point.value,
                      ),
                    )
                    .toList(growable: false),
                isCurved: segment.length >= 3,
                curveSmoothness: .4,
                preventCurveOverShooting: true,
                color: color,
                barWidth: segment.length >= 2 ? 2.8 : 0,
                isStrokeCapRound: true,
                isStrokeJoinRound: true,
                belowBarData: BarAreaData(
                  show: segment.length >= 2,
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      color.withValues(alpha: .20),
                      color.withValues(alpha: .01),
                    ],
                  ),
                ),
                dotData: FlDotData(
                  show: true,
                  checkToShowDot: (spot, _) {
                    if (spot.x == lastTime || points.length <= 18) return true;
                    final index = points.indexWhere(
                      (point) =>
                          point.timestamp.millisecondsSinceEpoch.toDouble() ==
                          spot.x,
                    );
                    final stride = (points.length / 12).ceil();
                    return index >= 0 && index % stride == 0;
                  },
                  getDotPainter: (spot, _, _, _) {
                    final latest = spot.x == lastTime;
                    return FlDotCirclePainter(
                      radius: latest ? 4.4 : 2.4,
                      color: color,
                      strokeColor: latest
                          ? Colors.white
                          : const Color(0xFF071217),
                      strokeWidth: latest ? 1.4 : 1,
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _WeatherMetric extends StatelessWidget {
  const _WeatherMetric({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(icon, color: color, size: 17),
      const SizedBox(width: 7),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _MonoLabel(label),
            const SizedBox(height: 5),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: FigmaFluviTokens.white,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

class _HourlyStrip extends StatelessWidget {
  const _HourlyStrip({required this.hours});

  final List<WeatherForecastHour> hours;

  @override
  Widget build(BuildContext context) {
    final visible = hours.take(4).toList(growable: false);
    if (visible.isEmpty) {
      return const Center(
        child: Text(
          'Prognoza orară nu este disponibilă.',
          style: TextStyle(color: FigmaFluviTokens.textMuted, fontSize: 11),
        ),
      );
    }
    return Row(
      children: [
        for (var index = 0; index < visible.length; index++) ...[
          if (index > 0) const SizedBox(width: 6),
          Expanded(
            child: _HourlyCell(hour: visible[index], now: index == 0),
          ),
        ],
      ],
    );
  }
}

class _HourlyCell extends StatelessWidget {
  const _HourlyCell({required this.hour, required this.now});

  final WeatherForecastHour hour;
  final bool now;

  @override
  Widget build(BuildContext context) => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(
        now ? 'Acum' : hour.time.hour.toString().padLeft(2, '0'),
        style: const TextStyle(
          color: FigmaFluviTokens.textSecondary,
          fontSize: 10,
        ),
      ),
      const SizedBox(height: 8),
      Text(
        '${hour.temperature.round()}°',
        style: const TextStyle(
          color: FigmaFluviTokens.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      const SizedBox(height: 8),
      Text(
        '${_windDirectionRo(hour.windDirectionLabel)} ${hour.windSpeed.round()}',
        style: const TextStyle(
          color: FigmaFluviTokens.cyan,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  );
}

class _FishingDecisionCard extends StatelessWidget {
  const _FishingDecisionCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => _ReviewPanel(
    height: _responsivePanelHeight(context, 74, 128),
    radius: 16,
    background: const Color(0xFF0D171C),
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Row(
      children: [
        SizedBox(width: 30, child: Icon(icon, color: color, size: 21)),
        const SizedBox(width: 6),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FigmaFluviTokens.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FigmaFluviTokens.textSecondary,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
        const Icon(Icons.chevron_right_rounded, color: FigmaFluviTokens.cyan),
      ],
    ),
  );
}

class _SolunarDatum extends StatelessWidget {
  const _SolunarDatum({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => ConstrainedBox(
    constraints: const BoxConstraints(minWidth: 82, maxWidth: 140),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _MonoLabel(label),
        const SizedBox(height: 5),
        Text(
          value,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: FigmaFluviTokens.white,
            fontSize: 12,
            height: 1.2,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );
}

class _ScoreFactor {
  const _ScoreFactor({
    required this.label,
    required this.detail,
    required this.color,
    required this.pill,
  });

  final String label;
  final String detail;
  final Color color;
  final String pill;
}

class _ScoreFactorCard extends StatelessWidget {
  const _ScoreFactorCard({required this.factor});

  final _ScoreFactor factor;

  @override
  Widget build(BuildContext context) => _ReviewPanel(
    height: _responsivePanelHeight(context, 72, 128),
    radius: 16,
    background: const Color(0xFF0B1115),
    padding: const EdgeInsets.symmetric(horizontal: 13),
    child: Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: factor.color.withValues(alpha: .08),
            border: Border.all(color: factor.color),
          ),
          alignment: Alignment.center,
          child: Icon(Icons.circle, size: 6, color: factor.color),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                factor.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FigmaFluviTokens.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                factor.detail,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: FigmaFluviTokens.textSecondary,
                  fontSize: 10.5,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        _TinyStatusPill(label: factor.pill, color: factor.color, width: 82),
      ],
    ),
  );
}

class FigmaWaterHubPage extends StatefulWidget {
  const FigmaWaterHubPage({
    super.key,
    this.initialStation,
    this.dataSource,
    this.entryMode = WaterHubEntryMode.overview,
  });

  final Station? initialStation;
  final CommercialHomeDataSource? dataSource;
  final WaterHubEntryMode entryMode;

  @override
  State<FigmaWaterHubPage> createState() => _FigmaWaterHubPageState();
}

class _FigmaWaterHubPageState extends State<FigmaWaterHubPage> {
  final WaterService _waterService = WaterService();
  Station? _selectedStation;

  Station? get _activeStation => _selectedStation ?? widget.initialStation;

  @override
  void initState() {
    super.initState();
    if (widget.entryMode == WaterHubEntryMode.selectStation) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _openStationSelector();
      });
    }
  }

  void _publishStation(Station station) {
    logMapRuntime('water.publish-selection', station: station);
    final container = ProviderScope.containerOf(context);
    final selected = container.read(selectedContextProvider);
    if (selected?.stationId == station.id &&
        selected?.latitude == station.latitude &&
        selected?.longitude == station.longitude) {
      return;
    }
    container.read(selectedContextProvider.notifier).selectStation(station);
  }

  Future<void> _openAlert(Station? station) async {
    if (station != null) {
      _publishStation(station);
    }
    await AppNavigator.open<void>(
      context,
      AppDestination.newAlert,
      arguments: station,
    );
  }

  Future<void> _openStationSelector() async {
    final selected = await showModalBottomSheet<Station>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: FigmaFluviTokens.surface,
      builder: (sheetContext) => FractionallySizedBox(
        heightFactor: .82,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 10),
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: FigmaFluviTokens.textMuted,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Schimbă apa',
                      style: TextStyle(
                        color: FigmaFluviTokens.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Station>>(
                future: _waterService.getStations(),
                builder: (context, state) {
                  if (state.connectionState == ConnectionState.waiting &&
                      !state.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final stations = state.data ?? const <Station>[];
                  if (stations.isEmpty) {
                    return const FigmaTruthfulEmpty(
                      icon: Icons.water_drop_outlined,
                      title: 'Nicio apă disponibilă',
                      message: 'Catalogul Water nu a returnat stații.',
                    );
                  }
                  return ListView.separated(
                    key: const ValueKey('water-station-selector-list'),
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                    itemCount: stations.length,
                    separatorBuilder: (_, _) => const FigmaDivider(),
                    itemBuilder: (context, index) {
                      final station = stations[index];
                      return ListTile(
                        leading: const Icon(
                          Icons.waves_rounded,
                          color: FigmaFluviTokens.cyan,
                        ),
                        title: Text(station.name),
                        subtitle: Text(
                          station.river.isEmpty
                              ? station.waterBodyType.name
                              : station.river,
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => Navigator.pop(sheetContext, station),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
    if (!mounted || selected == null) {
      return;
    }
    _publishStation(selected);
    if (widget.entryMode == WaterHubEntryMode.selectStation) {
      Navigator.of(context).pop(selected);
      return;
    }
    setState(() => _selectedStation = selected);
  }

  Future<void> _openHistory(List<WaterLevel> history) {
    final accessTier = ProviderScope.containerOf(
      context,
      listen: false,
    ).read(fluviAccessTierProvider);
    return showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: FigmaFluviTokens.surface,
      builder: (sheetContext) =>
          WaterHistorySheet(history: history, accessTier: accessTier),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-water-hub'),
      title: 'Inteligență Hidrologică',
      subtitle: _officialContext(null, _activeStation),
      subtitleColor: const Color(0xFF38BDF8),
      action: FigmaRoundButton(
        key: const ValueKey('water-create-alert'),
        icon: Icons.notifications_none_rounded,
        tooltip: 'Creează alertă',
        onPressed: () => _openAlert(_activeStation),
      ),
      scaffoldColor: const Color(0xFF05080B),
      background: const BoxDecoration(color: Color(0xFF05080B)),
      padding: EdgeInsets.zero,
      child: FigmaRuntimeSnapshotBuilder(
        key: ValueKey('water-runtime-${_activeStation?.id ?? 'selected'}'),
        station: _activeStation,
        dataSource: widget.dataSource,
        builder: (context, snapshot, refresh) {
          final water = snapshot?.water;
          final officialObservation = resolveWaterOfficialObservationState(
            water,
          );
          final reading = officialObservation.currentReading;
          final station = _activeStation ?? snapshot?.station;
          final delta = officialObservation.deltaCm;
          final trend = officialObservation.trend;
          final trendColor = _trendColor(trend);
          final history = water?.history ?? const <WaterLevel>[];
          final source = _sourceLabel(water?.sourceName ?? reading?.sourceName);
          final freshness = _relativeAge(water?.dataAge);
          final freshnessState = resolveWaterFreshnessDisplayState(water);
          final currentStatus = waterFreshnessDisplayLabel(
            freshnessState,
            isRomanian: true,
          );
          final currentStatusColor = _waterFreshnessDisplayColor(
            freshnessState,
          );
          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: ListView(
              key: const ValueKey('figma-water-scroll'),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: _TinyStatusPill(
                    label: currentStatus,
                    color: currentStatusColor,
                    width: 92,
                  ),
                ),
                const SizedBox(height: 10),
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 133, 230),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _MonoLabel(
                        'ULTIMA OBSERVAȚIE OFICIALĂ',
                        color: Color(0xFF38BDF8),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 7,
                        runSpacing: 2,
                        crossAxisAlignment: WrapCrossAlignment.end,
                        children: [
                          Text(
                            _number(reading?.value),
                            style: const TextStyle(
                              color: FigmaFluviTokens.white,
                              fontSize: 48,
                              height: .92,
                              fontWeight: FontWeight.w600,
                              letterSpacing: -1.4,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(bottom: 5),
                            child: Text(
                              'cm',
                              style: TextStyle(
                                color: FigmaFluviTokens.textSecondary,
                                fontSize: 17,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Wrap(
                        spacing: 20,
                        runSpacing: 4,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          if (delta != null)
                            Text(
                              _signedDelta(delta),
                              style: TextStyle(
                                color: trendColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          Text(
                            _trendLabel(trend),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: FigmaFluviTokens.textSecondary,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        '$source · ${station?.name ?? 'stație'} · actualizat $freshness',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: 'IBM Plex Mono',
                          color: FigmaFluviTokens.textSecondary,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _WaterSegmentBar(
                  onStations: _openStationSelector,
                  onAlerts: () =>
                      AppNavigator.open<void>(context, AppDestination.alerts),
                ),
                const SizedBox(height: 14),
                Semantics(
                  button: true,
                  label: 'Deschide opțiunile de istoric apă',
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    key: const ValueKey('water-history-open'),
                    onTap: () => _openHistory(history),
                    child: _ReviewPanel(
                      height: _responsivePanelHeight(context, 270, 360),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Wrap(
                            alignment: WrapAlignment.spaceBetween,
                            runAlignment: WrapAlignment.center,
                            spacing: 12,
                            runSpacing: 4,
                            children: [
                              const _MonoLabel(
                                'DOAR OBSERVAȚII OFICIALE',
                                color: Color(0xFF38BDF8),
                              ),
                              _MonoLabel('${history.length} observații'),
                            ],
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Tendință nivel · 30 zile',
                            style: TextStyle(
                              color: FigmaFluviTokens.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Expanded(
                            child: history.length >= 2
                                ? _OfficialWaterChart(history: history)
                                : const FigmaTruthfulEmpty(
                                    icon: Icons.show_chart_rounded,
                                    title: 'Istoric insuficient',
                                    message:
                                        'Nu sunt suficiente observații oficiale pentru grafic.',
                                  ),
                          ),
                          const SizedBox(height: 8),
                          const Wrap(
                            alignment: WrapAlignment.spaceBetween,
                            runAlignment: WrapAlignment.center,
                            spacing: 16,
                            runSpacing: 4,
                            children: [
                              _MonoLabel('−30 Z'),
                              _MonoLabel('−15 Z'),
                              _MonoLabel('ACUM'),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Perioadele fără date nu sunt estimate.',
                            style: TextStyle(
                              fontFamily: 'IBM Plex Mono',
                              color: FigmaFluviTokens.textSecondary,
                              fontSize: 8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 78, 150),
                  radius: 16,
                  background: const Color(0xFF101C22),
                  child: const Row(
                    children: [
                      Expanded(
                        child: _WaterMetricBlock(label: 'DEBIT', value: '—'),
                      ),
                      Expanded(
                        child: _WaterMetricBlock(
                          label: 'TEMP. APĂ',
                          value: '—',
                        ),
                      ),
                      Expanded(
                        child: _WaterMetricBlock(
                          label: 'ACTUALIZAT',
                          value: 'date live',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Semantics(
                  button: true,
                  label: 'Deschide Pulsul Râului',
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => AppNavigator.open<void>(
                      context,
                      AppDestination.community,
                    ),
                    child: _ReviewPanel(
                      height: _responsivePanelHeight(context, 70, 140),
                      radius: 16,
                      accent: FigmaFluviTokens.cyan,
                      background: const Color(0xFF0A1519),
                      child: const Row(
                        children: [
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _MonoLabel(
                                  'SEMNAL COMUNITAR · SURSĂ SEPARATĂ',
                                  color: FigmaFluviTokens.cyan,
                                ),
                                SizedBox(height: 6),
                                Text(
                                  'Deschide Pulsul Râului',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: FigmaFluviTokens.white,
                                    fontSize: 15,
                                    height: 1.2,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(
                            Icons.chevron_right_rounded,
                            color: FigmaFluviTokens.cyan,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                _ContextHubActionGrid(
                  actions: [
                    _ContextHubAction(
                      keyName: 'batch3-water-open-map',
                      label: 'Vezi pe hartă',
                      icon: Icons.map_outlined,
                      onPressed: station == null
                          ? null
                          : () {
                              _publishStation(station);
                              AppNavigator.open<void>(
                                context,
                                AppDestination.contextualMap,
                                arguments: ContextualMapEntry.forStation(
                                  source: 'water',
                                  station: station,
                                ),
                              );
                            },
                    ),
                    _ContextHubAction(
                      keyName: 'batch3-water-add-alert',
                      label: 'Adaugă alertă',
                      icon: Icons.add_alert_rounded,
                      secondary: false,
                      onPressed: () => _openAlert(station),
                    ),
                    _ContextHubAction(
                      keyName: 'batch3-water-open-weather',
                      label: 'Vreme și solunar',
                      icon: Icons.cloud_outlined,
                      onPressed: () => AppNavigator.open<void>(
                        context,
                        AppDestination.weather,
                        arguments: station,
                      ),
                    ),
                    _ContextHubAction(
                      keyName: 'batch3-water-open-fluvi',
                      label: 'FluviScore',
                      icon: Icons.auto_awesome_rounded,
                      onPressed: () => AppNavigator.open<void>(
                        context,
                        AppDestination.fluvi,
                        arguments: station,
                      ),
                    ),
                  ],
                ),
                if (water?.safeDiagnosticMessage != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    water!.safeDiagnosticMessage!,
                    textAlign: TextAlign.center,
                    style: figmaBody(size: 10),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class WaterHistorySheet extends StatefulWidget {
  const WaterHistorySheet({
    super.key,
    required this.history,
    required this.accessTier,
  });

  final List<WaterLevel> history;
  final FluviAccessTier accessTier;

  @override
  State<WaterHistorySheet> createState() => _WaterHistorySheetState();
}

class _WaterHistorySheetState extends State<WaterHistorySheet> {
  WaterHistoryRange _range = WaterHistoryRange.hours24;

  bool get _canUseThirtyDays => widget.accessTier == FluviAccessTier.premium;

  void _select(WaterHistoryRange range) {
    if (range == WaterHistoryRange.days30 && !_canUseThirtyDays) return;
    setState(() {
      _range = range;
    });
  }

  @override
  Widget build(BuildContext context) {
    final filtered = realWaterHistoryForRange(widget.history, _range);
    return SingleChildScrollView(
      key: const ValueKey('water-history-scroll'),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: FigmaFluviTokens.textMuted,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Istoric apă',
              style: TextStyle(
                color: FigmaFluviTokens.white,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '24h și 3 zile în Free · 30 zile în Pro',
              style: figmaBody(size: 11),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FigmaPill(
                  key: const ValueKey('water-history-range-24h'),
                  label: '24h',
                  active: _range == WaterHistoryRange.hours24,
                  onTap: () => _select(WaterHistoryRange.hours24),
                ),
                FigmaPill(
                  key: const ValueKey('water-history-range-3d'),
                  label: '3 zile',
                  active: _range == WaterHistoryRange.days3,
                  onTap: () => _select(WaterHistoryRange.days3),
                ),
                FigmaPill(
                  key: const ValueKey('water-history-range-30d'),
                  label: '30 zile · PRO',
                  active: _range == WaterHistoryRange.days30,
                  color: FigmaFluviTokens.amber,
                  onTap: _canUseThirtyDays
                      ? () => _select(WaterHistoryRange.days30)
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              '${filtered.length} observații reale',
              key: const ValueKey('water-history-observation-count'),
              style: figmaBody(size: 10),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 180,
              child: filtered.length >= 2
                  ? _OfficialWaterChart(history: filtered)
                  : const FigmaTruthfulEmpty(
                      icon: Icons.show_chart_rounded,
                      title: 'Istoric insuficient',
                      message: 'Sunt necesare cel puțin două observații reale.',
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WaterMetricBlock extends StatelessWidget {
  const _WaterMetricBlock({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _MonoLabel(label),
      const SizedBox(height: 6),
      Text(
        value,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: FigmaFluviTokens.white,
          fontSize: 13,
          height: 1.2,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  );
}

class FigmaStationPage extends StatelessWidget {
  const FigmaStationPage({super.key, this.station});

  final Station? station;

  @override
  Widget build(BuildContext context) =>
      FigmaWaterHubPage(initialStation: station);
}

class FigmaWeatherHubPage extends StatelessWidget {
  const FigmaWeatherHubPage({super.key, this.initialStation, this.dataSource});

  final Station? initialStation;
  final CommercialHomeDataSource? dataSource;

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-weather-hub'),
      title: 'Vreme & Solunar',
      subtitle: _stationContext(null, initialStation),
      action: FigmaRoundButton(
        key: const ValueKey('weather-open-alerts'),
        icon: Icons.notifications_none_rounded,
        tooltip: 'Alerte meteo',
        onPressed: () =>
            AppNavigator.open<void>(context, AppDestination.alerts),
      ),
      scaffoldColor: const Color(0xFF05080B),
      background: const BoxDecoration(color: Color(0xFF05080B)),
      padding: EdgeInsets.zero,
      child: FigmaRuntimeSnapshotBuilder(
        station: initialStation,
        dataSource: dataSource,
        builder: (context, snapshot, refresh) {
          final result = snapshot?.weather;
          final data = result?.data;
          final station = initialStation ?? snapshot?.station;
          final hours = data?.hourlyForecast ?? const <WeatherForecastHour>[];
          final score = snapshot?.score;
          final bestTime = score?.hasEnoughData == true ? score!.bestTime : '—';
          final confidence = score?.hasEnoughData == true
              ? '${score!.confidence}%'
              : 'indisponibilă';
          final windRisk = data == null
              ? 'Vânt indisponibil'
              : data.windGusts >= 28
              ? 'Vânt dificil · rafale ${data.windGusts.round()} km/h'
              : 'Vânt ${data.windSpeed.round()} km/h acum';
          final windDetail = data == null
              ? 'Nu există date meteo live.'
              : '${_windDirectionRo(data.windDirectionLabel)} · rafale ${data.windGusts.round()} km/h';
          final pressureTitle = data?.pressure == null
              ? 'Presiune indisponibilă'
              : 'Presiune ${data!.pressure!.round()} hPa';
          final pressureDetail = data?.pressure == null
              ? 'Sursa meteo nu a returnat presiunea.'
              : 'Valoare curentă · fără trend inventat';
          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: ListView(
              key: const ValueKey('figma-weather-scroll'),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
              children: [
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 209, 372),
                  radius: 20,
                  background: const Color(0xFF0D171C),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _MonoLabel('CONDIȚII ACTUALE'),
                      const SizedBox(height: 10),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 2,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    children: [
                                      if (data != null)
                                        Icon(
                                          _conditionIcon(data.condition),
                                          color: FigmaFluviTokens.cyan,
                                          size: 28,
                                        ),
                                      Text(
                                        data == null
                                            ? '—'
                                            : '${data.temperature.round()}°',
                                        style: const TextStyle(
                                          color: FigmaFluviTokens.white,
                                          fontSize: 54,
                                          height: .95,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: -1.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    data == null
                                        ? 'Date meteo indisponibile'
                                        : _localizedWeatherCondition(
                                            context,
                                            data.condition,
                                          ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: FigmaFluviTokens.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 136,
                              child: _ReviewPanel(
                                height: _responsivePanelHeight(
                                  context,
                                  98,
                                  160,
                                ),
                                padding: const EdgeInsets.all(13),
                                radius: 16,
                                accent: FigmaFluviTokens.cyan,
                                background: const Color(0xFF103F42),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const _MonoLabel(
                                      'INTERVAL OPTIM',
                                      color: FigmaFluviTokens.cyan,
                                    ),
                                    const Spacer(),
                                    Text(
                                      bestTime,
                                      maxLines: 2,
                                      softWrap: true,
                                      style: const TextStyle(
                                        color: FigmaFluviTokens.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Încredere · $confidence',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: FigmaFluviTokens.textSecondary,
                                        fontSize: 9,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: _WeatherMetric(
                              icon: Icons.north_east_rounded,
                              label: 'VÂNT',
                              value: data == null
                                  ? '—'
                                  : '${data.windSpeed.round()} km/h',
                              color: FigmaFluviTokens.amber,
                            ),
                          ),
                          Expanded(
                            child: _WeatherMetric(
                              icon: Icons.water_drop_outlined,
                              label: 'PLOAIE',
                              value: data == null
                                  ? '—'
                                  : '${data.precipitationProbability.round()}%',
                              color: const Color(0xFF2DB9F2),
                            ),
                          ),
                          Expanded(
                            child: _WeatherMetric(
                              icon: Icons.adjust_rounded,
                              label: 'PRESIUNE',
                              value: data?.pressure == null
                                  ? '—'
                                  : '${data!.pressure!.round()} hPa',
                              color: FigmaFluviTokens.green,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const _MonoLabel('URMĂTOARELE 12 ORE'),
                const SizedBox(height: 12),
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 108, 190),
                  radius: 18,
                  background: const Color(0xFF0D171C),
                  child: _HourlyStrip(hours: hours),
                ),
                const SizedBox(height: 22),
                const _MonoLabel('DECIZIE PESCUIT'),
                const SizedBox(height: 12),
                _FishingDecisionCard(
                  icon: Icons.north_east_rounded,
                  color: FigmaFluviTokens.amber,
                  title: windRisk,
                  subtitle: windDetail,
                ),
                const SizedBox(height: 10),
                _FishingDecisionCard(
                  icon: Icons.adjust_rounded,
                  color: FigmaFluviTokens.green,
                  title: pressureTitle,
                  subtitle: pressureDetail,
                ),
                const SizedBox(height: 14),
                KeyedSubtree(
                  key: const ValueKey('batch3-weather-solunar-section'),
                  child: _ReviewPanel(
                    height: _responsivePanelHeight(context, 82, 150),
                    radius: 18,
                    background: const Color(0xFF101D23),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Prognoză extinsă',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: FigmaFluviTokens.white,
                                  fontSize: 15,
                                  height: 1.2,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 6),
                              Text(
                                '72h vânt · ploaie · presiune · răsărit · solunar',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: FigmaFluviTokens.textSecondary,
                                  fontSize: 11,
                                  height: 1.25,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.timeline_rounded,
                          color: FigmaFluviTokens.cyan,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                _ReviewPanel(
                  radius: 16,
                  background: const Color(0xFF0D171C),
                  child: Wrap(
                    spacing: 18,
                    runSpacing: 10,
                    children: [
                      _SolunarDatum(
                        label: 'RĂSĂRIT',
                        value: data?.sunrise == null
                            ? '—'
                            : '${data!.sunrise!.hour.toString().padLeft(2, '0')}:${data.sunrise!.minute.toString().padLeft(2, '0')}',
                      ),
                      _SolunarDatum(
                        label: 'APUS',
                        value: data?.sunset == null
                            ? '—'
                            : '${data!.sunset!.hour.toString().padLeft(2, '0')}:${data.sunset!.minute.toString().padLeft(2, '0')}',
                      ),
                      _SolunarDatum(
                        label: 'LUNĂ',
                        value: data?.moonPhase ?? '—',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                KeyedSubtree(
                  key: const ValueKey('batch3-weather-actions'),
                  child: _ContextHubActionGrid(
                    actions: [
                      _ContextHubAction(
                        keyName: 'batch3-weather-open-water',
                        label: 'Inteligență hidrologică',
                        icon: Icons.water_rounded,
                        onPressed: () => AppNavigator.open<void>(
                          context,
                          AppDestination.water,
                          arguments: station,
                        ),
                      ),
                      _ContextHubAction(
                        keyName: 'batch3-weather-open-map',
                        label: 'Hartă completă',
                        icon: Icons.map_outlined,
                        onPressed: station == null
                            ? null
                            : () => AppNavigator.open<void>(
                                context,
                                AppDestination.contextualMap,
                                arguments: ContextualMapEntry.forStation(
                                  source: 'weather',
                                  station: station,
                                ),
                              ),
                      ),
                      _ContextHubAction(
                        keyName: 'batch3-weather-open-fluvi',
                        label: 'FluviScore',
                        icon: Icons.auto_awesome_rounded,
                        secondary: false,
                        onPressed: () => AppNavigator.open<void>(
                          context,
                          AppDestination.fluvi,
                          arguments: station,
                        ),
                      ),
                    ],
                  ),
                ),
                if (result?.safeDiagnosticMessage != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    result!.safeDiagnosticMessage!,
                    textAlign: TextAlign.center,
                    style: figmaBody(size: 10),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class FigmaFluviHubPage extends StatelessWidget {
  const FigmaFluviHubPage({super.key, this.initialStation, this.dataSource});

  final Station? initialStation;
  final CommercialHomeDataSource? dataSource;

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-fluvi-hub'),
      title: 'FluviScore',
      subtitle: _stationContext(null, initialStation),
      action: const _TinyStatusPill(
        label: 'EXPLICABIL',
        color: FigmaFluviTokens.cyan,
        width: 88,
      ),
      scaffoldColor: const Color(0xFF05080A),
      background: const BoxDecoration(color: Color(0xFF05080A)),
      padding: EdgeInsets.zero,
      child: FigmaRuntimeSnapshotBuilder(
        station: initialStation,
        dataSource: dataSource,
        builder: (context, snapshot, refresh) {
          final score = snapshot?.score;
          final station = initialStation ?? snapshot?.station;
          final hasScore = score?.hasEnoughData == true;
          final scoreValue = hasScore ? score!.score!.round().toString() : '—';
          final confidence = hasScore ? score!.confidence : 0;
          final recommendation = hasScore
              ? _localizedScoreText(context, score!.recommendation)
              : 'Nu sunt suficiente date';
          final positive = score?.positiveFactors ?? const <String>[];
          final negative = score?.negativeFactors ?? const <String>[];
          final missing = score?.missingFactors ?? const <String>[];
          final factors = <_ScoreFactor>[
            for (final item in positive.take(2))
              _ScoreFactor(
                label: _localizedScoreText(context, item),
                detail: 'Semnal real favorabil',
                color: FigmaFluviTokens.green,
                pill: 'POZITIV',
              ),
            for (final item in negative.take(2))
              _ScoreFactor(
                label: _localizedScoreText(context, item),
                detail: 'Semnal real nefavorabil',
                color: FigmaFluviTokens.amber,
                pill: 'RISC',
              ),
            for (final item in missing.take(2))
              _ScoreFactor(
                label: _localizedScoreText(context, item),
                detail: 'Intrare lipsă · scorul nu este completat artificial',
                color: FigmaFluviTokens.red,
                pill: 'DATE PUȚINE',
              ),
          ].take(4).toList(growable: false);
          final confidenceColor = confidence >= 75
              ? FigmaFluviTokens.green
              : confidence >= 45
              ? FigmaFluviTokens.amber
              : FigmaFluviTokens.red;

          return RefreshIndicator(
            onRefresh: () async => refresh(),
            child: ListView(
              key: const ValueKey('figma-fluvi-scroll'),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
              children: [
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 167, 300),
                  radius: 20,
                  background: const Color(0xFF0B1115),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: _MonoLabel('CONDIȚII DE PESCUIT ACUM'),
                          ),
                          _TinyStatusPill(
                            label: hasScore
                                ? 'ÎNCREDERE $confidence%'
                                : 'DATE PUȚINE',
                            color: confidenceColor,
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (MediaQuery.textScalerOf(context).scale(1) < 1.5)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              scoreValue,
                              style: const TextStyle(
                                color: FigmaFluviTokens.white,
                                fontSize: 54,
                                height: .95,
                                fontWeight: FontWeight.w600,
                                letterSpacing: -1.2,
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 6, bottom: 5),
                              child: Text(
                                '/100',
                                style: TextStyle(
                                  color: FigmaFluviTokens.cyan,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        )
                      else
                        Wrap(
                          crossAxisAlignment: WrapCrossAlignment.end,
                          spacing: 6,
                          runSpacing: 2,
                          children: [
                            Text(
                              scoreValue,
                              style: const TextStyle(
                                color: FigmaFluviTokens.white,
                                fontSize: 54,
                                height: .95,
                                fontWeight: FontWeight.w600,
                                letterSpacing: -1.2,
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(bottom: 5),
                              child: Text(
                                '/100',
                                style: TextStyle(
                                  color: FigmaFluviTokens.cyan,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      const Spacer(),
                      Text(
                        recommendation,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: hasScore
                              ? FigmaFluviTokens.green
                              : FigmaFluviTokens.textSecondary,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        hasScore
                            ? 'Scor calculat din intrările disponibile acum.'
                            : 'Fluvi nu inventează scorul când lipsesc intrările.',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: FigmaFluviTokens.textSecondary,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const _MonoLabel('DE CE ACEST SCOR'),
                const SizedBox(height: 10),
                if (factors.isEmpty)
                  const _ReviewPanel(
                    height: 88,
                    child: Center(
                      child: Text(
                        'Nu există încă factori explicabili disponibili.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: FigmaFluviTokens.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  )
                else
                  for (var index = 0; index < factors.length; index++) ...[
                    if (index > 0) const SizedBox(height: 8),
                    _ScoreFactorCard(factor: factors[index]),
                  ],
                const SizedBox(height: 16),
                _ReviewPanel(
                  height: _responsivePanelHeight(context, 82, 150),
                  radius: 16,
                  background: const Color(0xFF070E11),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Proveniența scorului',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: FigmaFluviTokens.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'Scor determinist · limită 0–100\nModelul IA nu calculează scorul numeric.',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: FigmaFluviTokens.textSecondary,
                          fontSize: 11,
                          height: 1.25,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _ContextHubActionGrid(
                  actions: [
                    _ContextHubAction(
                      keyName: 'batch3-fluvi-open-water',
                      label: 'Inteligență hidrologică',
                      icon: Icons.water_rounded,
                      onPressed: () => AppNavigator.open<void>(
                        context,
                        AppDestination.water,
                        arguments: station,
                      ),
                    ),
                    _ContextHubAction(
                      keyName: 'batch3-fluvi-open-weather',
                      label: 'Vreme și solunar',
                      icon: Icons.cloud_outlined,
                      onPressed: () => AppNavigator.open<void>(
                        context,
                        AppDestination.weather,
                        arguments: station,
                      ),
                    ),
                    _ContextHubAction(
                      keyName: 'batch3-fluvi-open-map',
                      label: 'Hartă completă',
                      icon: Icons.map_outlined,
                      onPressed: station == null
                          ? null
                          : () => AppNavigator.open<void>(
                              context,
                              AppDestination.contextualMap,
                              arguments: ContextualMapEntry.forStation(
                                source: 'fluvi-score',
                                station: station,
                              ),
                            ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class FigmaAskFluviPage extends StatefulWidget {
  const FigmaAskFluviPage({super.key});

  @override
  State<FigmaAskFluviPage> createState() => _FigmaAskFluviPageState();
}

class _FigmaAskFluviPageState extends State<FigmaAskFluviPage> {
  final _controller = TextEditingController();
  bool _submitted = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-ask-fluvi'),
      title: 'Întreabă Fluvi',
      eyebrow: 'CONTEXT REAL',
      child: ListView(
        children: [
          FigmaSurface(
            accent: FigmaFluviTokens.violet,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(
                      Icons.auto_awesome_rounded,
                      color: FigmaFluviTokens.violet,
                    ),
                    SizedBox(width: 9),
                    Text(
                      'Fluvi',
                      style: TextStyle(
                        color: FigmaFluviTokens.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Întreabă despre condiții, apă sau pregătirea unei partide. Răspunsurile AI nu sunt conectate în această versiune și nu vor fi fabricate.',
                  style: figmaBody(size: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _controller,
            minLines: 4,
            maxLines: 7,
            decoration: const InputDecoration(
              hintText: 'Ex.: Cum influențează scăderea apei partida de mâine?',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 12),
          FigmaPrimaryButton(
            label: 'Trimite întrebarea',
            icon: Icons.send_rounded,
            onPressed: () {
              FocusScope.of(context).unfocus();
              setState(() => _submitted = true);
            },
          ),
          if (_submitted) ...[
            const SizedBox(height: 18),
            const FigmaTruthfulEmpty(
              icon: Icons.cloud_off_rounded,
              title: 'Serviciul AI nu este conectat',
              message:
                  'Întrebarea nu a fost trimisă și nu s-a generat un răspuns demonstrativ.',
            ),
          ],
        ],
      ),
    );
  }
}

class FigmaReservoirPage extends StatelessWidget {
  const FigmaReservoirPage({super.key, this.label});

  final String? label;

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-reservoir-detail'),
      title: label ?? 'Acumulare',
      eyebrow: 'BARAJ ȘI LAC',
      child: ListView(
        children: [
          const FigmaTruthfulEmpty(
            icon: Icons.waves_rounded,
            title: 'Date operaționale indisponibile',
            message:
                'Nivelul, umplerea, afluentul și debitul evacuat vor fi afișate numai din surse reale conectate.',
          ),
          const SizedBox(height: 16),
          FigmaSurface(
            child: Column(
              children: const [
                Row(
                  children: [
                    Expanded(
                      child: FigmaMetric(value: '—', label: 'grad umplere'),
                    ),
                    Expanded(
                      child: FigmaMetric(
                        value: '—',
                        label: 'afluent',
                        alignment: CrossAxisAlignment.center,
                      ),
                    ),
                    Expanded(
                      child: FigmaMetric(
                        value: '—',
                        label: 'evacuare',
                        alignment: CrossAxisAlignment.end,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FigmaHydropowerPage extends StatelessWidget {
  const FigmaHydropowerPage({super.key, this.label});

  final String? label;

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-hydropower-detail'),
      title: label ?? 'Hidrocentrală',
      eyebrow: 'CONTEXT HIDROTEHNIC',
      child: const FigmaTruthfulEmpty(
        icon: Icons.electric_bolt_rounded,
        title: 'Sursa operațională nu este conectată',
        message: 'Nu afișăm producție, debite sau manevre neverificate.',
      ),
    );
  }
}
