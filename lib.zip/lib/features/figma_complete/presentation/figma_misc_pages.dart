import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/context/selected_context.dart';
import '../../../core/map/pending_map_camera.dart';
import '../../../core/navigation/app_destination.dart';
import '../../../core/navigation/app_navigator.dart';
import '../../../core/navigation/map_entry.dart';
import '../../../models/station.dart';
import '../../../services/alert_rule_repository.dart';
import '../../../services/billing_repository.dart';
import '../../../services/map_search_service.dart';
import '../../../services/water_service.dart';
import 'figma_foundation.dart';

class FigmaGlobalSearchPage extends StatefulWidget {
  const FigmaGlobalSearchPage({
    super.key,
    this.waterService,
    this.searchService = const MapSearchService(),
  });

  final WaterService? waterService;
  final MapSearchService searchService;

  @override
  State<FigmaGlobalSearchPage> createState() => _FigmaGlobalSearchPageState();
}

class _FigmaGlobalSearchPageState extends State<FigmaGlobalSearchPage> {
  late final WaterService _waterService;
  late Future<List<Station>> _future;
  Future<List<MapSearchResult>> _placesFuture = Future.value(const []);
  final _query = TextEditingController();
  Timer? _searchDebounce;
  int _filter = 0;

  @override
  void initState() {
    super.initState();
    _waterService = widget.waterService ?? WaterService();
    _future = _waterService.getStations();
    _query.addListener(_onChanged);
  }

  void _onChanged() {
    _searchDebounce?.cancel();
    final query = _query.text.trim();
    setState(() {
      if (query.length < 2) {
        _placesFuture = Future.value(const []);
      }
    });
    if (query.length < 2) return;
    _searchDebounce = Timer(const Duration(milliseconds: 300), () {
      if (!mounted || query != _query.text.trim()) return;
      setState(() {
        _placesFuture = widget.searchService.search(query);
      });
    });
  }

  @override
  void dispose() {
    _query.removeListener(_onChanged);
    _searchDebounce?.cancel();
    _query.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = _query.text.trim().toLowerCase();
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-global-search'),
      title: 'Căutare',
      eyebrow: 'GLOBAL',
      child: FutureBuilder<List<Station>>(
        future: _future,
        builder: (context, state) {
          final all = state.data ?? const <Station>[];
          final filteredStations = all
              .where((station) {
                if (_filter == 1 &&
                    station.waterBodyType != WaterBodyType.river) {
                  return false;
                }
                if (_filter == 3) return false;
                if (query.isEmpty) return true;
                final haystack =
                    '${station.name} ${station.river} ${station.id}'
                        .toLowerCase();
                return haystack.contains(query);
              })
              .take(50)
              .toList(growable: false);
          return FutureBuilder<List<MapSearchResult>>(
            future: _placesFuture,
            builder: (context, placeState) {
              final places = _filter == 1 || _filter == 2
                  ? const <MapSearchResult>[]
                  : placeState.data ?? const <MapSearchResult>[];
              final isSearchingPlaces =
                  query.length >= 2 &&
                  placeState.connectionState == ConnectionState.waiting;
              final resultCount = filteredStations.length + places.length;
              return Column(
                children: [
                  TextField(
                    key: const ValueKey('figma-global-search-field'),
                    controller: _query,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: 'Caută ape, stații, baraje, locuri…',
                      prefixIcon: Icon(Icons.search_rounded),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 38,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        FigmaPill(
                          label: 'Toate',
                          active: _filter == 0,
                          onTap: () => setState(() => _filter = 0),
                        ),
                        const SizedBox(width: 8),
                        FigmaPill(
                          label: 'Ape',
                          active: _filter == 1,
                          onTap: () => setState(() => _filter = 1),
                        ),
                        const SizedBox(width: 8),
                        FigmaPill(
                          label: 'Stații',
                          active: _filter == 2,
                          onTap: () => setState(() => _filter = 2),
                        ),
                        const SizedBox(width: 8),
                        FigmaPill(
                          label: 'Locuri',
                          active: _filter == 3,
                          onTap: () => setState(() => _filter = 3),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child:
                        state.connectionState == ConnectionState.waiting &&
                            !state.hasData
                        ? const Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : resultCount == 0 && isSearchingPlaces
                        ? const Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : resultCount == 0
                        ? const FigmaTruthfulEmpty(
                            icon: Icons.search_off_rounded,
                            title: 'Niciun rezultat',
                            message:
                                'Căutarea globală nu a găsit un loc sau o stație reală.',
                          )
                        : ListView.separated(
                            itemCount: resultCount,
                            separatorBuilder: (_, _) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              if (index < filteredStations.length) {
                                return _SearchResultTile(
                                  station: filteredStations[index],
                                );
                              }
                              return _PlaceSearchResultTile(
                                result: places[index - filteredStations.length],
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Locurile mută doar camera. Locația GPS rămâne neschimbată.',
                    style: figmaBody(size: 9),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _SearchResultTile extends StatelessWidget {
  const _SearchResultTile({required this.station});

  final Station station;

  @override
  Widget build(BuildContext context) {
    return FigmaSurface(
      onTap: () => AppNavigator.open(
        context,
        AppDestination.contextualMap,
        arguments: ContextualMapEntry.forStation(
          source: 'global-search',
          station: station,
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 9,
            height: 9,
            decoration: const BoxDecoration(
              color: FigmaFluviTokens.cyan,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  station.river.trim().isEmpty
                      ? station.name
                      : '${station.name} · ${station.river}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: FigmaFluviTokens.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  station.waterBodyType == WaterBodyType.lake
                      ? 'Lac / acumulare'
                      : 'Stație hidrometrică',
                  style: figmaBody(size: 9),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.chevron_right_rounded,
            color: FigmaFluviTokens.textSecondary,
          ),
        ],
      ),
    );
  }
}

class _PlaceSearchResultTile extends StatelessWidget {
  const _PlaceSearchResultTile({required this.result});

  final MapSearchResult result;

  @override
  Widget build(BuildContext context) {
    return FigmaSurface(
      onTap: () => AppNavigator.open(
        context,
        AppDestination.contextualMap,
        arguments: ContextualMapEntry.forTarget(
          source: 'global-search',
          target: RuntimeMapCameraTarget(
            source: 'global-search',
            entityId: result.name,
            latitude: result.latitude,
            longitude: result.longitude,
            zoom: 13.5,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          const Icon(
            Icons.location_on_outlined,
            size: 19,
            color: FigmaFluviTokens.cyan,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: FigmaFluviTokens.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (result.description?.trim().isNotEmpty == true) ...[
                  const SizedBox(height: 3),
                  Text(
                    result.description!.trim(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: figmaBody(size: 9),
                  ),
                ],
              ],
            ),
          ),
          const Icon(Icons.map_outlined, color: FigmaFluviTokens.textSecondary),
        ],
      ),
    );
  }
}

class FigmaAlertEditorPage extends ConsumerStatefulWidget {
  const FigmaAlertEditorPage({
    super.key,
    this.station,
    this.rule,
    this.repository = const AlertRuleRepository(),
  });

  final Station? station;
  final AlertRule? rule;
  final AlertRuleRepository repository;

  @override
  ConsumerState<FigmaAlertEditorPage> createState() =>
      _FigmaAlertEditorPageState();
}

class _FigmaAlertEditorPageState extends ConsumerState<FigmaAlertEditorPage> {
  late AlertRuleKind _kind;
  late TextEditingController _threshold;
  bool _enabled = true;
  bool _saving = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _kind = widget.rule?.kind ?? AlertRuleKind.levelAbove;
    _enabled = widget.rule?.enabled ?? true;
    _threshold = TextEditingController(
      text: widget.rule?.threshold?.toStringAsFixed(0) ?? '',
    );
  }

  @override
  void dispose() {
    _threshold.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final selected = ref.read(selectedContextProvider);
    final station = widget.station;
    final entityId =
        widget.rule?.entityId ??
        station?.id ??
        selected?.stationId ??
        selected?.waterId;
    final entityLabel =
        widget.rule?.entityLabel ?? station?.name ?? selected?.primaryLabel;
    if (entityId == null || entityLabel == null) {
      setState(
        () => _message = 'Selectează mai întâi o apă sau o stație reală.',
      );
      return;
    }
    final needsThreshold = _kind != AlertRuleKind.communityReport;
    final threshold = needsThreshold
        ? double.tryParse(_threshold.text.replaceAll(',', '.'))
        : null;
    if (needsThreshold && threshold == null) {
      setState(() => _message = 'Introdu un prag numeric valid.');
      return;
    }
    setState(() {
      _saving = true;
      _message = null;
    });
    final rule = AlertRule(
      id: widget.rule?.id ?? 'local-${DateTime.now().microsecondsSinceEpoch}',
      entityId: entityId,
      entityLabel: entityLabel,
      kind: _kind,
      createdAt: widget.rule?.createdAt ?? DateTime.now(),
      threshold: threshold,
      enabled: _enabled,
    );
    try {
      await widget.repository.save(rule);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on Exception {
      if (mounted) {
        setState(() {
          _saving = false;
          _message = 'Alerta nu a putut fi salvată. Încearcă din nou.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final selected = ref.watch(selectedContextProvider);
    final label =
        widget.rule?.entityLabel ??
        widget.station?.name ??
        selected?.primaryLabel ??
        'Nicio entitate selectată';
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-alert-editor'),
      title: widget.rule == null ? 'Alertă nouă' : 'Editează alerta',
      eyebrow: 'REGULĂ LOCALĂ',
      child: ListView(
        children: [
          FigmaSurface(
            child: Row(
              children: [
                const Icon(Icons.water_rounded, color: FigmaFluviTokens.cyan),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: FigmaFluviTokens.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const FigmaSectionLabel('Tip alertă'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FigmaPill(
                label: 'Nivel peste',
                active: _kind == AlertRuleKind.levelAbove,
                onTap: () => setState(() => _kind = AlertRuleKind.levelAbove),
              ),
              FigmaPill(
                label: 'Nivel sub',
                active: _kind == AlertRuleKind.levelBelow,
                onTap: () => setState(() => _kind = AlertRuleKind.levelBelow),
              ),
              FigmaPill(
                label: 'Schimbare rapidă',
                active: _kind == AlertRuleKind.rapidChange,
                onTap: () => setState(() => _kind = AlertRuleKind.rapidChange),
              ),
              FigmaPill(
                label: 'Raport în zonă',
                active: _kind == AlertRuleKind.communityReport,
                onTap: () =>
                    setState(() => _kind = AlertRuleKind.communityReport),
              ),
            ],
          ),
          if (_kind != AlertRuleKind.communityReport) ...[
            const SizedBox(height: 16),
            TextField(
              controller: _threshold,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
                signed: true,
              ),
              decoration: InputDecoration(
                labelText: _kind == AlertRuleKind.rapidChange
                    ? 'Prag cm/24h'
                    : 'Prag nivel cm',
              ),
            ),
          ],
          const SizedBox(height: 12),
          FigmaSurface(
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Alertă activă',
                    style: TextStyle(
                      color: FigmaFluviTokens.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Switch(
                  value: _enabled,
                  onChanged: (value) => setState(() => _enabled = value),
                ),
              ],
            ),
          ),
          if (_message != null) ...[
            const SizedBox(height: 12),
            Text(
              _message!,
              textAlign: TextAlign.center,
              style: figmaBody(color: FigmaFluviTokens.red, size: 11),
            ),
          ],
          const SizedBox(height: 18),
          FigmaPrimaryButton(
            label: _saving ? 'Se salvează…' : 'Salvează alerta',
            icon: Icons.notifications_active_rounded,
            onPressed: _saving ? null : _save,
          ),
        ],
      ),
    );
  }
}

class FigmaRestoreResultPage extends StatelessWidget {
  const FigmaRestoreResultPage({super.key, required this.result});

  final BillingRestoreResult result;

  @override
  Widget build(BuildContext context) {
    final isRo = Localizations.localeOf(context).languageCode == 'ro';
    final (icon, title, message, color) = switch (result) {
      BillingRestoreResult.restored => (
        Icons.check_circle_rounded,
        isRo ? 'Premium restaurat' : 'Premium restored',
        isRo
            ? 'Drepturile Premium au fost restaurate.'
            : 'Premium entitlement was restored for this session.',
        FigmaFluviTokens.green,
      ),
      BillingRestoreResult.nothingToRestore => (
        Icons.info_outline_rounded,
        isRo ? 'Nicio achiziție găsită' : 'No purchase found',
        isRo
            ? 'Magazinul nu a returnat o achiziție eligibilă.'
            : 'The store returned no eligible purchase.',
        FigmaFluviTokens.amber,
      ),
      BillingRestoreResult.unavailable => (
        Icons.cloud_off_rounded,
        isRo ? 'Restaurarea nu este disponibilă' : 'Restore is unavailable',
        isRo
            ? 'Repository-ul de billing nu este conectat.'
            : 'The billing repository is not connected; the plan was not changed.',
        FigmaFluviTokens.textMuted,
      ),
      BillingRestoreResult.error => (
        Icons.error_outline_rounded,
        isRo ? 'Restaurarea a eșuat' : 'Restore failed',
        isRo
            ? 'Planul nu a fost modificat.'
            : 'The plan was not changed. Try again later.',
        FigmaFluviTokens.red,
      ),
    };
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-restore-result'),
      title: isRo ? 'Rezultat restaurare' : 'Restore result',
      eyebrow: 'FLUVIAI PRO',
      child: Center(
        child: FigmaSurface(
          accent: color,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 46),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: FigmaFluviTokens.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: figmaBody(size: 12),
              ),
              const SizedBox(height: 16),
              FigmaPrimaryButton(
                label: isRo ? 'Continuă la profil' : 'Continue to profile',
                onPressed: () =>
                    AppNavigator.open(context, AppDestination.profile),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FigmaReportConfirmedPage extends StatelessWidget {
  const FigmaReportConfirmedPage({super.key, required this.stillValid});

  final bool stillValid;

  @override
  Widget build(BuildContext context) {
    return FigmaCanonicalScaffold(
      key: const ValueKey('figma-report-confirmed'),
      title: 'Confirmare raport',
      eyebrow: 'ÎNCREDERE COMUNITATE',
      child: FigmaTruthfulEmpty(
        icon: stillValid ? Icons.verified_rounded : Icons.report_off_outlined,
        title: stillValid ? 'Raport confirmat' : 'Raport marcat ca expirat',
        message: stillValid
            ? 'Confirmarea reală a fost înregistrată.'
            : 'Marcajul real a fost înregistrat.',
        actionLabel: 'Înapoi la Comunitate',
        onAction: () => AppNavigator.open(context, AppDestination.community),
      ),
    );
  }
}

class FigmaFavoriteCollectionPage extends StatelessWidget {
  const FigmaFavoriteCollectionPage({super.key, this.label});

  final String? label;

  @override
  Widget build(BuildContext context) => FigmaCanonicalScaffold(
    key: const ValueKey('figma-favorite-collection'),
    title: label ?? 'Colecție',
    eyebrow: 'FAVORITE',
    child: const FigmaTruthfulEmpty(
      icon: Icons.folder_special_outlined,
      title: 'Colecție goală',
      message: 'Salvează entități reale din hartă pentru a construi colecția.',
    ),
  );
}
