import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';

class WeatherCardPremium extends StatelessWidget {
  const WeatherCardPremium({
    super.key,
    this.temperature = 24,
    this.condition = 'Sunny',
    this.wind = '9 km/h',
    this.humidity = '58%',
    this.pressure = '1018 hPa',
    this.visibility = '12 km',
  });

  final int temperature;
  final String condition;
  final String wind;
  final String humidity;
  final String pressure;
  final String visibility;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.wb_sunny_rounded, color: AppColors.weather),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('Weather', style: AppTextStyles.cardTitle),
                ),
              ],
            ),

            const SizedBox(height: 14),

            Row(
              children: [
                const Icon(
                  Icons.wb_sunny_rounded,
                  color: AppColors.weather,
                  size: 42,
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$temperature°', style: AppTextStyles.bigValue),
                    Text(condition, style: AppTextStyles.location),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 18),

            Row(
              children: [
                Expanded(
                  child: _InfoTile(icon: Icons.air, title: 'Wind', value: wind),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _InfoTile(
                    icon: Icons.water_drop_outlined,
                    title: 'Humidity',
                    value: humidity,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: _InfoTile(
                    icon: Icons.speed,
                    title: 'Pressure',
                    value: pressure,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _InfoTile(
                    icon: Icons.visibility_outlined,
                    title: 'Visibility',
                    value: visibility,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.title,
    required this.value,
  });

  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.background.withOpacity(.35),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.weather),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTextStyles.caption),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
