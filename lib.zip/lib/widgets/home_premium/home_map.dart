import 'package:flutter/material.dart';

import '../home/map_preview.dart';

class HomePremiumMap extends StatelessWidget {
  const HomePremiumMap({super.key, this.onTap, this.child});

  final VoidCallback? onTap;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: Stack(
        fit: StackFit.expand,
        children: [
          MapPreview(
            onTap: onTap,
            child: child ?? Container(color: const Color(0xFF16212B)),
          ),

          IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(.10),
                    Colors.transparent,
                    Colors.black.withOpacity(.35),
                  ],
                ),
              ),
            ),
          ),

          // SEARCH BAR
          Positioned(
            left: 16,
            right: 16,
            top: 16,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.45),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white10),
              ),
              child: const Row(
                children: [
                  SizedBox(width: 14),
                  Icon(Icons.search_rounded, color: Colors.white70, size: 22),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Search river, lake or city...',
                      style: TextStyle(color: Colors.white60, fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // RIGHT BUTTONS
          Positioned(
            right: 16,
            top: 74,
            child: Column(
              children: const [
                _FloatingButton(Icons.my_location_rounded),
                SizedBox(height: 10),
                _FloatingButton(Icons.layers_rounded),
                SizedBox(height: 10),
                _FloatingButton(Icons.filter_alt_rounded),
              ],
            ),
          ),

          // LOCATION CHIP
          Positioned(
            left: 16,
            bottom: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.50),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.location_on_rounded,
                    color: Color(0xFF67D04B),
                    size: 18,
                  ),
                  SizedBox(width: 6),
                  Text(
                    'Current Location',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // LIVE CHIP
          Positioned(
            right: 16,
            bottom: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF67D04B),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.sensors, size: 16, color: Colors.black),
                  SizedBox(width: 5),
                  Text(
                    'LIVE',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FloatingButton extends StatelessWidget {
  const _FloatingButton(this.icon);

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(.55),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {},
        child: SizedBox(
          width: 50,
          height: 50,
          child: Icon(icon, color: Colors.white, size: 24),
        ),
      ),
    );
  }
}
