import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';

class RecentCatchesCardPremium extends StatelessWidget {
  const RecentCatchesCardPremium({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.phishing_rounded, color: Colors.orange),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('Recent Catches', style: AppTextStyles.cardTitle),
                ),
                TextButton(onPressed: () {}, child: const Text('See all')),
              ],
            ),

            const SizedBox(height: 16),

            const _CatchTile(
              angler: 'John Smith',
              fish: 'Common Carp',
              weight: '8.4 kg',
              bait: 'Sweet Corn',
              time: '18 min ago',
              color: Colors.orange,
            ),

            const Divider(color: AppColors.divider),

            const _CatchTile(
              angler: 'Michael Brown',
              fish: 'Zander',
              weight: '3.1 kg',
              bait: 'Green Shad',
              time: '41 min ago',
              color: Colors.green,
            ),

            const Divider(color: AppColors.divider),

            const _CatchTile(
              angler: 'Daniel Wilson',
              fish: 'Perch',
              weight: '1.2 kg',
              bait: 'Spinner',
              time: '1 h ago',
              color: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }
}

class _CatchTile extends StatelessWidget {
  const _CatchTile({
    required this.angler,
    required this.fish,
    required this.weight,
    required this.bait,
    required this.time,
    required this.color,
  });

  final String angler;
  final String fish;
  final String weight;
  final String bait;
  final String time;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: color.withOpacity(.18),
            child: Icon(Icons.person, color: color),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  angler,
                  style: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3),
                Text('$fish • $weight', style: AppTextStyles.caption),
                const SizedBox(height: 3),
                Text('Bait: $bait', style: AppTextStyles.caption),
              ],
            ),
          ),

          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Icon(
                Icons.camera_alt_rounded,
                color: Colors.white54,
                size: 18,
              ),
              const SizedBox(height: 8),
              Text(time, style: AppTextStyles.caption),
            ],
          ),
        ],
      ),
    );
  }
}
