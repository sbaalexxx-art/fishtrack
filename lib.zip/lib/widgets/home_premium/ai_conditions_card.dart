import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';

enum FishingRating { excellent, good, fair, poor }

class AIConditionsCardPremium extends StatelessWidget {
  const AIConditionsCardPremium({
    super.key,
    this.score = 8.6,
    this.rating = FishingRating.excellent,
    this.bestTime = '06:00 - 10:00',
    this.species = 'Common Carp',
    this.recommendation = 'Corn & Sweet Boilie',
  });

  final double score;
  final FishingRating rating;
  final String bestTime;
  final String species;
  final String recommendation;

  Color get _color {
    switch (rating) {
      case FishingRating.excellent:
        return Colors.green;
      case FishingRating.good:
        return Colors.lightGreen;
      case FishingRating.fair:
        return Colors.orange;
      case FishingRating.poor:
        return Colors.red;
    }
  }

  String get _label {
    switch (rating) {
      case FishingRating.excellent:
        return 'Excellent';
      case FishingRating.good:
        return 'Good';
      case FishingRating.fair:
        return 'Fair';
      case FishingRating.poor:
        return 'Poor';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.psychology_alt_rounded, color: AppColors.ai),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Fishing Conditions',
                    style: AppTextStyles.cardTitle,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${score.toStringAsFixed(1)}/10',
                        style: AppTextStyles.bigValue,
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: _color.withOpacity(.12),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(
                          _label,
                          style: AppTextStyles.trend.copyWith(color: _color),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  width: 78,
                  height: 78,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 78,
                        height: 78,
                        child: CircularProgressIndicator(
                          value: score / 10,
                          strokeWidth: 7,
                          backgroundColor: Colors.white10,
                          color: _color,
                        ),
                      ),
                      Icon(Icons.phishing, color: _color, size: 32),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 18),

            _InfoRow(
              icon: Icons.schedule_rounded,
              title: 'Best Time',
              value: bestTime,
            ),

            const SizedBox(height: 10),

            _InfoRow(
              icon: Icons.set_meal_rounded,
              title: 'Target Species',
              value: species,
            ),

            const SizedBox(height: 10),

            _InfoRow(
              icon: Icons.tips_and_updates_rounded,
              title: 'AI Recommendation',
              value: recommendation,
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.title,
    required this.value,
  });

  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppColors.ai),
        const SizedBox(width: 8),
        Expanded(child: Text(title, style: AppTextStyles.caption)),
        Text(
          value,
          style: AppTextStyles.body.copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
