import 'package:flutter/material.dart';

import 'ai_conditions_card.dart';
import 'community_card.dart';
import 'recent_catches_card.dart';
import 'water_level_card.dart';
import 'weather_card.dart';

class PremiumDashboard extends StatelessWidget {
  const PremiumDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    final bool desktop = width > 1100;
    final bool tablet = width > 720;

    if (desktop) {
      return Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Expanded(child: WaterLevelCardPremium()),
              SizedBox(width: 18),
              Expanded(child: WeatherCardPremium()),
              SizedBox(width: 18),
              Expanded(child: AIConditionsCardPremium()),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Expanded(child: CommunityCardPremium()),
              SizedBox(width: 18),
              Expanded(flex: 2, child: RecentCatchesCardPremium()),
            ],
          ),
        ],
      );
    }

    if (tablet) {
      return Column(
        children: const [
          Row(
            children: [
              Expanded(child: WaterLevelCardPremium()),
              SizedBox(width: 16),
              Expanded(child: WeatherCardPremium()),
            ],
          ),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: AIConditionsCardPremium()),
              SizedBox(width: 16),
              Expanded(child: CommunityCardPremium()),
            ],
          ),
          SizedBox(height: 16),
          RecentCatchesCardPremium(),
        ],
      );
    }

    return const Column(
      children: [
        WaterLevelCardPremium(),

        SizedBox(height: 16),

        WeatherCardPremium(),

        SizedBox(height: 16),

        AIConditionsCardPremium(),

        SizedBox(height: 16),

        CommunityCardPremium(),

        SizedBox(height: 16),

        RecentCatchesCardPremium(),
      ],
    );
  }
}
