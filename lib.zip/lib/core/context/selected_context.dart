import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/station.dart';
import '../../services/water_service.dart';
import 'environmental_context.dart';

/// The single location/water contract carried between FluviAI destinations.
///
/// Every field is optional because the app must remain truthful when a source
/// has not resolved an entity yet. No placeholder location is ever created.
class SelectedContext {
  const SelectedContext({
    this.countryCode,
    this.region,
    this.locationName,
    this.latitude,
    this.longitude,
    this.waterId,
    this.waterName,
    this.riverName,
    this.stationId,
    this.stationName,
    this.damId,
    this.reservoirId,
    this.placeId,
    this.source,
    this.observedAt,
    this.selectedAt,
  });

  final String? countryCode;
  final String? region;
  final String? locationName;
  final double? latitude;
  final double? longitude;
  final String? waterId;
  final String? waterName;
  final String? riverName;
  final String? stationId;
  final String? stationName;
  final String? damId;
  final String? reservoirId;
  final String? placeId;
  final String? source;
  final DateTime? observedAt;
  final DateTime? selectedAt;

  factory SelectedContext.fromStation(Station station) => SelectedContext(
    locationName: station.name,
    latitude: station.latitude,
    longitude: station.longitude,
    // A monitoring-station identifier is never a water-body identifier.
    waterId: null,
    waterName: station.river.isEmpty ? station.name : station.river,
    riverName: station.river.isEmpty ? null : station.river,
    stationId: station.id,
    stationName: station.name,
    source: station.waterLevelSource,
    observedAt: station.hasWaterLevel ? station.lastUpdate : null,
  );

  bool get hasCoordinates => latitude != null && longitude != null;

  bool get hasEntity =>
      waterId != null ||
      stationId != null ||
      damId != null ||
      reservoirId != null ||
      placeId != null;

  String? get primaryLabel =>
      stationName ?? waterName ?? riverName ?? locationName;

  EnvironmentalContext? get environmentalContext {
    final lat = latitude;
    final lng = longitude;
    if (lat == null || lng == null) return null;
    return EnvironmentalContext(
      source: stationId != null
          ? EnvironmentalContextSource.selectedStation
          : EnvironmentalContextSource.selectedWater,
      latitude: lat,
      longitude: lng,
      observedAt: observedAt ?? selectedAt ?? DateTime.now(),
      displayLabel: primaryLabel,
      locality: locationName,
      region: region,
      countryCode: countryCode,
      waterId: waterId,
      waterName: waterName,
      stationId: stationId,
      stationName: stationName,
    );
  }

  SelectedContext copyWith({
    String? countryCode,
    String? region,
    String? locationName,
    double? latitude,
    double? longitude,
    String? waterId,
    String? waterName,
    String? riverName,
    String? stationId,
    String? stationName,
    String? damId,
    String? reservoirId,
    String? placeId,
    String? source,
    DateTime? observedAt,
    DateTime? selectedAt,
  }) => SelectedContext(
    countryCode: countryCode ?? this.countryCode,
    region: region ?? this.region,
    locationName: locationName ?? this.locationName,
    latitude: latitude ?? this.latitude,
    longitude: longitude ?? this.longitude,
    waterId: waterId ?? this.waterId,
    waterName: waterName ?? this.waterName,
    riverName: riverName ?? this.riverName,
    stationId: stationId ?? this.stationId,
    stationName: stationName ?? this.stationName,
    damId: damId ?? this.damId,
    reservoirId: reservoirId ?? this.reservoirId,
    placeId: placeId ?? this.placeId,
    source: source ?? this.source,
    observedAt: observedAt ?? this.observedAt,
    selectedAt: selectedAt ?? this.selectedAt,
  );
}

class SelectedContextController extends Notifier<SelectedContext?> {
  @override
  SelectedContext? build() => null;

  void select(SelectedContext selection) {
    state = selection.copyWith(selectedAt: DateTime.now());
  }

  void selectStation(Station station) {
    WaterService().selectStation(station);
    select(SelectedContext.fromStation(station));
  }

  void clear() => state = null;
}

final selectedContextProvider =
    NotifierProvider<SelectedContextController, SelectedContext?>(
      SelectedContextController.new,
    );

enum FluviAccessTier { free, premium }

class FluviAccessTierController extends Notifier<FluviAccessTier> {
  @override
  FluviAccessTier build() => FluviAccessTier.free;

  void setTier(FluviAccessTier tier) => state = tier;
}

final fluviAccessTierProvider =
    NotifierProvider<FluviAccessTierController, FluviAccessTier>(
      FluviAccessTierController.new,
    );
