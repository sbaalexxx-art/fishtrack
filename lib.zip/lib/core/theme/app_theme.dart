import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'fluviai_commercial_tokens.dart';

class AppTheme {
  AppTheme._();

  static final ThemeData lightTheme = _build(Brightness.light);
  static final ThemeData darkTheme = _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    final background = isDark
        ? FluviAICommercialTokens.background
        : const Color(0xFFF3F8FA);
    final surface = isDark
        ? FluviAICommercialTokens.surface
        : const Color(0xFFFFFFFF);
    final surfaceRaised = isDark
        ? FluviAICommercialTokens.surfaceRaised
        : const Color(0xFFE8F1F4);
    final onSurface = isDark
        ? FluviAICommercialTokens.textPrimary
        : const Color(0xFF10202B);
    final onSurfaceVariant = isDark
        ? FluviAICommercialTokens.textSecondary
        : const Color(0xFF4E6674);
    final scheme = ColorScheme(
      brightness: brightness,
      primary: FluviAICommercialTokens.accent,
      onPrimary: const Color(0xFF001F27),
      primaryContainer: FluviAICommercialTokens.accentSoft,
      onPrimaryContainer: onSurface,
      secondary: FluviAICommercialTokens.brandFocus,
      onSecondary: const Color(0xFF001F27),
      secondaryContainer: surfaceRaised,
      onSecondaryContainer: onSurface,
      error: FluviAICommercialTokens.waterFalling,
      onError: Colors.white,
      errorContainer: FluviAICommercialTokens.waterFalling.withValues(
        alpha: .16,
      ),
      onErrorContainer: onSurface,
      surface: surface,
      onSurface: onSurface,
      onSurfaceVariant: onSurfaceVariant,
      outline: isDark
          ? FluviAICommercialTokens.border
          : const Color(0xFFB7C8D0),
      outlineVariant: isDark
          ? FluviAICommercialTokens.borderSoft
          : const Color(0xFFD7E2E7),
      shadow: Colors.black,
      scrim: Colors.black,
      inverseSurface: onSurface,
      onInverseSurface: surface,
      inversePrimary: FluviAICommercialTokens.brandFocus,
      surfaceTint: Colors.transparent,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      fontFamily: FluviAICommercialTokens.fontFamily,
      scaffoldBackgroundColor: background,
      visualDensity: VisualDensity.standard,
      materialTapTargetSize: MaterialTapTargetSize.padded,

      appBarTheme: AppBarTheme(
        centerTitle: true,
        backgroundColor: background,
        foregroundColor: scheme.onSurface,
        elevation: 0,
      ),

      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceRaised,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: const Color(0xFF001F27),
          minimumSize: const Size(48, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: onSurface,
          minimumSize: const Size(48, 48),
          side: BorderSide(color: scheme.outline),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant,
        thickness: 1,
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(minimumSize: const Size(48, 48)),
      ),
    );
  }
}
