import 'package:flutter/material.dart';

/// Canonical visual language for the production FluviAI experience.
///
/// Values mirror the approved Figma UI/UX Release Candidate v2. Runtime data,
/// entitlement and connectivity remain dynamic; these tokens define only the
/// shared visual contract used by Android and iOS.
abstract final class FluviAICommercialTokens {
  /// Bundled primary UI font used by the approved production design.
  static const primaryFontFamily = 'Geist';

  /// Bundled monospace font for data and technical values.
  static const monoFontFamily = 'IBM Plex Mono';

  /// Compatibility alias used by existing presentation code.
  static const fontFamily = primaryFontFamily;

  static const background = Color(0xFF050B14);
  static const backgroundRaised = Color(0xFF071321);
  static const surface = Color(0xFF0A1628);
  static const surfaceRaised = Color(0xFF0D2033);
  static const surfaceStrong = Color(0xFF112B40);
  static const border = Color(0xFF133750);
  static const borderSoft = Color(0x33133750);

  static const textPrimary = Color(0xFFF6F9FB);
  static const textSecondary = Color(0xFF94A3B8);
  static const textMuted = Color(0xFF64748B);

  static const accent = Color(0xFF43D9CC);
  static const accentDeep = Color(0xFF007394);
  static const accentSoft = Color(0x2643D9CC);
  static const brandFocus = Color(0xFF43D9CC);

  static const waterRising = Color(0xFF43D9CC);
  static const waterStable = Color(0xFF00E676);
  static const waterFalling = Color(0xFFFA4F4F);
  static const warning = Color(0xFFF0BD55);
  static const premium = Color(0xFFF0BD55);

  static const radiusSmall = 12.0;
  static const radiusMedium = 16.0;
  static const radiusLarge = 20.0;
  static const radiusHero = 24.0;

  static const space4 = 4.0;
  static const space8 = 8.0;
  static const space12 = 12.0;
  static const space16 = 16.0;
  static const space20 = 20.0;
  static const space24 = 24.0;
  static const space32 = 32.0;

  static const minimumTouchTarget = 48.0;

  // Approved Bento shell navigation contract (Figma 329:111 / 445:10-14).
  static const bottomNavigationVisualHeight = 60.0;
  static const bottomNavigationHorizontalMargin = 16.0;
  static const bottomNavigationRadius = 20.0;
  static const bottomNavigationQuickAddWidth = 58.0;
  static const bottomNavigationQuickAddVisualHeight = 56.0;
  static const bottomNavigationQuickAddRadius = 18.0;
  static const bottomNavigationIconSize = 19.0;
  static const bottomNavigationLabelSize = 11.0;

  static const bottomNavigationBackground = Color(0xFF071015);
  static const bottomNavigationInactive = Color(0xFF9AABB4);
  static const bottomNavigationBorder = Color(0xD1263941);

  static List<BoxShadow> get softShadow => const [
    BoxShadow(color: Color(0x47000000), blurRadius: 12, offset: Offset(0, 10)),
  ];

  static List<BoxShadow> get heroShadow => const [
    BoxShadow(color: Color(0x47000000), blurRadius: 14, offset: Offset(0, 12)),
  ];

  static const LinearGradient pageGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF0A1628), background, Color(0xFF03070D)],
    stops: [0, .52, 1],
  );

  static const LinearGradient bottomNavigationGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xD9050B14), background],
  );

  static LinearGradient surfaceGradient({Color? accent}) => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color.alphaBlend(
        (accent ?? FluviAICommercialTokens.brandFocus).withValues(alpha: .055),
        surfaceRaised,
      ),
      surface,
    ],
  );
}
